// SnowBear background service worker — auth, settings, custom site scripts
//
// importScripts can occasionally throw 'NetworkError ... failed to load' right
// after the unpacked extension is reloaded — Chrome's MV3 service worker
// sometimes starts up against a stale file snapshot. Retrying once almost
// always resolves it. If it keeps happening, fully REMOVE the extension in
// chrome://extensions (not just the reload icon) and re-"Load unpacked" —
// that clears the stale worker registration.
let coreReady = false

function loadCoreScripts(attempt = 0) {
  try {
    importScripts(
      'website-config.js',
      'firebase-config.js',
      'groq-config.js',
      'groq-service.js',
      'auth-service.js',
      'usage-service.js',
      'rtdb-service.js',
      'shared.js'
    )
    coreReady = true
  } catch (err) {
    console.error('[SnowBear] importScripts failed (attempt ' + (attempt + 1) + '):', err)
    if (attempt < 2) {
      setTimeout(() => loadCoreScripts(attempt + 1), 120 * (attempt + 1))
    }
  }
}
loadCoreScripts()

const API_TIMEOUT_MS = 9000
let cachedBackendBase = null
let keepAliveTimer = null

function startKeepAlive() {
  stopKeepAlive()
  keepAliveTimer = setInterval(() => {
    chrome.runtime.getPlatformInfo(() => {})
  }, 15000)
}

function stopKeepAlive() {
  if (!keepAliveTimer) return
  clearInterval(keepAliveTimer)
  keepAliveTimer = null
}

async function ensureCoreReady(timeoutMs = 5000) {
  if (coreReady) return true
  const deadline = Date.now() + timeoutMs
  while (!coreReady && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 40))
  }
  return coreReady
}

function resolveBackendBase(msgBackend) {
  if (msgBackend && typeof msgBackend === 'string' && msgBackend.trim()) {
    return String(msgBackend).replace(/\/$/, '')
  }
  if (cachedBackendBase) return cachedBackendBase
  const base = String(getWebsiteBaseUrl()).replace(/\/$/, '')
  cachedBackendBase = base
  return base
}

function prewarmBackend() {
  const base = resolveBackendBase()
  fetch(`${base}/api/health`, { method: 'GET', cache: 'no-store' }).catch(() => {})
}

setTimeout(prewarmBackend, 80)
setInterval(prewarmBackend, 5 * 60 * 1000)

const REMOTE_PROFILE_POLL_MS = 20000
setInterval(async () => {
  if (!coreReady) return
  try {
    const stored = await chrome.storage.local.get(STORAGE_KEYS.user)
    if (stored[STORAGE_KEYS.user]?.uid) await pullRemoteProfile()
  } catch (_) {}
}, REMOTE_PROFILE_POLL_MS)

async function fetchWebsiteApi(action, prompt, backend) {
  const base = resolveBackendBase(backend)
  const endpoint = action === 'score' ? 'score' : action
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS)

  try {
    const res = await fetch(`${base}/api/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
      signal: controller.signal,
    })

    let data = {}
    try {
      data = await res.json()
    } catch (_) {}

    if (!res.ok) {
      const err = new Error(data.error || `SnowBear server error ${res.status}`)
      err.status = res.status
      throw err
    }

    return { data, status: res.status }
  } catch (err) {
    if (err?.name === 'AbortError') {
      throw new Error('AI request timed out.')
    }
    throw err
  } finally {
    clearTimeout(timer)
  }
}

function deferCreditSync(uid) {
  setTimeout(async () => {
    try {
      const stored = await chrome.storage.local.get([STORAGE_KEYS.user, STORAGE_KEYS.credits])
      const user = stored[STORAGE_KEYS.user]
      const credits = stored[STORAGE_KEYS.credits]?.[uid]
      if (user?.idToken && credits) {
        await SnowBearRtdb.syncCredits(uid, credits, user.idToken)
      }
    } catch (_) {}
    notifyWebsiteTabs()
  }, 0)
}

function safeReply(sendResponse, payload) {
  try {
    sendResponse(payload)
  } catch (err) {
    console.debug('[SnowBear] sendResponse failed:', err?.message || err)
  }
}

self.addEventListener('unhandledrejection', (event) => {
  console.error('[SnowBear] unhandled rejection:', event.reason)
  event.preventDefault()
})

const STORAGE_KEYS = {
  user: 'snowbear_user',
  settings: 'snowbear_settings',
  chatContext: 'snowbear_chat_context',
  history: 'snowbear_history',
  credits: 'snowbear_credits',
}

function mapPlanFromWebsite(plan) {
  if (plan === 'pro') return 'polar'
  if (plan === 'polar' || plan === 'unlimited' || plan === 'free') return plan
  return 'free'
}

function mapPlanToWebsite(plan) {
  if (plan === 'polar') return 'pro'
  if (plan === 'unlimited' || plan === 'free') return plan
  return 'free'
}

async function getHistoryForUid(uid) {
  const data = await chrome.storage.local.get(STORAGE_KEYS.history)
  const store = data[STORAGE_KEYS.history] || {}
  return store[uid] || []
}

async function saveHistoryForUid(uid, history) {
  const data = await chrome.storage.local.get(STORAGE_KEYS.history)
  const store = data[STORAGE_KEYS.history] || {}
  store[uid] = history
  await chrome.storage.local.set({ [STORAGE_KEYS.history]: store })
}

const WEBSITE_BRIDGE_URLS = [
  'https://snowbear.online/*',
  'https://www.snowbear.online/*',
  'https://snow-tau-ten.vercel.app/*',
  'http://localhost:3000/*',
  'http://127.0.0.1:3000/*',
  'http://snowbear.online/*',
]

function getWebsiteBaseUrl() {
  try {
    if (typeof WEBSITE_CONFIG !== 'undefined' && WEBSITE_CONFIG.backendUrl) {
      const base = String(WEBSITE_CONFIG.backendUrl).replace(/\/$/, '')
      if (base && !base.includes('localhost') && !base.includes('127.0.0.1')) {
        return base
      }
    }
  } catch (_) {}
  return 'https://snowbear.online'
}

function getExtensionGoogleSignInUrl() {
  const base = getWebsiteBaseUrl()
  return `${base}/auth?redirect=${encodeURIComponent('/extension-bridge')}&ext=1`
}

async function notifyWebsiteTabs() {
  try {
    const tabs = await chrome.tabs.query({
      url: WEBSITE_BRIDGE_URLS,
    })
    for (const tab of tabs) {
      if (!tab.id) continue
      chrome.tabs.sendMessage(tab.id, { type: 'CREDITS_UPDATED' }, () => {
        void chrome.runtime.lastError
      })
    }
  } catch (_) {}
}

async function pullIdTokenFromWebsiteTabs(uid) {
  try {
    const tabs = await chrome.tabs.query({ url: WEBSITE_BRIDGE_URLS })
    for (const tab of tabs) {
      if (!tab.id) continue
      try {
        const res = await chrome.tabs.sendMessage(tab.id, { type: 'GET_WEBSITE_ID_TOKEN' })
        if (res?.idToken && (!res.uid || res.uid === uid)) {
          return {
            idToken: res.idToken,
            expiresAt: res.expiresAt || Date.now() + 55 * 60 * 1000,
          }
        }
      } catch (_) { /* tab has no bridge */ }
    }
  } catch (_) {}
  return null
}

async function saveAuthUser(user) {
  await chrome.storage.local.set({ [STORAGE_KEYS.user]: user })
  return user
}

async function resolveAuthForRtdb(options = {}) {
  const fast = options.fast === true
  const stored = await chrome.storage.local.get(STORAGE_KEYS.user)
  let user = stored[STORAGE_KEYS.user]
  if (!user?.uid) return null

  const tokenFresh =
    user.idToken && user.expiresAt && user.expiresAt > Date.now() + 2 * 60 * 1000
  if (tokenFresh) return user
  if (fast && user.idToken) return user

  const fromSite = await pullIdTokenFromWebsiteTabs(user.uid)
  if (fromSite?.idToken) {
    return saveAuthUser({
      ...user,
      idToken: fromSite.idToken,
      expiresAt: fromSite.expiresAt || Date.now() + 55 * 60 * 1000,
    })
  }

  if (user.refreshToken) {
    try {
      const fresh = await SnowBearAuthService.getCurrentUser()
      if (fresh?.idToken) return fresh
      user = fresh || user
    } catch (_) {}
  }

  return user?.uid ? user : null
}

async function pullRemoteProfile() {
  const authUser = await resolveAuthForRtdb()
  if (!authUser?.idToken || !authUser?.uid) return { ok: false }

  await ensureUserInRtdb(authUser)

  const remote = await SnowBearRtdb.fetchUserProfile(authUser.uid, authUser.idToken)
  if (!remote) return { ok: false }

  let changed = false
  const mappedPlan = mapPlanFromWebsite(remote.plan)
  let user = authUser
  const remoteExpiry = remote.planExpiresAt || null
  const remoteCycle = remote.planBillingCycle || null

  if (
    mappedPlan !== authUser.plan ||
    remoteExpiry !== (authUser.planExpiresAt || null) ||
    remoteCycle !== (authUser.planBillingCycle || null)
  ) {
    user = {
      ...authUser,
      plan: mappedPlan || authUser.plan || 'free',
      planExpiresAt: remoteExpiry,
      planBillingCycle: remoteCycle,
    }
    await saveAuthUser(user)
    changed = true
  }

  if (remote.credits) {
    const creditsAll = (await chrome.storage.local.get(STORAGE_KEYS.credits))[STORAGE_KEYS.credits] || {}
    const current = creditsAll[authUser.uid] || { month: new Date().toISOString().slice(0, 7), used: 0, purchased: 0 }
    const merged = {
      month: remote.credits.month || current.month,
      used: remote.credits.used ?? current.used ?? 0,
      purchased: remote.credits.purchased ?? current.purchased ?? 0,
    }
    if (
      merged.used !== current.used ||
      merged.purchased !== current.purchased ||
      merged.month !== current.month
    ) {
      creditsAll[authUser.uid] = merged
      await chrome.storage.local.set({ [STORAGE_KEYS.credits]: creditsAll })
      changed = true
    }
  }

  if (changed) notifyWebsiteTabs()
  return { ok: true, user, changed }
}

async function redeemPromoWithRetry(uid, email, code) {
  let user = await resolveAuthForRtdb({ fast: true })
  if (!user?.idToken) {
    user = await resolveAuthForRtdb()
  }
  if (!user?.idToken) {
    throw new Error('Sign in on snowbear.online (keep tab open), then try again.')
  }
  try {
    return await SnowBearRtdb.redeemPromoCode(uid, email, user.idToken, code)
  } catch (err) {
    const msg = err?.message || ''
    const authIssue =
      msg.includes('Sign in') ||
      msg.includes('Session') ||
      msg.includes('Invalid session') ||
      msg.includes('Permission denied') ||
      msg.includes('Could not read') ||
      msg.includes('Could not reach')

    if (!authIssue) throw err

    const fromSite = await pullIdTokenFromWebsiteTabs(uid)
    if (!fromSite?.idToken || fromSite.idToken === user.idToken) throw err

    user = await saveAuthUser({
      ...user,
      idToken: fromSite.idToken,
      expiresAt: fromSite.expiresAt || Date.now() + 55 * 60 * 1000,
    })
    return await SnowBearRtdb.redeemPromoCode(uid, email, user.idToken, code)
  }
}

function mergeHistoryLists(a, b) {
  const map = new Map()
  for (const item of [...(a || []), ...(b || [])]) map.set(item.id, item)
  return [...map.values()].sort((x, y) => Number(y.id) - Number(x.id)).slice(0, 200)
}

const CUSTOM_SCRIPT_ID = 'snowbear-custom'

const DEFAULT_SETTINGS = SnowBearShared?.DEFAULT_SETTINGS || {
  enabled: true,
  blockedWebsites: [],
  advancedMode: false,
  customPrompts: { enhance: '', compress: '', grammar: '', score: '' },
}

async function syncCustomScripts() {
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [CUSTOM_SCRIPT_ID] })
    if (existing.length) {
      await chrome.scripting.unregisterContentScripts({ ids: [CUSTOM_SCRIPT_ID] })
    }
  } catch (err) {
    console.debug('[SnowBear] legacy script cleanup:', err.message)
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(STORAGE_KEYS.settings, (data) => {
    if (!data[STORAGE_KEYS.settings]) {
      chrome.storage.local.set({ [STORAGE_KEYS.settings]: DEFAULT_SETTINGS })
    }
    syncCustomScripts()
  })
})

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[STORAGE_KEYS.settings]) {
    syncCustomScripts()
  }
})

async function ensureUserInRtdb(user) {
  if (!user?.uid || !user?.idToken) return
  try {
    await SnowBearRtdb.registerUserIfNeeded(user.uid, user.email || '', user.idToken)
    const month = new Date().toISOString().slice(0, 7)
    const stored = await chrome.storage.local.get(STORAGE_KEYS.credits)
    const creditsAll = stored[STORAGE_KEYS.credits] || {}
    if (!creditsAll[user.uid]) {
      creditsAll[user.uid] = { month, used: 0, purchased: 0 }
      await chrome.storage.local.set({ [STORAGE_KEYS.credits]: creditsAll })
    }
  } catch (err) {
    console.debug('[SnowBear] RTDB register:', err?.message || err)
  }
}

async function handleAuthAction(fn) {
  try {
    const user = await fn()
    if (user?.uid) await ensureUserInRtdb(user)
    return { user }
  } catch (err) {
    return {
      error: {
        code: err.code || 'auth/unknown',
        message: err.message || 'Authentication failed',
        raw: err.raw || err.message,
        userMessage: SnowBearAuthService.userMessage(err),
      },
    }
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'PING') {
    safeReply(sendResponse, { ok: true, coreReady })
    return true
  }

  if (!coreReady) {
    safeReply(sendResponse, { error: 'SnowBear is starting. Wait a moment and try again.' })
    return true
  }

  if (msg.type === 'GROQ_COMPLETE') {
    startKeepAlive()
    SnowBearGroq.complete(msg.userContent, {
      temperature: msg.temperature,
      maxTokens: msg.maxTokens,
    })
      .then((result) => safeReply(sendResponse, { result }))
      .catch((err) => safeReply(sendResponse, { error: err.message || 'Groq request failed.' }))
      .finally(() => stopKeepAlive())
    return true
  }

  if (msg.type === 'WEBSITE_API') {
    startKeepAlive()
    ;(async () => {
      try {
        const ready = await ensureCoreReady()
        if (!ready) {
          safeReply(sendResponse, { error: 'SnowBear is starting. Wait a moment and try again.' })
          return
        }
        const result = await fetchWebsiteApi(msg.action, msg.prompt, msg.backend)
        safeReply(sendResponse, result)
      } catch (err) {
        safeReply(sendResponse, {
          error: err.message || 'Failed to reach SnowBear server.',
          status: err.status,
        })
      } finally {
        stopKeepAlive()
      }
    })()
    return true
  }

  if (msg.type === 'RUN_ACTION') {
    startKeepAlive()
    ;(async () => {
      try {
        const ready = await ensureCoreReady()
        if (!ready) {
          safeReply(sendResponse, {
            ok: false,
            error: 'SnowBear is starting. Wait a moment and try again.',
          })
          return
        }

        if (!msg.uid) {
          safeReply(sendResponse, {
            ok: false,
            error: 'Sign in via the SnowBear extension icon first.',
          })
          return
        }

        const usage = await SnowBearUsage.checkAllowed(msg.uid, msg.action)
        if (!usage.allowed) {
          safeReply(sendResponse, { ok: false, usage })
          return
        }

        const result = await fetchWebsiteApi(msg.action, msg.prompt, msg.backend)
        const cost = SnowBearUsage.CREDIT_COSTS[msg.action] ?? 0
        if (cost > 0 && usage.plan !== 'unlimited') {
          const deducted = await SnowBearUsage.deduct(msg.uid, msg.action)
          if (deducted.status) usage.remaining = deducted.status.remaining
          if (deducted.status) usage.used = deducted.status.used
          deferCreditSync(msg.uid)
        }

        safeReply(sendResponse, { ok: true, data: result.data, usage })
      } catch (err) {
        safeReply(sendResponse, {
          ok: false,
          error: err.message || 'Action failed.',
          status: err.status,
        })
      } finally {
        stopKeepAlive()
      }
    })()
    return true
  }

  if (msg.type === 'AUTH_SIGNUP') {
    handleAuthAction(() => SnowBearAuthService.signUp(msg.email, msg.password))
      .then((res) => safeReply(sendResponse, res))
      .catch((err) => safeReply(sendResponse, { error: { message: err?.message || 'Sign up failed.' } }))
    return true
  }

  if (msg.type === 'AUTH_SIGNIN') {
    handleAuthAction(() => SnowBearAuthService.signIn(msg.email, msg.password))
      .then((res) => safeReply(sendResponse, res))
      .catch((err) => safeReply(sendResponse, { error: { message: err?.message || 'Sign in failed.' } }))
    return true
  }

  if (msg.type === 'AUTH_SIGNUP_OR_SIGNIN') {
    handleAuthAction(() => SnowBearAuthService.signUpOrSignIn(msg.email, msg.password))
      .then((res) => safeReply(sendResponse, res))
      .catch((err) => safeReply(sendResponse, { error: { message: err?.message || 'Auth failed.' } }))
    return true
  }

  if (msg.type === 'AUTH_SIGNOUT') {
    SnowBearAuthService.signOut()
      .then(async () => {
        try {
          await chrome.storage.local.remove(['snowbear_last_sync'])
        } catch (_) {}
      })
      .then(() => safeReply(sendResponse, { ok: true }))
      .catch((err) => safeReply(sendResponse, { ok: false, message: err?.message || 'Sign out failed.' }))
    return true
  }

  if (msg.type === 'AUTH_GET_USER') {
    handleAuthAction(() => SnowBearAuthService.getCurrentUser())
      .then((res) => safeReply(sendResponse, res))
      .catch((err) => safeReply(sendResponse, { error: { message: err?.message || 'Session check failed.' } }))
    return true
  }

  if (msg.type === 'USAGE_STATUS') {
    SnowBearUsage.getStatus(msg.uid, msg.action).then((status) => sendResponse(status))
    return true
  }

  if (msg.type === 'USAGE_CONSUME') {
    ;(async () => {
      try {
        const status = await SnowBearUsage.consume(msg.uid, msg.action)
        safeReply(sendResponse, status)
        if (status.consumed) deferCreditSync(msg.uid)
      } catch (err) {
        safeReply(sendResponse, { allowed: false, message: err?.message || 'Usage check failed.' })
      }
    })()
    return true
  }

  if (msg.type === 'ACTIVATE_PRO') {
    SnowBearUsage.activatePro(msg.uid).then((result) => sendResponse(result))
    return true
  }

  if (msg.type === 'SET_PLAN') {
    SnowBearUsage.setPlan(msg.uid, msg.plan).then((result) => {
      sendResponse(result)
      if (result.ok) notifyWebsiteTabs()
    })
    return true
  }

  if (msg.type === 'REDEEM_PROMO') {
    ;(async () => {
      try {
        const stored = await chrome.storage.local.get(STORAGE_KEYS.user)
        const user = stored[STORAGE_KEYS.user]
        if (!user?.uid) {
          sendResponse({
            ok: false,
            message: 'Sign in on snowbear.online first (keep tab open), then try again.',
          })
          return
        }
        const result = await redeemPromoWithRetry(
          user.uid,
          user.email || '',
          msg.code
        )
        sendResponse(result)
        notifyWebsiteTabs()
      } catch (err) {
        sendResponse({ ok: false, message: err.message || 'Redeem failed.' })
      }
    })()
    return true
  }

  if (msg.type === 'ADD_CREDITS') {
    SnowBearUsage.addPurchasedCredits(msg.uid, msg.amount || 100).then((result) => {
      sendResponse(result)
      if (result.ok) notifyWebsiteTabs()
    })
    return true
  }

  if (msg.type === 'GET_SYNC_STATE') {
    ;(async () => {
      try {
        const data = await chrome.storage.local.get([
          STORAGE_KEYS.user,
          STORAGE_KEYS.credits,
          STORAGE_KEYS.history,
        ])
        const user = data[STORAGE_KEYS.user]
        if (!user?.uid) {
          safeReply(sendResponse, null)
          return
        }
        const creditsAll = data[STORAGE_KEYS.credits] || {}
        const credits =
          creditsAll[user.uid] || {
            month: new Date().toISOString().slice(0, 7),
            used: 0,
            purchased: 0,
          }
        const history = await getHistoryForUid(user.uid)
        safeReply(sendResponse, {
          uid: user.uid,
          email: user.email,
          plan: mapPlanToWebsite(user.plan),
          credits,
          history,
        })
      } catch (err) {
        console.debug('[SnowBear] GET_SYNC_STATE:', err?.message || err)
        safeReply(sendResponse, null)
      }
    })()
    return true
  }

  if (msg.type === 'SYNC_FROM_WEBSITE') {
    ;(async () => {
      try {
        const payload = msg.payload || {}
        if (!payload.uid) {
          safeReply(sendResponse, { ok: false, message: 'Missing user id.' })
          return
        }

        const stored = await chrome.storage.local.get(STORAGE_KEYS.user)
        const prev = stored[STORAGE_KEYS.user] || {}
        let user = {
          uid: payload.uid,
          email: payload.email || prev.email || '',
          plan: mapPlanFromWebsite(payload.plan || prev.plan || 'free'),
          idToken: payload.idToken || prev.idToken || null,
          refreshToken: prev.refreshToken || null,
          expiresAt: payload.idToken ? Date.now() + 55 * 60 * 1000 : prev.expiresAt,
        }
        await chrome.storage.local.set({ [STORAGE_KEYS.user]: user })

        if (!user.idToken) {
          const fromSite = await pullIdTokenFromWebsiteTabs(user.uid)
          if (fromSite?.idToken) {
            user = {
              ...user,
              idToken: fromSite.idToken,
              expiresAt: fromSite.expiresAt || Date.now() + 55 * 60 * 1000,
            }
            await saveAuthUser(user)
          }
        }

        if (payload.credits) {
          const creditsAll =
            (await chrome.storage.local.get(STORAGE_KEYS.credits))[STORAGE_KEYS.credits] || {}
          const current = creditsAll[payload.uid] || payload.credits
          const fromSite = payload.credits
          creditsAll[payload.uid] = {
            month: fromSite.month || current.month,
            used: fromSite.used ?? current.used ?? 0,
            purchased: fromSite.purchased ?? current.purchased ?? 0,
          }
          await chrome.storage.local.set({ [STORAGE_KEYS.credits]: creditsAll })
        }

        if (Array.isArray(payload.history)) {
          const merged = mergeHistoryLists(await getHistoryForUid(payload.uid), payload.history)
          await saveHistoryForUid(payload.uid, merged)
        }

        try {
          if (user.idToken) await ensureUserInRtdb(user)
        } catch (_) {}

        await chrome.storage.local.set({
          snowbear_last_sync: { at: Date.now(), uid: payload.uid },
        })

        safeReply(sendResponse, { ok: true, user })
        notifyWebsiteTabs()
      } catch (err) {
        console.error('[SnowBear] SYNC_FROM_WEBSITE:', err)
        safeReply(sendResponse, { ok: false, message: err?.message || 'Sync failed.' })
      }
    })()
    return true
  }

  if (msg.type === 'SAVE_HISTORY_ITEM') {
    ;(async () => {
      try {
        const { uid, item } = msg
        if (!uid || !item) {
          safeReply(sendResponse, { ok: false })
          return
        }
        const current = await getHistoryForUid(uid)
        await saveHistoryForUid(uid, mergeHistoryLists([item], current))
        safeReply(sendResponse, { ok: true })
        notifyWebsiteTabs()
      } catch (err) {
        safeReply(sendResponse, { ok: false, message: err?.message || 'Save failed.' })
      }
    })()
    return true
  }

  if (msg.type === 'PULL_REMOTE_PROFILE') {
    pullRemoteProfile()
      .then((result) => sendResponse(result || { ok: false }))
      .catch(() => sendResponse({ ok: false }))
    return true
  }

  if (msg.type === 'GET_AUTH') {
    chrome.storage.local.get(STORAGE_KEYS.user, (data) => {
      safeReply(sendResponse, { user: data[STORAGE_KEYS.user] || null })
    })
    return true
  }

  if (msg.type === 'AUTH_OPEN_GOOGLE_SIGNIN') {
    ;(async () => {
      try {
        const signInUrl = getExtensionGoogleSignInUrl()
        const tab = await chrome.tabs.create({ url: signInUrl })
        sendResponse({ ok: true, tabId: tab?.id ?? null, url: signInUrl })
      } catch (err) {
        sendResponse({
          ok: false,
          message: err?.message || 'Could not open sign-in page on snowbear.online.',
        })
      }
    })()
    return true
  }

  if (msg.type === 'GET_SETTINGS') {
    chrome.storage.local.get([STORAGE_KEYS.settings, STORAGE_KEYS.user], (data) => {
      sendResponse({
        settings: data[STORAGE_KEYS.settings] || null,
        user: data[STORAGE_KEYS.user] || null,
      })
    })
    return true
  }

  if (msg.type === 'SYNC_CUSTOM_SCRIPTS') {
    syncCustomScripts().then(() => sendResponse({ ok: true }))
    return true
  }

  if (msg.type === 'SAVE_CHAT_CONTEXT') {
    chrome.storage.local.get(STORAGE_KEYS.chatContext, (data) => {
      const ctx = data[STORAGE_KEYS.chatContext] || {}
      ctx[msg.chatId] = { text: msg.text, savedAt: Date.now() }
      const keys = Object.keys(ctx)
      if (keys.length > 50) {
        keys
          .sort((a, b) => (ctx[a].savedAt || 0) - (ctx[b].savedAt || 0))
          .slice(0, keys.length - 50)
          .forEach((k) => delete ctx[k])
      }
      chrome.storage.local.set({ [STORAGE_KEYS.chatContext]: ctx })
    })
    sendResponse({ ok: true })
    return true
  }

  if (msg.type === 'GET_CHAT_CONTEXT') {
    chrome.storage.local.get(STORAGE_KEYS.chatContext, (data) => {
      const ctx = data[STORAGE_KEYS.chatContext] || {}
      sendResponse({ text: ctx[msg.chatId]?.text || '' })
    })
    return true
  }
})