// Instant popup paint from cached auth — must stay external (MV3 CSP blocks inline scripts).
;(function bootPopupFast() {
  try {
    chrome.runtime.sendMessage({ type: 'PING' })
    chrome.storage.local.get(['snowbear_user', 'snowbear_credits'], function (data) {
      var user = data.snowbear_user
      var auth = document.getElementById('auth-screen')
      var app = document.getElementById('app-screen')
      if (!auth || !app) return
      if (user && user.uid) {
        auth.classList.add('hidden')
        app.classList.remove('hidden')
        var plan = user.plan === 'pro' ? 'polar' : user.plan || 'free'
        var planBadge = document.getElementById('current-plan-badge')
        var usageBadge = document.getElementById('usage-badge')
        if (planBadge) {
          planBadge.textContent =
            plan === 'unlimited' ? 'Unlimited Plan' : plan === 'polar' ? 'Polar Plan' : 'Free Plan'
        }
        if (usageBadge) {
          if (plan === 'unlimited') {
            usageBadge.textContent = '∞ Unlimited'
          } else {
            var cred = data.snowbear_credits && data.snowbear_credits[user.uid]
            var used = (cred && cred.used) || 0
            var purchased = (cred && cred.purchased) || 0
            var allowance = plan === 'polar' ? 100 : 10
            var left = Math.max(0, allowance + purchased - used)
            usageBadge.textContent = left + ' cr left'
          }
        }
      }
    })
  } catch (_) {}
})()