"""Remove solid black background from bear-prompt.png for transparent pin icon."""
from collections import deque
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "bear-prompt.png"
DARK_LIMIT = 55
EDGE_LIMIT = 70


def is_dark(r: int, g: int, b: int, a: int, limit: int = DARK_LIMIT) -> bool:
    return a > 0 and r <= limit and g <= limit and b <= limit


def flood_remove_background(img: Image.Image) -> None:
    px = img.load()
    w, h = img.size
    q: deque[tuple[int, int]] = deque()
    seen: set[tuple[int, int]] = set()
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        if is_dark(*px[x, y]):
            q.append((x, y))
            seen.add((x, y))
    while q:
        x, y = q.popleft()
        px[x, y] = (0, 0, 0, 0)
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < w and 0 <= ny < h and (nx, ny) not in seen and is_dark(*px[nx, ny]):
                seen.add((nx, ny))
                q.append((nx, ny))


def soften_edges(img: Image.Image) -> None:
    px = img.load()
    w, h = img.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a and max(r, g, b) <= EDGE_LIMIT:
                fade = int(255 * max(r, g, b) / EDGE_LIMIT)
                px[x, y] = (r, g, b, min(a, fade))


def main() -> None:
    img = Image.open(TARGET).convert("RGBA")
    flood_remove_background(img)
    soften_edges(img)
    img.save(TARGET, "PNG")
    print(f"Updated {TARGET} — corners and background are transparent")


if __name__ == "__main__":
    main()