// SnowBear Firebase configuration
const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyCSlC-QUUXIdqk-E--83KdX84-1AKtOJiA',
  authDomain: 'snowbear-online.firebaseapp.com',
  projectId: 'snowbear-online',
  storageBucket: 'snowbear-online.firebasestorage.app',
  messagingSenderId: '420360574036',
  appId: '1:420360574036:web:ed69dd7212199b22ca09c1',
  measurementId: 'G-TXSH91974E',
  databaseURL: 'https://snowbear-online-default-rtdb.asia-southeast1.firebasedatabase.app',
}