const WEBSITE_CONFIG = { backendUrl: "https://www.snowbear.online" };
