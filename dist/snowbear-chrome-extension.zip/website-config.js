const WEBSITE_CONFIG = { backendUrl: "https://snowbear.online" };
