// SnowBear popup v2.1 — separate signup/login, free daily limit
;(function () {
  if (typeof SnowBearShared === 'undefined' || typeof SnowBearAuth === 'undefined') {
    document.body.innerHTML =
      '<div style="padding:20px;font-family:sans-serif;font-size:13px;color:#334155;">SnowBear failed to load. Please reload the extension at chrome://extensions</div>'
    return
  }

  const SB = SnowBearShared
  const Auth = SnowBearAuth

  const $ = (id) => document.getElementById(id)

  const authScreen = $('auth-screen')
  const appScreen = $('app-screen')
  const authError = $('auth-error')
  const btnGoogleAuth = $('btn-google-auth')
  const usageBadge = $('usage-badge')
  const currentPlanBadge = $('current-plan-badge')
  const btnSettingsSignout = $('btn-settings-signout')
  const btnHeaderUpgrade = $('btn-header-upgrade')
  const btnUpgradeCta = $('btn-upgrade-cta')
  const btnActivatePro = $('btn-activate-pro')
  const upgradeModal = $('upgrade-modal')
  const upgradeModalCount = $('upgrade-modal-count')
  const btnModalUpgrade = $('btn-modal-upgrade')
  const btnModalActivate = $('btn-modal-activate')
  const btnModalClose = $('btn-modal-close')

  const tabBtns = document.querySelectorAll('.tab-btn')
  const promptInput = $('prompt-input')
  const charCounter = $('char-counter')
  const btnSubmit = $('btn-submit')
  const btnText = $('btn-text')
  const loader = $('loader')
  const resultBox = $('result-box')
  const resultType = $('result-type')
  const resultText = $('result-text')
  const btnCopy = $('btn-copy')
  const inputLabel = $('input-label')

  const navTabs = document.querySelectorAll('.nav-tab')
  const sectionTools = $('section-tools')
  const sectionCredits = $('section-credits')
  const sectionSettings = $('section-settings')
  const sectionUpgrade = $('section-upgrade')

  const toggleEnabled = $('toggle-enabled')
  const toggleAdvanced = $('toggle-advanced')
  const advancedPrompts = $('advanced-prompts')
  const advancedToggleRow = $('advanced-toggle-row')
  const advancedHint = $('advanced-hint')
  const customSiteInput = $('custom-site-input')
  const btnAddSite = $('btn-add-site')
  const customSitesList = $('custom-sites-list')
  const defaultSitesEl = $('default-sites')
  const btnSaveSettings = $('btn-save-settings')

  let activeTab = 'enhance'
  let settings = { ...SB.DEFAULT_SETTINGS }
  let blockedWebsites = []
  let currentUser = null

  function sendMsg(msg, timeoutMs = 0) {
    return new Promise((resolve) => {
      let settled = false
      const finish = (value) => {
        if (settled) return
        settled = true
        resolve(value)
      }
      if (timeoutMs > 0) {
        setTimeout(() => finish({ ok: false, message: 'Request timed out. Reload extension and try again.' }), timeoutMs)
      }
      chrome.runtime.sendMessage(msg, (res) => {
        if (chrome.runtime.lastError) finish(null)
        else finish(res)
      })
    })
  }

  function websiteUrl(path = '') {
    const base =
      typeof WEBSITE_CONFIG !== 'undefined' && WEBSITE_CONFIG.backendUrl
        ? WEBSITE_CONFIG.backendUrl.replace(/\/$/, '')
        : 'https://snowbear.online'
    return `${base}${path}`
  }

  function showAuth() {
    authScreen.classList.remove('hidden')
    appScreen.classList.add('hidden')
    if (authError) authError.textContent = ''
  }

  function paintCreditsFromCache(user, creditsAll) {
    if (!user?.uid) return
    const plan = normalizePlan(user.plan)
    const record = creditsAll?.[user.uid] || {}
    const used = record.used || 0
    const purchased = record.purchased || 0
    const allowance = plan === 'unlimited' ? Infinity : plan === 'polar' ? 100 : 10
    const remaining =
      plan === 'unlimited' ? Infinity : Math.max(0, (allowance === Infinity ? 0 : allowance) + purchased - used)

    if (currentPlanBadge) {
      const label = SB.PLANS[plan]?.name || 'Free Plan'
      currentPlanBadge.textContent = label
      currentPlanBadge.classList.remove('plan-badge--polar', 'plan-badge--unlimited')
      if (plan === 'polar') currentPlanBadge.classList.add('plan-badge--polar')
      if (plan === 'unlimited') currentPlanBadge.classList.add('plan-badge--unlimited')
    }

    if (usageBadge) {
      if (plan === 'unlimited') {
        usageBadge.textContent = '∞ Unlimited'
        usageBadge.classList.remove('usage-badge--empty')
      } else {
        const left = remaining
        usageBadge.textContent = `${left} cr left`
        usageBadge.classList.toggle('usage-badge--empty', left === 0)
      }
    }
  }

  function showApp(user) {
    if (!user?.uid) {
      showAuth()
      return
    }

    const sameUser = currentUser?.uid === user.uid
    currentUser = user
    authScreen?.classList.add('hidden')
    appScreen?.classList.remove('hidden')
    updateAdvancedAccessUI()

    chrome.storage.local.get('snowbear_credits', (data) => {
      paintCreditsFromCache(user, data.snowbear_credits || {})
    })

    if (sameUser) return

    setTimeout(() => {
      refreshUsageBadge().catch(() => {})
      sendMsg({ type: 'PULL_REMOTE_PROFILE' })
        .then((pulled) => {
          if (!pulled?.user?.uid) return
          currentUser = pulled.user
          refreshUsageBadge().catch(() => {})
          updateAdvancedAccessUI()
        })
        .catch(() => {})
    }, 0)
  }

  function authErrorMsg(err) {
    if (!err) return 'Authentication failed. Please try again.'
    if (typeof err === 'string') return err
    if (err.userMessage) return err.userMessage
    const map = {
      'auth/email-already-in-use': 'This email is already registered. Use the Log In tab.',
      'auth/invalid-email': 'Enter a valid email address.',
      'auth/weak-password': 'Password must be at least 6 characters.',
      'auth/user-not-found': 'No account found. Use Create Account first.',
      'auth/wrong-password': 'Incorrect password.',
      'auth/invalid-credential': 'Wrong email or password. Check your details or create an account.',
      'auth/operation-not-allowed': 'Enable Email/Password in Firebase Console.',
      'auth/too-many-requests': 'Too many attempts. Wait a few minutes.',
      'auth/api-key-invalid': 'Firebase API key blocked. Check Google Cloud Console.',
    }
    return map[err.code] || err.message || 'Authentication failed.'
  }

  function validateCredentials(email, password) {
    if (!email || !password) return 'Enter email and password.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Enter a valid email address.'
    if (password.length < 6) return 'Password must be at least 6 characters.'
    return ''
  }

  async function handleGoogleAuth() {
    if (authError) authError.textContent = ''

    const existing = await sendMsg({ type: 'GET_AUTH' })
    if (existing?.user?.uid) {
      showApp(existing.user)
      return
    }

    if (btnGoogleAuth) {
      btnGoogleAuth.disabled = true
      btnGoogleAuth.textContent = 'Opening sign-in…'
    }

    try {
      const res = await sendMsg({ type: 'AUTH_OPEN_GOOGLE_SIGNIN' })
      if (!res?.ok) {
        if (authError) {
          authError.textContent =
            res?.message || 'Could not open sign-in. Visit snowbear.online and try again.'
        }
        return
      }

      if (authError) {
        authError.textContent =
          'Complete Google sign-in on snowbear.online in the new tab, then reopen SnowBear — you will be signed in automatically.'
      }
    } catch (e) {
      if (authError) authError.textContent = e.message || 'Could not open website sign-in.'
    } finally {
      if (btnGoogleAuth) {
        btnGoogleAuth.disabled = false
        btnGoogleAuth.innerHTML = '<span>Continue with Google</span>'
      }
    }
  }

  function normalizePlan(plan) {
    if (plan === 'pro') return 'polar'
    if (plan === 'unlimited') return 'unlimited'
    return plan || 'free'
  }

  function canUseCustomPrompts(plan) {
    const p = normalizePlan(plan)
    return p === 'polar' || p === 'unlimited'
  }

  function updateAdvancedAccessUI() {
    const allowed = canUseCustomPrompts(currentUser?.plan)
    if (!allowed) {
      toggleAdvanced.checked = false
      advancedPrompts?.classList.add('hidden')
      toggleAdvanced.disabled = true
      advancedToggleRow?.classList.add('toggle-row--locked')
      if (advancedHint) {
        advancedHint.textContent =
          'Polar & Unlimited only. Tap here to view plans on snowbear.online.'
        advancedHint.classList.add('hint--upgrade')
      }
      return
    }

    toggleAdvanced.disabled = false
    advancedToggleRow?.classList.remove('toggle-row--locked')
    if (advancedHint) {
      advancedHint.textContent =
        'Polar & Unlimited plans only. Use {{prompt}} as placeholder. Score is always free.'
      advancedHint.classList.remove('hint--upgrade')
    }
    advancedPrompts?.classList.toggle('hidden', !toggleAdvanced.checked)
  }

  function handleAdvancedToggleBlocked() {
    toggleAdvanced.checked = false
    advancedPrompts?.classList.add('hidden')
    openWebsitePricing()
  }

  async function getCreditStatus(action) {
    if (!currentUser?.uid) return null
    return sendMsg({ type: 'USAGE_STATUS', uid: currentUser.uid, action })
  }

  async function refreshCreditsUI() {
    const status = await getCreditStatus()
    if (!status) return

    const plan = normalizePlan(status.plan)
    currentUser.plan = plan

    if (currentPlanBadge) {
      const label = status.planLabel || SB.PLANS[plan]?.name || 'Free Plan'
      currentPlanBadge.textContent = label
      currentPlanBadge.classList.remove('plan-badge--polar', 'plan-badge--unlimited')
      if (plan === 'polar') currentPlanBadge.classList.add('plan-badge--polar')
      if (plan === 'unlimited') currentPlanBadge.classList.add('plan-badge--unlimited')
    }

    if (usageBadge) {
      if (plan === 'unlimited') {
        usageBadge.textContent = '∞ Unlimited'
        usageBadge.classList.remove('usage-badge--empty')
      } else {
        const left = status.remaining ?? 0
        usageBadge.textContent = `${left} cr left`
        usageBadge.classList.toggle('usage-badge--empty', left === 0)
      }
    }

    const usedEl = $('credits-used')
    const remEl = $('credits-remaining')
    const planEl = $('credits-plan-label')
    const planExpiryEl = $('credits-plan-expiry')
    const barEl = $('credits-bar-fill')

    if (planEl) planEl.textContent = status.planLabel || SB.PLANS[plan]?.name || 'Free Plan'
    if (planExpiryEl) {
      const exp = currentUser?.planExpiresAt
      if (plan !== 'free' && typeof exp === 'number' && exp > Date.now()) {
        const cycle =
          currentUser?.planBillingCycle === 'yearly'
            ? ' (1 year)'
            : currentUser?.planBillingCycle === 'monthly'
              ? ' (30 days)'
              : ''
        planExpiryEl.textContent = `Active until ${new Date(exp).toLocaleString()}${cycle}`
        planExpiryEl.style.display = 'block'
      } else {
        planExpiryEl.textContent = ''
        planExpiryEl.style.display = 'none'
      }
    }
    if (usedEl) usedEl.textContent = plan === 'unlimited' ? '—' : String(status.used ?? 0)
    if (remEl) remEl.textContent = plan === 'unlimited' ? '∞' : String(status.remaining ?? 0)

    if (barEl && plan !== 'unlimited') {
      const total = status.totalPool || status.limit || 10
      const pct = total > 0 ? Math.min(100, ((status.used || 0) / total) * 100) : 0
      barEl.style.width = `${pct}%`
    } else if (barEl) {
      barEl.style.width = '0%'
    }

    document.querySelectorAll('.plan-card').forEach((c) => c.classList.remove('plan-card--active'))
    const activeCard = $('plan-card-' + plan)
    if (activeCard) activeCard.classList.add('plan-card--active')

    updateAdvancedAccessUI()
  }

  async function refreshUsageBadge() {
    await refreshCreditsUI()
  }

  async function consumeUsage(action) {
    if (!currentUser?.uid) return { allowed: false, message: 'Please sign in first.' }
    const status = await sendMsg({ type: 'USAGE_CONSUME', uid: currentUser.uid, action })
    if (status) await refreshCreditsUI()
    return status || { allowed: false, message: 'Could not check credits.' }
  }

  function showUpgradeModal(status) {
    if (!upgradeModal) return
    const left = status?.remaining ?? 0
    if (upgradeModalCount) upgradeModalCount.textContent = `${left} credits remaining`
    upgradeModal.classList.remove('hidden')
  }

  function hideUpgradeModal() {
    upgradeModal?.classList.add('hidden')
  }

  function openWebsitePricing() {
    window.open(websiteUrl('/pricing'), '_blank')
  }

  function openWebsiteCredits() {
    window.open(websiteUrl('/credits'), '_blank')
  }

  function initAuth() {
    chrome.storage.local.get(['snowbear_user', 'snowbear_credits'], (data) => {
      const user = data.snowbear_user
      if (user?.uid) {
        try {
          showApp(user)
        } catch (_) {
          showAuth()
        }
        return
      }
      showAuth()
    })

    setTimeout(() => {
      sendMsg({ type: 'GET_AUTH' })
        .then((synced) => {
          if (synced?.user?.uid) showApp(synced.user)
        })
        .catch(() => {})
    }, 0)
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return

    if (changes.snowbear_credits?.newValue && currentUser?.uid) {
      paintCreditsFromCache(currentUser, changes.snowbear_credits.newValue || {})
      return
    }

    const nextUser = changes.snowbear_user?.newValue
    if (!nextUser?.uid) return

    try {
      showApp(nextUser)
    } catch (_) {
      showAuth()
    }
  })

  btnGoogleAuth?.addEventListener('click', (e) => {
    e.preventDefault()
    handleGoogleAuth()
  })

  async function handleSignOut() {
    await chrome.storage.local.remove(['snowbear_user', 'snowbear_last_sync'])
    await Auth.signOut().catch(() => {})
    currentUser = null
    showAuth()
  }

  btnSettingsSignout?.addEventListener('click', handleSignOut)

  function showSection(name) {
    sectionTools?.classList.toggle('hidden', name !== 'tools')
    sectionCredits?.classList.toggle('hidden', name !== 'credits')
    sectionSettings?.classList.toggle('hidden', name !== 'settings')
    sectionUpgrade?.classList.toggle('hidden', name !== 'upgrade')
    navTabs.forEach((t) => t.classList.toggle('active', t.dataset.section === name))
    if (name === 'credits') {
      chrome.storage.local.get('snowbear_credits', (data) => {
        if (currentUser) paintCreditsFromCache(currentUser, data.snowbear_credits || {})
      })
      refreshCreditsUI().catch(() => {})
    }
    if (name === 'settings') {
      ensureSettingsLoaded()
      renderDefaultSites()
    }
  }

  navTabs.forEach((tab) => {
    tab.addEventListener('click', () => showSection(tab.dataset.section))
  })

  btnHeaderUpgrade.addEventListener('click', () => showSection('credits'))
  btnUpgradeCta?.addEventListener('click', openWebsitePricing)
  $('btn-plan-polar')?.addEventListener('click', openWebsitePricing)
  $('btn-plan-unlimited')?.addEventListener('click', openWebsitePricing)
  $('btn-buy-credits')?.addEventListener('click', openWebsiteCredits)

  $('btn-redeem-promo')?.addEventListener('click', async () => {
    const input = $('promo-code-input')
    const msgEl = $('promo-redeem-msg')
    const code = input?.value?.trim()
    if (!code) {
      if (msgEl) msgEl.textContent = 'Enter a promo code.'
      return
    }
    if (!currentUser?.uid) {
      if (msgEl) msgEl.textContent = 'Sign in first.'
      return
    }
    if (msgEl) msgEl.textContent = 'Redeeming…'
    const btn = $('btn-redeem-promo')
    if (btn) btn.disabled = true
    const res = await sendMsg({ type: 'REDEEM_PROMO', code }, 25000)
    if (btn) btn.disabled = false
    if (res?.ok) {
      if (msgEl) msgEl.textContent = `+${res.credits} credits added!`
      if (input) input.value = ''
      await refreshCreditsUI()
    } else {
      if (msgEl) msgEl.textContent = res?.message || 'Could not redeem code.'
    }
  })
  btnModalUpgrade?.addEventListener('click', openWebsitePricing)
  btnModalActivate?.addEventListener('click', openWebsitePricing)
  btnModalClose?.addEventListener('click', hideUpgradeModal)

  function updateCharCount() {
    charCounter.textContent = `${promptInput.value.length} chars`
  }
  promptInput.addEventListener('input', updateCharCount)

  tabBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      activeTab = btn.dataset.tab
      tabBtns.forEach((b) => b.classList.remove('active'))
      btn.classList.add('active')

      const labels = {
        enhance: ['Your Prompt', 'Enhance Prompt'],
        compress: ['Wordy Prompt', 'Compress Prompt'],
        grammar: ['Draft Prompt', 'Fix Grammar'],
        score: ['Prompt to Analyze', 'Analyze & Score'],
      }
      const [lbl, cta] = labels[activeTab]
      inputLabel.textContent = lbl
      btnText.textContent = cta
      resultBox.style.display = 'none'
    })
  })

  async function handleProcess() {
    const prompt = promptInput.value.trim()
    if (!prompt) return alert('Type a prompt first!')

    if (!currentUser) {
      showAuth()
      return alert('Please sign in with Google on the SnowBear website first.')
    }

    resultBox.style.display = 'none'
    loader.style.display = 'block'
    btnSubmit.disabled = true

    try {
      const t0 = performance.now()
      const { result } = await SB.runActionViaBackground(
        activeTab,
        prompt,
        SB.getBackendUrl(),
        currentUser.uid
      )
      const ms = Math.round(performance.now() - t0)

      const titles = {
        enhance: 'Enhanced Prompt',
        compress: 'Compressed Prompt',
        grammar: 'Grammar Fixed',
        score: 'Prompt Score',
      }

      loader.style.display = 'none'
      resultBox.style.display = 'flex'
      resultType.textContent = `${titles[activeTab]} · ${ms}ms`

      if (activeTab === 'enhance') {
        const parsed = SB.parseEnhanceResponse(result)
        const parts = [`Enhanced Prompt:\n${parsed.enhanced}`]
        if (parsed.assumptions) parts.push(`Assumptions:\n${parsed.assumptions}`)
        if (parsed.suggestions) parts.push(`Suggestions:\n${parsed.suggestions}`)
        resultText.textContent = parts.join('\n\n')
        resultText.dataset.enhancedOnly = parsed.enhanced
      } else if (activeTab === 'score') {
        const parsed = SB.parseScoreResponse(result)
        const parts = []
        if (parsed.score != null) parts.push(`Score: ${parsed.score}/100`)
        if (parsed.breakdown) parts.push(`Breakdown:\n${parsed.breakdown}`)
        if (parsed.weaknesses.length)
          parts.push(`Top Weaknesses:\n${parsed.weaknesses.map((t) => `• ${t}`).join('\n')}`)
        if (parsed.fix) parts.push(`Fix:\n${parsed.fix}`)
        resultText.textContent = parts.join('\n\n') || parsed.raw
        resultText.dataset.enhancedOnly = ''
      } else if (activeTab === 'grammar') {
        resultText.textContent = SB.cleanGrammarOutput(prompt, result)
        resultText.dataset.enhancedOnly = ''
      } else if (activeTab === 'compress') {
        resultText.textContent = SB.cleanCompressOutput(prompt, result)
        resultText.dataset.enhancedOnly = ''
      } else {
        resultText.textContent = SB.cleanOutput(result)
        resultText.dataset.enhancedOnly = ''
      }
    } catch (err) {
      loader.style.display = 'none'
      if (err.usage && !err.usage.allowed) showUpgradeModal(err.usage)
      else alert('Error: ' + err.message)
    } finally {
      btnSubmit.disabled = false
    }
  }

  btnSubmit.addEventListener('click', handleProcess)
  btnCopy.addEventListener('click', () => {
    const txt = resultText.dataset.enhancedOnly || resultText.textContent
    if (!txt) return
    navigator.clipboard.writeText(txt)
    btnCopy.textContent = 'Copied!'
    setTimeout(() => (btnCopy.textContent = 'Copy'), 1200)
  })

  promptInput.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault()
      handleProcess()
    }
  })

  let defaultSitesRendered = false

  function renderDefaultSites() {
    if (defaultSitesRendered || !defaultSitesEl) return
    defaultSitesRendered = true
    defaultSitesEl.innerHTML = ''
    const labels = SB.BLOCKED_SITE_LABELS || []
    labels.forEach((label) => {
      const chip = document.createElement('span')
      chip.className = 'site-chip'
      chip.textContent = label
      defaultSitesEl.appendChild(chip)
    })
  }

  function renderBlockedSites() {
    customSitesList.innerHTML = ''
    blockedWebsites.forEach((site) => {
      const row = document.createElement('div')
      row.className = 'custom-site-item'
      row.innerHTML = `<span>${site}</span><button data-site="${site}">Unblock</button>`
      row.querySelector('button').addEventListener('click', () => {
        blockedWebsites = blockedWebsites.filter((s) => s !== site)
        renderBlockedSites()
      })
      customSitesList.appendChild(row)
    })
  }

  function loadSettingsUI() {
    toggleEnabled.checked = settings.enabled !== false
    const allowed = canUseCustomPrompts(currentUser?.plan)
    toggleAdvanced.checked = allowed && !!settings.advancedMode
    $('custom-enhance').value = allowed
      ? settings.customPrompts?.enhance?.trim() || SB.DEFAULT_CUSTOM_PROMPTS.enhance
      : ''
    $('custom-compress').value = allowed
      ? settings.customPrompts?.compress?.trim() || SB.DEFAULT_CUSTOM_PROMPTS.compress
      : ''
    $('custom-grammar').value = allowed
      ? settings.customPrompts?.grammar?.trim() || SB.DEFAULT_CUSTOM_PROMPTS.grammar
      : ''
    blockedWebsites = [
      ...(settings.blockedWebsites || []),
      ...(settings.customWebsites || []),
    ]
    renderBlockedSites()
    updateAdvancedAccessUI()
  }

  async function saveSettings() {
    const allowed = canUseCustomPrompts(currentUser?.plan)
    settings = {
      enabled: toggleEnabled.checked,
      blockedWebsites: [...blockedWebsites],
      advancedMode: allowed && toggleAdvanced.checked,
      customPrompts: allowed
        ? {
            enhance: $('custom-enhance').value.trim(),
            compress: $('custom-compress').value.trim(),
            grammar: $('custom-grammar').value.trim(),
            score: '',
          }
        : { enhance: '', compress: '', grammar: '', score: '' },
    }
    await chrome.storage.local.set({ snowbear_settings: settings })
    chrome.runtime.sendMessage({ type: 'SYNC_CUSTOM_SCRIPTS' })
    btnSaveSettings.textContent = 'Saved!'
    setTimeout(() => (btnSaveSettings.textContent = 'Save Settings'), 1500)
  }

  toggleAdvanced.addEventListener('click', (e) => {
    if (!canUseCustomPrompts(currentUser?.plan)) {
      e.preventDefault()
      handleAdvancedToggleBlocked()
    }
  })

  toggleAdvanced.addEventListener('change', () => {
    if (!canUseCustomPrompts(currentUser?.plan)) {
      handleAdvancedToggleBlocked()
      return
    }
    advancedPrompts.classList.toggle('hidden', !toggleAdvanced.checked)
    if (toggleAdvanced.checked) {
      if (!$('custom-enhance').value.trim()) $('custom-enhance').value = SB.DEFAULT_CUSTOM_PROMPTS.enhance
      if (!$('custom-compress').value.trim()) $('custom-compress').value = SB.DEFAULT_CUSTOM_PROMPTS.compress
      if (!$('custom-grammar').value.trim()) $('custom-grammar').value = SB.DEFAULT_CUSTOM_PROMPTS.grammar
    }
  })

  advancedToggleRow?.addEventListener('click', (e) => {
    if (canUseCustomPrompts(currentUser?.plan)) return
    if (e.target.closest('.toggle')) return
    handleAdvancedToggleBlocked()
  })

  btnAddSite.addEventListener('click', async () => {
    const site = customSiteInput.value.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '').toLowerCase()
    if (!site || blockedWebsites.includes(site)) return
    if (SB.isBlockedHost(site)) {
      alert('This site is already blocked by default.')
      return
    }

    blockedWebsites.push(site)
    customSiteInput.value = ''
    renderBlockedSites()
    await saveSettings()
    chrome.runtime.sendMessage({ type: 'SYNC_CUSTOM_SCRIPTS' })
  })

  btnSaveSettings.addEventListener('click', saveSettings)

  let settingsLoaded = false

  function ensureSettingsLoaded() {
    if (settingsLoaded) return
    settingsLoaded = true
    chrome.storage.local.get('snowbear_settings', (data) => {
      settings = { ...SB.DEFAULT_SETTINGS, ...(data.snowbear_settings || {}) }
      loadSettingsUI()
    })
  }

  updateCharCount()
  document.querySelector('.tab-btn[data-tab="enhance"]').classList.add('active')
  initAuth()
})()