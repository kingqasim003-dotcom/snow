// SnowBear popup v2.1 — separate signup/login, free daily limit
;(function () {
  if (typeof SnowBearShared === 'undefined' || typeof SnowBearAuth === 'undefined') {
    document.body.innerHTML =
      '<div style="padding:20px;font-family:sans-serif;font-size:13px;color:#334155;">SnowBear failed to load. Please reload the extension at chrome://extensions</div>'
    return
  }

  const SB = SnowBearShared
  const Auth = SnowBearAuth

  const $ = (id) => document.getElementById(id)

  const authScreen = $('auth-screen')
  const appScreen = $('app-screen')
  const authError = $('auth-error')
  const btnGoogleAuth = $('btn-google-auth')
  const usageBadge = $('usage-badge')
  const currentPlanBadge = $('current-plan-badge')
  const btnSettingsSignout = $('btn-settings-signout')
  const btnHeaderUpgrade = $('btn-header-upgrade')
  const btnUpgradeCta = $('btn-upgrade-cta')
  const btnActivatePro = $('btn-activate-pro')
  const upgradeModal = $('upgrade-modal')
  const upgradeModalCount = $('upgrade-modal-count')
  const btnModalUpgrade = $('btn-modal-upgrade')
  const btnModalActivate = $('btn-modal-activate')
  const btnModalClose = $('btn-modal-close')

  const tabBtns = document.querySelectorAll('.tab-btn')
  const promptInput = $('prompt-input')
  const charCounter = $('char-counter')
  const btnSubmit = $('btn-submit')
  const btnText = $('btn-text')
  const loader = $('loader')
  const resultBox = $('result-box')
  const resultType = $('result-type')
  const resultText = $('result-text')
  const btnCopy = $('btn-copy')
  const inputLabel = $('input-label')

  const navTabs = document.querySelectorAll('.nav-tab')
  const sectionTools = $('section-tools')
  const sectionCredits = $('section-credits')
  const sectionSettings = $('section-settings')
  const sectionUpgrade = $('section-upgrade')

  const toggleEnabled = $('toggle-enabled')
  const toggleAdvanced = $('toggle-advanced')
  const advancedPrompts = $('advanced-prompts')
  const customSiteInput = $('custom-site-input')
  const btnAddSite = $('btn-add-site')
  const customSitesList = $('custom-sites-list')
  const defaultSitesEl = $('default-sites')
  const btnSaveSettings = $('btn-save-settings')

  let activeTab = 'enhance'
  let settings = { ...SB.DEFAULT_SETTINGS }
  let customWebsites = []
  let currentUser = null

  function sendMsg(msg, timeoutMs = 0) {
    return new Promise((resolve) => {
      let settled = false
      const finish = (value) => {
        if (settled) return
        settled = true
        resolve(value)
      }
      if (timeoutMs > 0) {
        setTimeout(() => finish({ ok: false, message: 'Request timed out. Reload extension and try again.' }), timeoutMs)
      }
      chrome.runtime.sendMessage(msg, (res) => {
        if (chrome.runtime.lastError) finish(null)
        else finish(res)
      })
    })
  }

  function websiteUrl(path = '') {
    const base =
      typeof WEBSITE_CONFIG !== 'undefined' && WEBSITE_CONFIG.backendUrl
        ? WEBSITE_CONFIG.backendUrl.replace(/\/$/, '')
        : 'https://snowbear.online'
    return `${base}${path}`
  }

  function showAuth() {
    authScreen.classList.remove('hidden')
    appScreen.classList.add('hidden')
    if (authError) authError.textContent = ''
  }

  async function showApp(user) {
    if (!user?.uid) throw new Error('Invalid user session.')
    currentUser = user
    authScreen?.classList.add('hidden')
    appScreen?.classList.remove('hidden')
    sendMsg({ type: 'PULL_REMOTE_PROFILE' })
      .then((pulled) => {
        if (!pulled?.user?.uid) return
        currentUser = pulled.user
        refreshUsageBadge().catch(() => {})
      })
      .catch(() => {})
    try {
      await refreshUsageBadge()
    } catch (_) {}
  }

  function authErrorMsg(err) {
    if (!err) return 'Authentication failed. Please try again.'
    if (typeof err === 'string') return err
    if (err.userMessage) return err.userMessage
    const map = {
      'auth/email-already-in-use': 'This email is already registered. Use the Log In tab.',
      'auth/invalid-email': 'Enter a valid email address.',
      'auth/weak-password': 'Password must be at least 6 characters.',
      'auth/user-not-found': 'No account found. Use Create Account first.',
      'auth/wrong-password': 'Incorrect password.',
      'auth/invalid-credential': 'Wrong email or password. Check your details or create an account.',
      'auth/operation-not-allowed': 'Enable Email/Password in Firebase Console.',
      'auth/too-many-requests': 'Too many attempts. Wait a few minutes.',
      'auth/api-key-invalid': 'Firebase API key blocked. Check Google Cloud Console.',
    }
    return map[err.code] || err.message || 'Authentication failed.'
  }

  function validateCredentials(email, password) {
    if (!email || !password) return 'Enter email and password.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Enter a valid email address.'
    if (password.length < 6) return 'Password must be at least 6 characters.'
    return ''
  }

  async function handleGoogleAuth() {
    if (authError) authError.textContent = ''

    const existing = await sendMsg({ type: 'GET_AUTH' })
    if (existing?.user?.uid) {
      await showApp(existing.user)
      return
    }

    if (btnGoogleAuth) {
      btnGoogleAuth.disabled = true
      btnGoogleAuth.textContent = 'Opening sign-in…'
    }

    try {
      const res = await sendMsg({ type: 'AUTH_OPEN_GOOGLE_SIGNIN' })
      if (!res?.ok) {
        if (authError) {
          authError.textContent =
            res?.message || 'Could not open sign-in. Visit snowbear.online and try again.'
        }
        return
      }

      if (authError) {
        authError.textContent =
          'Complete Google sign-in on snowbear.online in the new tab, then reopen SnowBear — you will be signed in automatically.'
      }
    } catch (e) {
      if (authError) authError.textContent = e.message || 'Could not open website sign-in.'
    } finally {
      if (btnGoogleAuth) {
        btnGoogleAuth.disabled = false
        btnGoogleAuth.innerHTML = '<span>Continue with Google</span>'
      }
    }
  }

  function normalizePlan(plan) {
    if (plan === 'pro') return 'polar'
    if (plan === 'unlimited') return 'unlimited'
    return plan || 'free'
  }

  function canUseCustomPrompts(plan) {
    const p = normalizePlan(plan)
    return p === 'polar' || p === 'unlimited'
  }

  async function getCreditStatus(action) {
    if (!currentUser?.uid) return null
    return sendMsg({ type: 'USAGE_STATUS', uid: currentUser.uid, action })
  }

  async function refreshCreditsUI() {
    const status = await getCreditStatus()
    if (!status) return

    const plan = normalizePlan(status.plan)
    currentUser.plan = plan

    if (currentPlanBadge) {
      const label = status.planLabel || SB.PLANS[plan]?.name || 'Free Plan'
      currentPlanBadge.textContent = label
      currentPlanBadge.classList.remove('plan-badge--polar', 'plan-badge--unlimited')
      if (plan === 'polar') currentPlanBadge.classList.add('plan-badge--polar')
      if (plan === 'unlimited') currentPlanBadge.classList.add('plan-badge--unlimited')
    }

    if (usageBadge) {
      if (plan === 'unlimited') {
        usageBadge.textContent = '∞ Unlimited'
        usageBadge.classList.remove('usage-badge--empty')
      } else {
        const left = status.remaining ?? 0
        usageBadge.textContent = `${left} cr left`
        usageBadge.classList.toggle('usage-badge--empty', left === 0)
      }
    }

    const usedEl = $('credits-used')
    const remEl = $('credits-remaining')
    const planEl = $('credits-plan-label')
    const planExpiryEl = $('credits-plan-expiry')
    const barEl = $('credits-bar-fill')

    if (planEl) planEl.textContent = status.planLabel || SB.PLANS[plan]?.name || 'Free Plan'
    if (planExpiryEl) {
      const exp = currentUser?.planExpiresAt
      if (plan !== 'free' && typeof exp === 'number' && exp > Date.now()) {
        const cycle =
          currentUser?.planBillingCycle === 'yearly'
            ? ' (1 year)'
            : currentUser?.planBillingCycle === 'monthly'
              ? ' (30 days)'
              : ''
        planExpiryEl.textContent = `Active until ${new Date(exp).toLocaleString()}${cycle}`
        planExpiryEl.style.display = 'block'
      } else {
        planExpiryEl.textContent = ''
        planExpiryEl.style.display = 'none'
      }
    }
    if (usedEl) usedEl.textContent = plan === 'unlimited' ? '—' : String(status.used ?? 0)
    if (remEl) remEl.textContent = plan === 'unlimited' ? '∞' : String(status.remaining ?? 0)

    if (barEl && plan !== 'unlimited') {
      const total = status.totalPool || status.limit || 10
      const pct = total > 0 ? Math.min(100, ((status.used || 0) / total) * 100) : 0
      barEl.style.width = `${pct}%`
    } else if (barEl) {
      barEl.style.width = '0%'
    }

    document.querySelectorAll('.plan-card').forEach((c) => c.classList.remove('plan-card--active'))
    const activeCard = $('plan-card-' + plan)
    if (activeCard) activeCard.classList.add('plan-card--active')
  }

  async function refreshUsageBadge() {
    await refreshCreditsUI()
  }

  async function consumeUsage(action) {
    if (!currentUser?.uid) return { allowed: false, message: 'Please sign in first.' }
    const status = await sendMsg({ type: 'USAGE_CONSUME', uid: currentUser.uid, action })
    if (status) await refreshCreditsUI()
    return status || { allowed: false, message: 'Could not check credits.' }
  }

  function showUpgradeModal(status) {
    if (!upgradeModal) return
    const left = status?.remaining ?? 0
    if (upgradeModalCount) upgradeModalCount.textContent = `${left} credits remaining`
    upgradeModal.classList.remove('hidden')
  }

  function hideUpgradeModal() {
    upgradeModal?.classList.add('hidden')
  }

  function openWebsitePricing() {
    window.open(websiteUrl('/pricing'), '_blank')
  }

  function openWebsiteCredits() {
    window.open(websiteUrl('/credits'), '_blank')
  }

  async function initAuth() {
    try {
      const synced = await sendMsg({ type: 'GET_AUTH' })
      if (synced?.user?.uid) {
        await showApp(synced.user)
        return
      }
      const user = await Auth.getCurrentUser()
      if (user?.uid) {
        await showApp(user)
        return
      }
      showAuth()
    } catch (_) {
      showAuth()
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.snowbear_user?.newValue?.uid) return
    showApp(changes.snowbear_user.newValue).catch(() => {})
  })

  btnGoogleAuth?.addEventListener('click', (e) => {
    e.preventDefault()
    handleGoogleAuth()
  })

  async function handleSignOut() {
    await chrome.storage.local.remove(['snowbear_user', 'snowbear_last_sync'])
    await Auth.signOut().catch(() => {})
    currentUser = null
    showAuth()
  }

  btnSettingsSignout?.addEventListener('click', handleSignOut)

  function showSection(name) {
    sectionTools?.classList.toggle('hidden', name !== 'tools')
    sectionCredits?.classList.toggle('hidden', name !== 'credits')
    sectionSettings?.classList.toggle('hidden', name !== 'settings')
    sectionUpgrade?.classList.toggle('hidden', name !== 'upgrade')
    navTabs.forEach((t) => t.classList.toggle('active', t.dataset.section === name))
    if (name === 'credits') refreshCreditsUI()
  }

  navTabs.forEach((tab) => {
    tab.addEventListener('click', () => showSection(tab.dataset.section))
  })

  btnHeaderUpgrade.addEventListener('click', () => showSection('credits'))
  btnUpgradeCta?.addEventListener('click', openWebsitePricing)
  $('btn-plan-polar')?.addEventListener('click', openWebsitePricing)
  $('btn-plan-unlimited')?.addEventListener('click', openWebsitePricing)
  $('btn-buy-credits')?.addEventListener('click', openWebsiteCredits)

  $('btn-redeem-promo')?.addEventListener('click', async () => {
    const input = $('promo-code-input')
    const msgEl = $('promo-redeem-msg')
    const code = input?.value?.trim()
    if (!code) {
      if (msgEl) msgEl.textContent = 'Enter a promo code.'
      return
    }
    if (!currentUser?.uid) {
      if (msgEl) msgEl.textContent = 'Sign in first.'
      return
    }
    if (msgEl) msgEl.textContent = 'Redeeming…'
    const btn = $('btn-redeem-promo')
    if (btn) btn.disabled = true
    const res = await sendMsg({ type: 'REDEEM_PROMO', code }, 25000)
    if (btn) btn.disabled = false
    if (res?.ok) {
      if (msgEl) msgEl.textContent = `+${res.credits} credits added!`
      if (input) input.value = ''
      await refreshCreditsUI()
    } else {
      if (msgEl) msgEl.textContent = res?.message || 'Could not redeem code.'
    }
  })
  btnModalUpgrade?.addEventListener('click', openWebsitePricing)
  btnModalActivate?.addEventListener('click', openWebsitePricing)
  btnModalClose?.addEventListener('click', hideUpgradeModal)

  function updateCharCount() {
    charCounter.textContent = `${promptInput.value.length} chars`
  }
  promptInput.addEventListener('input', updateCharCount)

  tabBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      activeTab = btn.dataset.tab
      tabBtns.forEach((b) => b.classList.remove('active'))
      btn.classList.add('active')

      const labels = {
        enhance: ['Your Prompt', 'Enhance Prompt'],
        compress: ['Wordy Prompt', 'Compress Prompt'],
        grammar: ['Draft Prompt', 'Fix Grammar'],
        score: ['Prompt to Analyze', 'Analyze & Score'],
      }
      const [lbl, cta] = labels[activeTab]
      inputLabel.textContent = lbl
      btnText.textContent = cta
      resultBox.style.display = 'none'
    })
  })

  async function handleProcess() {
    const prompt = promptInput.value.trim()
    if (!prompt) return alert('Type a prompt first!')

    if (!currentUser) {
      showAuth()
      return alert('Please sign in with Google on the SnowBear website first.')
    }

    const usage = await consumeUsage(activeTab)
    if (!usage?.allowed) {
      showUpgradeModal(usage)
      return
    }

    resultBox.style.display = 'none'
    loader.style.display = 'block'
    btnSubmit.disabled = true

    const prompts = SB.buildPrompts(
      settings.advancedMode && canUseCustomPrompts(currentUser?.plan) ? settings.customPrompts : {}
    )

    try {
      const t0 = performance.now()
      const result = await SB.callSnowBearApi(activeTab, prompt, prompts)
      const ms = Math.round(performance.now() - t0)

      const titles = {
        enhance: 'Enhanced Prompt',
        compress: 'Compressed Prompt',
        grammar: 'Grammar Fixed',
        score: 'Prompt Score',
      }

      loader.style.display = 'none'
      resultBox.style.display = 'flex'
      resultType.textContent = `${titles[activeTab]} · ${ms}ms`

      if (activeTab === 'enhance') {
        const parsed = SB.parseEnhanceResponse(result)
        const parts = [`Enhanced Prompt:\n${parsed.enhanced}`]
        if (parsed.assumptions) parts.push(`Assumptions:\n${parsed.assumptions}`)
        if (parsed.suggestions) parts.push(`Suggestions:\n${parsed.suggestions}`)
        resultText.textContent = parts.join('\n\n')
        resultText.dataset.enhancedOnly = parsed.enhanced
      } else if (activeTab === 'score') {
        const parsed = SB.parseScoreResponse(result)
        const parts = []
        if (parsed.score != null) parts.push(`Score: ${parsed.score}/100`)
        if (parsed.breakdown) parts.push(`Breakdown:\n${parsed.breakdown}`)
        if (parsed.weaknesses.length)
          parts.push(`Top Weaknesses:\n${parsed.weaknesses.map((t) => `• ${t}`).join('\n')}`)
        if (parsed.fix) parts.push(`Fix:\n${parsed.fix}`)
        resultText.textContent = parts.join('\n\n') || parsed.raw
        resultText.dataset.enhancedOnly = ''
      } else if (activeTab === 'grammar') {
        resultText.textContent = SB.cleanGrammarOutput(prompt, result)
        resultText.dataset.enhancedOnly = ''
      } else {
        resultText.textContent = SB.cleanOutput(result)
        resultText.dataset.enhancedOnly = ''
      }
    } catch (err) {
      loader.style.display = 'none'
      alert('Error: ' + err.message)
    } finally {
      btnSubmit.disabled = false
    }
  }

  btnSubmit.addEventListener('click', handleProcess)
  btnCopy.addEventListener('click', () => {
    const txt = resultText.dataset.enhancedOnly || resultText.textContent
    if (!txt) return
    navigator.clipboard.writeText(txt)
    btnCopy.textContent = 'Copied!'
    setTimeout(() => (btnCopy.textContent = 'Copy'), 1200)
  })

  promptInput.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault()
      handleProcess()
    }
  })

  function renderDefaultSites() {
    defaultSitesEl.innerHTML = ''
    const seen = new Set()
    SB.DEFAULT_SITES.forEach((s) => {
      if (seen.has(s.label)) return
      seen.add(s.label)
      const chip = document.createElement('span')
      chip.className = 'site-chip'
      chip.textContent = s.label
      defaultSitesEl.appendChild(chip)
    })
  }

  function renderCustomSites() {
    customSitesList.innerHTML = ''
    customWebsites.forEach((site) => {
      const row = document.createElement('div')
      row.className = 'custom-site-item'
      row.innerHTML = `<span>${site}</span><button data-site="${site}">Remove</button>`
      row.querySelector('button').addEventListener('click', () => {
        customWebsites = customWebsites.filter((s) => s !== site)
        renderCustomSites()
      })
      customSitesList.appendChild(row)
    })
  }

  function loadSettingsUI() {
    toggleEnabled.checked = settings.enabled !== false
    toggleAdvanced.checked = !!settings.advancedMode
    advancedPrompts.classList.toggle('hidden', !settings.advancedMode)
    $('custom-enhance').value = settings.customPrompts?.enhance || ''
    $('custom-compress').value = settings.customPrompts?.compress || ''
    $('custom-grammar').value = settings.customPrompts?.grammar || ''
    customWebsites = [...(settings.customWebsites || [])]
    renderCustomSites()
  }

  async function saveSettings() {
    settings = {
      enabled: toggleEnabled.checked,
      customWebsites: [...customWebsites],
      advancedMode: toggleAdvanced.checked,
      customPrompts: {
        enhance: $('custom-enhance').value.trim(),
        compress: $('custom-compress').value.trim(),
        grammar: $('custom-grammar').value.trim(),
        score: '',
      },
    }
    await chrome.storage.local.set({ snowbear_settings: settings })
    chrome.runtime.sendMessage({ type: 'SYNC_CUSTOM_SCRIPTS' })
    btnSaveSettings.textContent = 'Saved!'
    setTimeout(() => (btnSaveSettings.textContent = 'Save Settings'), 1500)
  }

  toggleAdvanced.addEventListener('change', () => {
    advancedPrompts.classList.toggle('hidden', !toggleAdvanced.checked)
  })

  btnAddSite.addEventListener('click', async () => {
    const site = customSiteInput.value.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '').toLowerCase()
    if (!site || customWebsites.includes(site)) return
    if (SB.isBlockedHost(site)) {
      alert('This site is not supported. Use a specific AI chat domain.')
      return
    }

    customWebsites.push(site)
    customSiteInput.value = ''
    renderCustomSites()
    await saveSettings()
    chrome.runtime.sendMessage({ type: 'SYNC_CUSTOM_SCRIPTS' })
  })

  btnSaveSettings.addEventListener('click', saveSettings)

  chrome.storage.local.get('snowbear_settings', (data) => {
    settings = { ...SB.DEFAULT_SETTINGS, ...(data.snowbear_settings || {}) }
    loadSettingsUI()
  })

  renderDefaultSites()
  updateCharCount()
  document.querySelector('.tab-btn[data-tab="enhance"]').classList.add('active')
  initAuth()
})()