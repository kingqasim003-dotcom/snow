// SnowBear credits — monthly allowance, per-action costs, plans
const SnowBearUsage = (function () {
  const CREDIT_COSTS = { enhance: 2, compress: 1, grammar: 1, score: 0 }
  const PLAN_ALLOWANCE = { free: 10, polar: 100, unlimited: Infinity }
  const PLAN_LABELS = { free: 'Free Plan', polar: 'Polar Plan', unlimited: 'Unlimited Plan' }

  function monthKey() {
    return new Date().toISOString().slice(0, 7)
  }

  function normalizePlan(plan) {
    if (plan === 'pro') return 'polar'
    if (plan === 'unlimited' || plan === 'polar' || plan === 'free') return plan
    return 'free'
  }

  async function getUser(uid) {
    const data = await chrome.storage.local.get('snowbear_user')
    const user = data.snowbear_user
    if (!user || user.uid !== uid) return null
    return user
  }

  async function getCreditsRecord(uid) {
    const data = await chrome.storage.local.get('snowbear_credits')
    const all = data.snowbear_credits || {}
    const month = monthKey()
    const entry = all[uid]
    if (!entry || entry.month !== month) {
      return { month, used: 0, purchased: entry?.purchased || 0 }
    }
    return { month: entry.month, used: entry.used || 0, purchased: entry.purchased || 0 }
  }

  async function saveCreditsRecord(uid, record) {
    const data = await chrome.storage.local.get('snowbear_credits')
    const all = data.snowbear_credits || {}
    all[uid] = record
    await chrome.storage.local.set({ snowbear_credits: all })
  }

  async function getStatus(uid, action) {
    if (!uid) {
      return {
        allowed: false,
        plan: 'free',
        used: 0,
        remaining: 0,
        limit: PLAN_ALLOWANCE.free,
        cost: action ? CREDIT_COSTS[action] ?? 0 : 0,
        message: 'Please sign in first.',
      }
    }

    const user = await getUser(uid)
    const plan = normalizePlan(user?.plan)
    const record = await getCreditsRecord(uid)
    const allowance = PLAN_ALLOWANCE[plan]
    const totalPool = plan === 'unlimited' ? Infinity : allowance + record.purchased
    const remaining = plan === 'unlimited' ? Infinity : Math.max(0, totalPool - record.used)
    const cost = action ? CREDIT_COSTS[action] ?? 0 : 0

    if (plan === 'unlimited' || cost === 0) {
      return {
        allowed: true,
        plan,
        planLabel: PLAN_LABELS[plan],
        used: record.used,
        remaining,
        limit: allowance,
        purchased: record.purchased,
        totalPool: plan === 'unlimited' ? '∞' : totalPool,
        cost,
        month: record.month,
        message: '',
      }
    }

    const allowed = remaining >= cost
    return {
      allowed,
      plan,
      planLabel: PLAN_LABELS[plan],
      used: record.used,
      remaining,
      limit: allowance,
      purchased: record.purchased,
      totalPool,
      cost,
      month: record.month,
      message: allowed
        ? ''
        : `Not enough credits. This action needs ${cost} credit${cost > 1 ? 's' : ''}. You have ${remaining} left this month.`,
    }
  }

  async function consume(uid, action = 'enhance') {
    const status = await getStatus(uid, action)
    if (!status.allowed) return { ...status, consumed: false }

    const cost = CREDIT_COSTS[action] ?? 0
    if (status.plan === 'unlimited' || cost === 0) {
      return { ...status, consumed: true }
    }

    const record = await getCreditsRecord(uid)
    record.used += cost
    await saveCreditsRecord(uid, record)

    const refreshed = await getStatus(uid, action)
    return { ...refreshed, consumed: true }
  }

  async function setPlan(uid, plan) {
    if (!uid) return { ok: false, message: 'Not signed in.' }
    const normalized = normalizePlan(plan)
    if (!PLAN_ALLOWANCE[normalized] && normalized !== 'unlimited') {
      return { ok: false, message: 'Invalid plan.' }
    }

    const data = await chrome.storage.local.get('snowbear_user')
    const user = data.snowbear_user
    if (!user || user.uid !== uid) return { ok: false, message: 'User not found.' }

    user.plan = normalized
    user.planActivatedAt = Date.now()
    await chrome.storage.local.set({ snowbear_user: user })
    return { ok: true, plan: normalized, message: `${PLAN_LABELS[normalized]} activated!` }
  }

  async function activatePro(uid) {
    return setPlan(uid, 'unlimited')
  }

  async function addPurchasedCredits(uid, amount = 100) {
    if (!uid) return { ok: false, message: 'Not signed in.' }
    const record = await getCreditsRecord(uid)
    record.purchased = (record.purchased || 0) + amount
    await saveCreditsRecord(uid, record)
    const status = await getStatus(uid)
    return { ok: true, message: `+${amount} credits added!`, status }
  }

  return {
    CREDIT_COSTS,
    PLAN_ALLOWANCE,
    PLAN_LABELS,
    getStatus,
    consume,
    setPlan,
    activatePro,
    addPurchasedCredits,
    FREE_DAILY_LIMIT: 10,
  }
})()