// SnowBear credits — monthly allowance, per-action costs, plans
const SnowBearUsage = (function () {
  const CREDIT_COSTS = { enhance: 2, compress: 1, grammar: 1, score: 0 }
  const PLAN_ALLOWANCE = { free: 10, polar: 100, unlimited: Infinity }
  const PLAN_LABELS = { free: 'Free Plan', polar: 'Polar Plan', unlimited: 'Unlimited Plan' }

  function monthKey() {
    return new Date().toISOString().slice(0, 7)
  }

  function normalizePlan(plan) {
    if (plan === 'pro') return 'polar'
    if (plan === 'unlimited' || plan === 'polar' || plan === 'free') return plan
    return 'free'
  }

  async function getUser(uid) {
    const data = await chrome.storage.local.get('snowbear_user')
    const user = data.snowbear_user
    if (!user || user.uid !== uid) return null
    return user
  }

  function normalizeCreditsEntry(entry) {
    const month = monthKey()
    if (!entry || entry.month !== month) {
      return { month, used: 0, purchased: entry?.purchased || 0 }
    }
    return { month: entry.month, used: entry.used || 0, purchased: entry.purchased || 0 }
  }

  async function loadUserCredits(uid) {
    const data = await chrome.storage.local.get(['snowbear_user', 'snowbear_credits'])
    const user = data.snowbear_user
    if (!user || user.uid !== uid) return null
    const all = data.snowbear_credits || {}
    return {
      user,
      plan: normalizePlan(user.plan),
      record: normalizeCreditsEntry(all[uid]),
      all,
    }
  }

  function buildStatus(plan, record, action) {
    const allowance = PLAN_ALLOWANCE[plan]
    const totalPool = plan === 'unlimited' ? Infinity : allowance + record.purchased
    const remaining = plan === 'unlimited' ? Infinity : Math.max(0, totalPool - record.used)
    const cost = action ? CREDIT_COSTS[action] ?? 0 : 0

    if (plan === 'unlimited' || cost === 0) {
      return {
        allowed: true,
        plan,
        planLabel: PLAN_LABELS[plan],
        used: record.used,
        remaining,
        limit: allowance,
        purchased: record.purchased,
        totalPool: plan === 'unlimited' ? '∞' : totalPool,
        cost,
        month: record.month,
        message: '',
      }
    }

    const allowed = remaining >= cost
    return {
      allowed,
      plan,
      planLabel: PLAN_LABELS[plan],
      used: record.used,
      remaining,
      limit: allowance,
      purchased: record.purchased,
      totalPool,
      cost,
      month: record.month,
      message: allowed
        ? ''
        : `Not enough credits. This action needs ${cost} credit${cost > 1 ? 's' : ''}. You have ${remaining} left this month.`,
    }
  }

  async function getCreditsRecord(uid) {
    const data = await chrome.storage.local.get('snowbear_credits')
    const all = data.snowbear_credits || {}
    return normalizeCreditsEntry(all[uid])
  }

  async function saveCreditsRecord(uid, record) {
    const data = await chrome.storage.local.get('snowbear_credits')
    const all = data.snowbear_credits || {}
    all[uid] = record
    await chrome.storage.local.set({ snowbear_credits: all })
  }

  async function getStatus(uid, action) {
    if (!uid) {
      return {
        allowed: false,
        plan: 'free',
        used: 0,
        remaining: 0,
        limit: PLAN_ALLOWANCE.free,
        cost: action ? CREDIT_COSTS[action] ?? 0 : 0,
        message: 'Please sign in first.',
      }
    }

    const loaded = await loadUserCredits(uid)
    if (!loaded) {
      return {
        allowed: false,
        plan: 'free',
        used: 0,
        remaining: 0,
        limit: PLAN_ALLOWANCE.free,
        cost: action ? CREDIT_COSTS[action] ?? 0 : 0,
        message: 'Please sign in first.',
      }
    }

    return buildStatus(loaded.plan, loaded.record, action)
  }

  async function checkAllowed(uid, action = 'enhance') {
    const status = await getStatus(uid, action)
    return { ...status, consumed: false }
  }

  async function deduct(uid, action = 'enhance') {
    const cost = CREDIT_COSTS[action] ?? 0
    if (!uid || cost === 0) return { ok: true }

    const loaded = await loadUserCredits(uid)
    if (!loaded) return { ok: false, message: 'User not found.' }
    if (loaded.plan === 'unlimited') return { ok: true }

    const record = { ...loaded.record, used: loaded.record.used + cost }
    const all = { ...loaded.all, [uid]: record }
    await chrome.storage.local.set({ snowbear_credits: all })
    return { ok: true, status: buildStatus(loaded.plan, record, action) }
  }

  async function consume(uid, action = 'enhance') {
    const status = await checkAllowed(uid, action)
    if (!status.allowed) return { ...status, consumed: false }

    const cost = CREDIT_COSTS[action] ?? 0
    if (status.plan === 'unlimited' || cost === 0) {
      return { ...status, consumed: true }
    }

    await deduct(uid, action)
    const refreshed = await getStatus(uid, action)
    return { ...refreshed, consumed: true }
  }

  async function setPlan(uid, plan) {
    if (!uid) return { ok: false, message: 'Not signed in.' }
    const normalized = normalizePlan(plan)
    if (!PLAN_ALLOWANCE[normalized] && normalized !== 'unlimited') {
      return { ok: false, message: 'Invalid plan.' }
    }

    const data = await chrome.storage.local.get('snowbear_user')
    const user = data.snowbear_user
    if (!user || user.uid !== uid) return { ok: false, message: 'User not found.' }

    user.plan = normalized
    user.planActivatedAt = Date.now()
    await chrome.storage.local.set({ snowbear_user: user })
    return { ok: true, plan: normalized, message: `${PLAN_LABELS[normalized]} activated!` }
  }

  async function activatePro(uid) {
    return setPlan(uid, 'unlimited')
  }

  async function addPurchasedCredits(uid, amount = 100) {
    if (!uid) return { ok: false, message: 'Not signed in.' }
    const record = await getCreditsRecord(uid)
    record.purchased = (record.purchased || 0) + amount
    await saveCreditsRecord(uid, record)
    const status = await getStatus(uid)
    return { ok: true, message: `+${amount} credits added!`, status }
  }

  return {
    CREDIT_COSTS,
    PLAN_ALLOWANCE,
    PLAN_LABELS,
    getStatus,
    checkAllowed,
    deduct,
    consume,
    setPlan,
    activatePro,
    addPurchasedCredits,
    FREE_DAILY_LIMIT: 10,
  }
})()