// Continuous bidirectional website ↔ extension sync
;(function () {
  if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) return

  const SYNC_KEY = 'snowbear_extension_sync'
  const POLL_MS = 8000

  let timer = null
  let stopped = false

  function contextOk() {
    try {
      return !!chrome.runtime?.id
    } catch (_) {
      return false
    }
  }

  function stopBridge() {
    stopped = true
    if (timer) {
      clearInterval(timer)
      timer = null
    }
  }

  function dispatch(name, detail) {
    try {
      window.dispatchEvent(new CustomEvent(name, { detail }))
    } catch (_) { /* ignore */ }
  }

  function isWorkerMissing(errMessage) {
    const msg = String(errMessage || '').toLowerCase()
    return msg.includes('no sw') || msg.includes('receiving end does not exist')
  }

  function sendToBackground(message, retries = 2) {
    return new Promise((resolve) => {
      if (!contextOk()) {
        resolve(null)
        return
      }

      const attempt = (left) => {
        try {
          chrome.runtime.sendMessage(message, (response) => {
            const err = chrome.runtime.lastError?.message
            if (err) {
              if (left > 0 && isWorkerMissing(err)) {
                setTimeout(() => attempt(left - 1), 300)
                return
              }
              resolve(null)
              return
            }
            resolve(response ?? null)
          })
        } catch (_) {
          if (left > 0) {
            setTimeout(() => attempt(left - 1), 300)
            return
          }
          resolve(null)
        }
      }

      attempt(retries)
    })
  }

  async function pingExtension() {
    const res = await sendToBackground({ type: 'PING' }, 3)
    return !!res?.ok
  }

  async function pullExtensionState() {
    const state = await sendToBackground({ type: 'GET_SYNC_STATE' })
    if (state?.uid) {
      dispatch('snowbear-extension-state', state)
      return true
    }
    return false
  }

  async function pushWebsiteToExtension() {
    try {
      const raw = localStorage.getItem(SYNC_KEY)
      if (!raw) return false
      const payload = JSON.parse(raw)
      if (!payload?.uid) return false
      const res = await sendToBackground({ type: 'SYNC_FROM_WEBSITE', payload })
      if (res?.ok) {
        dispatch('snowbear-extension-synced', res)
        return true
      }
    } catch (_) { /* ignore */ }
    return false
  }

  async function syncCycle() {
    if (stopped || !contextOk()) {
      stopBridge()
      return
    }

    try {
      const alive = await pingExtension()
      if (!alive) {
        dispatch('snowbear-extension-offline')
        return
      }
      await pushWebsiteToExtension()
      await pullExtensionState()
    } catch (_) {
      dispatch('snowbear-extension-offline')
    }
  }

  function safeSync() {
    syncCycle().catch(() => {
      dispatch('snowbear-extension-offline')
    })
  }

  safeSync()
  timer = setInterval(safeSync, POLL_MS)

  window.addEventListener('snowbear-sync-ready', () => {
    pushWebsiteToExtension().catch(() => {})
    safeSync()
  })

  window.addEventListener('snowbear-signed-out', () => {
    sendToBackground({ type: 'AUTH_SIGNOUT' }).catch(() => {})
  })

  function waitForIdToken(ms = 2500) {
    return new Promise((resolve) => {
      const handler = (event) => {
        window.removeEventListener('snowbear-id-token', handler)
        resolve(event.detail || null)
      }
      window.addEventListener('snowbear-id-token', handler)
      window.dispatchEvent(new CustomEvent('snowbear-request-id-token'))
      setTimeout(() => {
        window.removeEventListener('snowbear-id-token', handler)
        resolve(null)
      }, ms)
    })
  }

  try {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (stopped || !contextOk()) {
        stopBridge()
        return
      }
      if (msg?.type === 'GET_WEBSITE_ID_TOKEN') {
        ;(async () => {
          const fresh = await waitForIdToken()
          if (fresh?.idToken) {
            sendResponse({
              idToken: fresh.idToken,
              uid: fresh.uid || null,
              expiresAt: fresh.expiresAt || null,
            })
            return
          }
          try {
            const raw = localStorage.getItem(SYNC_KEY)
            const payload = raw ? JSON.parse(raw) : null
            sendResponse({
              idToken: payload?.idToken || null,
              uid: payload?.uid || null,
            })
          } catch (_) {
            sendResponse({ idToken: null })
          }
        })()
        return true
      }
      if (msg?.type === 'CREDITS_UPDATED' || msg?.type === 'REQUEST_WEBSITE_PULL') {
        pullExtensionState().catch(() => {})
      }
    })
  } catch (_) {
    stopBridge()
  }

  window.addEventListener('beforeunload', stopBridge)

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && !stopped && contextOk()) {
      safeSync()
    }
  })
})()