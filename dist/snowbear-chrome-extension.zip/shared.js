// SnowBear shared utilities — prompts, settings, site matching
;(function (root) {
  const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'
  const MODEL = 'llama-3.1-8b-instant'
  const RATE_LIMIT_PER_KEY = 30
  const NO_FORMAT =
    'Use plain text only. No asterisks, no markdown, no bold, no quotes, no labels.'

  function canUseBackgroundGroq() {
    return typeof chrome !== 'undefined' && typeof chrome.runtime?.sendMessage === 'function'
  }

  function groqTemperature(action) {
    if (action === 'grammar' || action === 'compress') return 0
    if (action === 'score') return 0.1
    if (action === 'enhance') return 0.15
    return 0.2
  }

  function groqMaxTokens(action, prompt) {
    const len = prompt.length
    if (action === 'grammar') return Math.min(1200, Math.max(80, Math.ceil(len / 2.2) + 80))
    if (action === 'compress') return Math.min(700, Math.max(48, Math.ceil(len / 2.8) + 40))
    if (action === 'enhance') return Math.min(900, Math.max(96, Math.ceil(len / 1.8) + 72))
    if (action === 'score') return 96
    return TOKEN_LIMITS[action] || 240
  }

  async function callGroqViaBackground(action, prompt, prompts) {
    const res = await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        {
          type: 'GROQ_COMPLETE',
          userContent: prompts[action](prompt),
          temperature: groqTemperature(action),
          maxTokens: groqMaxTokens(action, prompt),
        },
        (reply) => {
          if (chrome.runtime.lastError) {
            resolve({ error: chrome.runtime.lastError.message })
            return
          }
          resolve(reply || { error: 'No response from SnowBear background.' })
        }
      )
    })
    if (res.error) throw new Error(res.error)
    return res.result || ''
  }

  const DEFAULT_SITES = [
    // Chat & LLM
    { pattern: 'chatgpt.com', label: 'ChatGPT' },
    { pattern: 'chat.openai.com', label: 'ChatGPT' },
    { pattern: 'claude.ai', label: 'Claude' },
    { pattern: 'gemini.google.com', label: 'Gemini' },
    { pattern: 'copilot.microsoft.com', label: 'Copilot' },
    { pattern: 'perplexity.ai', label: 'Perplexity' },
    { pattern: 'chat.deepseek.com', label: 'DeepSeek' },
    { pattern: 'deepseek.com', label: 'DeepSeek' },
    { pattern: 'grok.com', label: 'Grok' },
    { pattern: 'x.com', label: 'Grok / X' },
    { pattern: 'chat.mistral.ai', label: 'Mistral' },
    { pattern: 'poe.com', label: 'Poe' },
    { pattern: 'you.com', label: 'You.com' },
    { pattern: 'pi.ai', label: 'Pi' },
    { pattern: 'chat.qwen.ai', label: 'Qwen' },
    { pattern: 'huggingface.co', label: 'HuggingChat' },
    // Image generation
    { pattern: 'midjourney.com', label: 'Midjourney' },
    { pattern: 'leonardo.ai', label: 'Leonardo' },
    { pattern: 'ideogram.ai', label: 'Ideogram' },
    { pattern: 'firefly.adobe.com', label: 'Adobe Firefly' },
    { pattern: 'canva.com', label: 'Canva' },
    { pattern: 'playground.com', label: 'Playground' },
    { pattern: 'mage.space', label: 'Mage Space' },
    { pattern: 'dream.ai', label: 'Dream.ai' },
    { pattern: 'seaart.ai', label: 'SeaArt' },
    { pattern: 'pixai.art', label: 'PixAI' },
    { pattern: 'recraft.ai', label: 'Recraft' },
    { pattern: 'playground.bfl.ai', label: 'BFL Playground' },
    { pattern: 'openart.ai', label: 'OpenArt' },
    { pattern: 'krea.ai', label: 'Krea' },
    { pattern: 'clipdrop.co', label: 'Clipdrop' },
    // Video generation
    { pattern: 'runwayml.com', label: 'Runway' },
    { pattern: 'pika.art', label: 'Pika' },
    { pattern: 'dream-machine.lumalabs.ai', label: 'Luma Dream Machine' },
    { pattern: 'klingai.com', label: 'Kling AI' },
    { pattern: 'hailuoai.video', label: 'Hailuo AI' },
    { pattern: 'haiper.ai', label: 'Haiper' },
    { pattern: 'pixverse.ai', label: 'PixVerse' },
    { pattern: 'ltx.studio', label: 'LTX Studio' },
    { pattern: 'invideo.io', label: 'InVideo' },
    { pattern: 'heygen.com', label: 'HeyGen' },
    { pattern: 'synthesia.io', label: 'Synthesia' },
    { pattern: 'vidu.com', label: 'Vidu' },
    { pattern: 'flow.google', label: 'Google Flow' },
    { pattern: 'labs.google', label: 'Google Labs' },
    // Audio & music
    { pattern: 'suno.com', label: 'Suno' },
    { pattern: 'udio.com', label: 'Udio' },
    { pattern: 'elevenlabs.io', label: 'ElevenLabs' },
    { pattern: 'murf.ai', label: 'Murf' },
    { pattern: 'play.ht', label: 'Play.ht' },
    // Coding
    { pattern: 'github.com', label: 'GitHub Copilot' },
    { pattern: 'cursor.com', label: 'Cursor' },
    { pattern: 'windsurf.com', label: 'Windsurf' },
    { pattern: 'bolt.new', label: 'Bolt' },
    { pattern: 'lovable.dev', label: 'Lovable' },
    { pattern: 'v0.dev', label: 'v0' },
    { pattern: 'replit.com', label: 'Replit' },
    // Productivity
    { pattern: 'notion.so', label: 'Notion AI' },
    { pattern: 'gamma.app', label: 'Gamma' },
    { pattern: 'tome.app', label: 'Tome' },
    { pattern: 'beautiful.ai', label: 'Beautiful.ai' },
    { pattern: 'napkin.ai', label: 'Napkin' },
    // Other AI platforms
    { pattern: 'character.ai', label: 'Character.ai' },
    { pattern: 'civitai.com', label: 'Civitai' },
    { pattern: 'tensor.art', label: 'Tensor.art' },
    { pattern: 'fal.ai', label: 'fal.ai' },
    { pattern: 'fal.run', label: 'fal.run' },
    { pattern: 'replicate.com', label: 'Replicate' },
    { pattern: 'together.ai', label: 'Together AI' },
    { pattern: 'groq.com', label: 'Groq' },
    { pattern: 'openrouter.ai', label: 'OpenRouter' },
    { pattern: 'cohere.com', label: 'Cohere' },
    { pattern: 'stability.ai', label: 'Stability AI' },
    { pattern: 'blackforestlabs.ai', label: 'Black Forest Labs' },
    { pattern: 'hyperbolic.xyz', label: 'Hyperbolic' },
    { pattern: 'novelai.net', label: 'NovelAI' },
    { pattern: 'janitorai.com', label: 'JanitorAI' },
    { pattern: 'venice.ai', label: 'Venice.ai' },
    { pattern: 'phind.com', label: 'Phind' },
    { pattern: 'consensus.app', label: 'Consensus' },
    { pattern: 'scispace.com', label: 'SciSpace' },
    { pattern: 'aistudio.google.com', label: 'Google AI Studio' },
    { pattern: 'notebooklm.google.com', label: 'NotebookLM' },
  ]

  const PARENT_DOMAIN_EXACT_ONLY = new Set([
    'google.com',
    'youtube.com',
    'facebook.com',
    'instagram.com',
    'spotify.com',
    'tiktok.com',
    'netflix.com',
    'hulu.com',
    'disneyplus.com',
    'primevideo.com',
    'twitch.tv',
  ])

  const DEFAULT_CUSTOM_PROMPTS = {
    enhance: `You are an expert Prompt Engineer. Lightly upgrade the user's prompt so an AI can follow it more reliably — without changing what they want.

Core principle: SAME prompt, CLEARER version. A reader should still recognize the original request.

Do:
1. Keep the user's goal, topic, product, audience, and constraints the same.
2. Clarify vague phrases only where needed.
3. Make the task explicit in the first sentence if buried.
4. Add compact structure only for gaps: Context / Task / Constraints / Output format.
5. Short [Assume: …] only for critical missing details — never a new direction.
6. Same language as the user. Stay about 1.0–1.5× original length.

Never: answer the prompt, invent a different request, or bury the user's words in long roleplay fluff.

STRICT OUTPUT: Output ONLY the enhanced prompt. No commentary.

{{user_input}}`,

    compress: `You are a professional prompt compressor. Reduce tokens while keeping every important requirement.

KEEP: task, role, hard constraints, numbers, names, formats, tone, limits, defining examples.
REMOVE: greetings, filler, repetition, hedging, decorative fluff.
MERGE: duplicate rules into one tight sentence.
NEVER add content or answer the prompt.
Result MUST be shorter in characters than the original.

STRICT OUTPUT: Output ONLY the compressed prompt. No commentary.

{{user_input}}`,

    grammar: `You are a professional grammar and spelling fixer (like Grammarly or a browser grammar checker). Fix ALL language errors.

Fix: spelling, typos, grammar, subject–verb agreement, tense, articles, punctuation, commas, apostrophes, capitalization, spacing, run-ons, fragments.

Preserve meaning, facts, names, numbers, and requirements 100%.
Do NOT enhance style, expand, compress, or answer the prompt.
If already correct, return unchanged. Prefer smallest edits that fully fix every real error.

STRICT OUTPUT: Output ONLY the fully corrected text. No commentary.

{{user_input}}`,

    score: '',
  }

  const DEFAULT_SETTINGS = {
    enabled: true,
    blockedWebsites: [],
    advancedMode: false,
    customPrompts: { ...DEFAULT_CUSTOM_PROMPTS },
  }

  function resolveCustomPrompts(customPrompts = {}) {
    const resolved = { enhance: '', compress: '', grammar: '', score: '' }
    for (const action of Object.keys(resolved)) {
      if (action === 'score') continue
      resolved[action] = customPrompts[action]?.trim() || DEFAULT_CUSTOM_PROMPTS[action] || ''
    }
    return resolved
  }

  const BLOCKED_HOSTS = [
    'translate.google.com',
    'docs.google.com',
    'mail.google.com',
    'drive.google.com',
    'maps.google.com',
    'calendar.google.com',
    'photos.google.com',
    'meet.google.com',
    'www.google.com',
    'google.com',
    'accounts.google.com',
    'youtube.com',
    'www.youtube.com',
    'm.youtube.com',
    'music.youtube.com',
    'youtu.be',
    'netflix.com',
    'www.netflix.com',
    'twitch.tv',
    'www.twitch.tv',
    'disneyplus.com',
    'www.disneyplus.com',
    'hulu.com',
    'www.hulu.com',
    'primevideo.com',
    'www.primevideo.com',
    'spotify.com',
    'open.spotify.com',
    'tiktok.com',
    'www.tiktok.com',
    'instagram.com',
    'www.instagram.com',
    'facebook.com',
    'www.facebook.com',
    'chromewebstore.google.com',
    'chrome.google.com',
  ]

  const BLOCKED_SITE_LABELS = [
    'YouTube',
    'Netflix',
    'Twitch',
    'Spotify',
    'TikTok',
    'Instagram',
    'Facebook',
    'Google Search',
    'Gmail',
    'Maps',
  ]

  const DEFAULT_MATCHES = ['http://*/*', 'https://*/*']

  const TOKEN_LIMITS = { enhance: 900, compress: 700, grammar: 1200, score: 140 }
  const CREDIT_COSTS = { enhance: 2, compress: 1, grammar: 1, score: 0 }
  const PLANS = {
    free: { name: 'Free Plan', credits: 10, price: 'Free', customInstructions: false },
    polar: { name: 'Polar Plan', credits: 100, price: '$4.99/mo', customInstructions: true },
    unlimited: { name: 'Unlimited Plan', credits: Infinity, price: '$20/mo', customInstructions: true },
  }
  const FREE_DAILY_LIMIT = 10

  const BASE_PROMPTS = {
    enhance: (p) =>
      `You are an expert Prompt Engineer. Lightly upgrade this prompt so an AI follows it better — same goal, clearer wording. Do not make it look like a totally different request. Clarify vague parts, make the task explicit, add compact structure only if missing. Keep language and hard requirements. Never answer the prompt.
${NO_FORMAT}
Output ONLY the enhanced prompt.

${p}`,

    compress: (p) =>
      `You are a professional prompt compressor. Keep every important requirement (task, constraints, numbers, names, format). Remove filler, repetition, greetings, and fluff. Merge duplicates. Result MUST be shorter. Never add content. Never answer the prompt.
${NO_FORMAT}
Output ONLY the compressed prompt.

${p}`,

    grammar: (p) =>
      `You are a professional grammar and spelling fixer (like Grammarly). Fix ALL spelling, grammar, punctuation, commas, apostrophes, capitalization, and spacing errors. Preserve meaning and requirements 100%. Do NOT enhance, expand, or rewrite style. If already correct, return unchanged. Do NOT answer the prompt.
${NO_FORMAT}
Output ONLY the fully corrected text.

${p}`,

    score: (p) =>
      `Score prompt quality 0-100. Be strict and realistic. ${NO_FORMAT}\nScore: X/100\nBreakdown:\n- Clarity: X/20\n- Specificity: X/20\n- Context: X/20\n- Structure: X/20\n- Output Definition: X/20\nTop 2 weaknesses:\n- w1\n- w2\nOne-line fix suggestion: tip\n\n${p}`,
  }

  function buildPrompts(customPrompts = {}, options = {}) {
    const useCustom = options.useCustom === true
    const resolvedCustom = useCustom ? resolveCustomPrompts(customPrompts) : customPrompts
    const prompts = {}
    for (const action of Object.keys(BASE_PROMPTS)) {
      // Score always uses the built-in honest evaluator — no custom override
      if (action === 'score') {
        prompts[action] = BASE_PROMPTS[action]
        continue
      }
      const custom = useCustom
        ? resolvedCustom[action]?.trim()
        : customPrompts[action]?.trim()
      if (custom) {
        prompts[action] = (p) =>
          custom
            .replace(/\{\{user_input\}\}/gi, p)
            .replace(/\{\{prompt\}\}/gi, p)
            .replace(/\{\{PROMPT\}\}/g, p)
      } else {
        prompts[action] = BASE_PROMPTS[action]
      }
    }
    return prompts
  }

  function cleanOutput(text) {
    return text
      .replace(/\*+/g, '')
      .replace(/_{2,}/g, '')
      .replace(/^#+\s*/gm, '')
      .replace(/^>\s*/gm, '')
      .replace(/```[\s\S]*?```/g, '')
      .replace(/^["'`]+|["'`]+$/g, '')
      .replace(/^(enhanced|compressed|corrected)\s+prompt\s*:?\s*/i, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim()
  }

  function stripGrammarCommentary(text) {
    return text
      .split(
        /\n{2,}(?:Note|Notes|Explanation|Changes(?:\s+made)?|Here(?:'s| is)|I\s+(?:fixed|corrected|changed)|Summary|Suggestions?)\s*:/i
      )[0]
      .replace(/^(?:Here(?:'s| is)\s+(?:the\s+)?(?:corrected|fixed)\s+(?:version|text|prompt)\s*:?\s*)/i, '')
      .trim()
  }

  function cleanCompressOutput(original, result) {
    const cleaned = cleanOutput(result)
    const orig = original.trim()
    if (!orig) return cleaned
    return cleaned.length < orig.length ? cleaned : orig
  }

  function cleanGrammarOutput(original, result) {
    let text = stripGrammarCommentary(cleanOutput(result))
    text = text
      .replace(
        /^(corrected(?:\s+text)?|fixed(?:\s+text)?|grammar[_\s-]?fixed|here(?:'s| is)\s+(?:the\s+)?(?:corrected|fixed)\s+(?:version|text|prompt))[:\s-]*/i,
        ''
      )
      .trim()
    const orig = original.trim()
    if (!orig) return text
    if (!text) return orig

    // Allow real grammar/punctuation fixes; only block answer-style rewrites
    if (text.length > orig.length * 2.2) return orig
    if (text.length < orig.length * 0.45 && orig.length > 40) return orig

    const origWords = orig.toLowerCase().split(/\s+/).filter(Boolean)
    const outWords = text.toLowerCase().split(/\s+/).filter(Boolean)
    if (origWords.length >= 4 && outWords.length >= 2) {
      const origSet = new Set(origWords.filter((w) => w.length > 2))
      let overlap = 0
      for (const w of outWords) {
        if (w.length > 2 && origSet.has(w)) overlap += 1
      }
      if (overlap / Math.max(1, origSet.size) < 0.25) return orig
    }
    return text
  }

  function parseEnhanceResponse(raw) {
    const text = raw.trim()
    const enhancedMatch = text.match(
      /-?\s*Enhanced Prompt:\s*([\s\S]*?)(?=-?\s*Assumptions\s*\(if any\):|$)/i
    )
    const assumptionsMatch = text.match(
      /-?\s*Assumptions\s*\(if any\):\s*([\s\S]*?)(?=-?\s*Suggestions for better results:|$)/i
    )
    const suggestionsMatch = text.match(/-?\s*Suggestions for better results:\s*([\s\S]*?)$/i)

    const enhanced = enhancedMatch?.[1]?.trim()
    if (!enhanced) {
      // Current enhance prompt outputs ONLY the rewritten prompt, no headers —
      // this is the normal path now. Kept the header-aware parse above for
      // resilience in case a custom prompt or the model still emits one.
      return { enhanced: cleanOutput(text), assumptions: '', suggestions: '' }
    }

    return {
      enhanced: cleanOutput(enhanced),
      assumptions: cleanOutput(assumptionsMatch?.[1]?.trim() || ''),
      suggestions: cleanOutput(suggestionsMatch?.[1]?.trim() || ''),
    }
  }

  function parseScoreResponse(raw) {
    const text = raw.trim()
    const scoreMatch = text.match(/Score:\s*(\d+)/i)
    const breakdownMatch = text.match(/Breakdown:\s*([\s\S]*?)(?=Top 2 weaknesses:|$)/i)
    const weaknessesMatch = text.match(
      /Top 2 weaknesses:\s*([\s\S]*?)(?=One-line fix suggestion:?|$)/i
    )
    const fixMatch = text.match(/One-line fix suggestion:?\s*([\s\S]*)$/i)

    const weaknesses = (weaknessesMatch?.[1] || '')
      .split('\n')
      .map((l) => l.replace(/^[-•]\s*/, '').trim())
      .filter(Boolean)

    return {
      score: scoreMatch ? Math.min(100, parseInt(scoreMatch[1], 10)) : null,
      breakdown: breakdownMatch?.[1]?.trim() || '',
      weaknesses,
      fix: cleanOutput(fixMatch?.[1]?.trim() || ''),
      raw: text,
    }
  }

  function hostMatches(hostname, pattern) {
    const h = hostname.toLowerCase()
    const p = pattern.toLowerCase().trim()
    if (!p) return false
    if (p.startsWith('*.')) return h === p.slice(2) || h.endsWith('.' + p.slice(2))
    return h === p || h.endsWith('.' + p)
  }

  function isKnownAiHost(hostname) {
    const h = hostname.toLowerCase()
    return DEFAULT_SITES.some((s) => hostMatches(h, s.pattern))
  }

  function isBlockedHost(hostname) {
    const h = hostname.toLowerCase()
    if (isKnownAiHost(h)) return false
    return BLOCKED_HOSTS.some((b) => {
      if (PARENT_DOMAIN_EXACT_ONLY.has(b)) return h === b
      return h === b || h.endsWith('.' + b)
    })
  }

  function isSiteAllowed(hostname, settings = DEFAULT_SETTINGS) {
    if (!settings.enabled) return false
    if (isBlockedHost(hostname)) return false
    const extraBlocked = [
      ...(settings.blockedWebsites || []),
      ...(settings.customWebsites || []),
    ]
    if (extraBlocked.some((p) => hostMatches(hostname, p))) return false
    return true
  }

  function getChatId() {
    const path = location.pathname + location.search
    const hash = location.hash
    const m =
      path.match(/\/c\/([a-zA-Z0-9-]+)/) ||
      path.match(/\/chat\/([a-zA-Z0-9-]+)/) ||
      hash.match(/#([a-zA-Z0-9-]+)/)
    return m ? m[1] : location.hostname + path.split('?')[0]
  }

  const DEFAULT_BACKEND_URL = 'https://www.snowbear.online'

  function getBackendUrl() {
    if (typeof WEBSITE_CONFIG !== 'undefined' && WEBSITE_CONFIG.backendUrl) {
      return WEBSITE_CONFIG.backendUrl.replace(/\/$/, '')
    }
    return DEFAULT_BACKEND_URL
  }

  function formatScoreApiResponse(data) {
    const suggestions = Array.isArray(data?.suggestions) ? data.suggestions : []
    const weaknesses = suggestions.slice(0, 2)
    return [
      `Score: ${data.score}/100`,
      'Breakdown:',
      `- Clarity: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Specificity: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Context: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Structure: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Output Definition: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      'Top 2 weaknesses:',
      ...weaknesses.map((item) => `- ${item}`),
      `One-line fix suggestion: ${suggestions[0] || 'Add clearer context and output format.'}`,
    ].join('\n')
  }

  function hasExtensionGroqKeys() {
    return (
      typeof GROQ_CONFIG !== 'undefined' &&
      Array.isArray(GROQ_CONFIG.apiKeys) &&
      GROQ_CONFIG.apiKeys.length > 0
    )
  }

  function formatActionResult(action, data) {
    if (action === 'score') return formatScoreApiResponse(data || {})
    return data?.result || ''
  }

  async function runActionViaBackground(action, prompt, backend, uid) {
    const res = await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: 'RUN_ACTION', action, prompt, backend, uid },
        (reply) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: chrome.runtime.lastError.message })
            return
          }
          resolve(reply || { ok: false, error: 'No response from SnowBear background.' })
        }
      )
    })

    if (!res.ok) {
      const err = new Error(res.error || res.usage?.message || 'Action failed.')
      err.status = res.status
      err.usage = res.usage
      throw err
    }

    return {
      result: formatActionResult(action, res.data),
      usage: res.usage,
    }
  }

  async function callWebsiteApiViaBackground(action, prompt, backend) {
    const res = await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: 'WEBSITE_API', action, prompt, backend },
        (reply) => {
          if (chrome.runtime.lastError) {
            resolve({ error: chrome.runtime.lastError.message })
            return
          }
          resolve(reply || { error: 'No response from SnowBear background.' })
        }
      )
    })
    if (res.error) {
      const err = new Error(res.error)
      err.status = res.status
      throw err
    }
    const data = res.data || {}
    if (action === 'score') return formatScoreApiResponse(data)
    return data.result || ''
  }

  async function callWebsiteApi(action, prompt, backend) {
    // Content scripts on ChatGPT etc. cannot fetch snowbear.online (CORS) — use background worker.
    if (canUseBackgroundGroq()) {
      return callWebsiteApiViaBackground(action, prompt, backend)
    }

    const endpoint = action === 'score' ? 'score' : action
    const res = await fetch(`${backend}/api/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    })

    if (!res.ok) {
      let detail = ''
      try {
        detail = (await res.json())?.error || ''
      } catch (_) {}
      const err = new Error(detail || `SnowBear server error ${res.status}`)
      err.status = res.status
      throw err
    }

    const data = await res.json()
    if (action === 'score') return formatScoreApiResponse(data)
    return data.result || ''
  }

  async function callSnowBearApi(action, prompt, prompts) {
    const backend = getBackendUrl()
    const errors = []

    // Prefer website API — Groq keys belong on the server (Vercel), not in the public extension.
    if (backend) {
      try {
        return await callWebsiteApi(action, prompt, backend)
      } catch (err) {
        errors.push(err?.message || String(err))
        const shouldRetryLocal =
          canUseBackgroundGroq() &&
          hasExtensionGroqKeys() &&
          (err?.status >= 500 || err?.status === 429)
        if (shouldRetryLocal) {
          try {
            return await callGroq(action, prompt, prompts)
          } catch (localErr) {
            errors.push(localErr?.message || String(localErr))
          }
        }
      }
    }

    if (hasExtensionGroqKeys() && canUseBackgroundGroq()) {
      try {
        return await callGroq(action, prompt, prompts)
      } catch (err) {
        errors.push(err?.message || String(err))
      }
    }

    if (!backend && canUseBackgroundGroq() && hasExtensionGroqKeys()) {
      try {
        return await callGroq(action, prompt, prompts)
      } catch (err) {
        errors.push(err?.message || String(err))
      }
    }

    const hint = errors.find(
      (m) =>
        m.includes('GROQ') ||
        m.includes('Groq') ||
        m.includes('configured') ||
        m.includes('invalid') ||
        m.includes('Invalid API')
    )
    throw new Error(
      hint ||
        errors[0] ||
        'AI unavailable. Add valid GROQ_API_KEYS in Vercel (snowbear.online project settings).'
    )
  }

  async function callGroq(action, prompt, prompts) {
    if (canUseBackgroundGroq()) {
      return callGroqViaBackground(action, prompt, prompts)
    }
    throw new Error('Groq service unavailable. Reload the SnowBear extension.')
  }

  const api = {
    GROQ_URL,
    MODEL,
    RATE_LIMIT_PER_KEY,
    NO_FORMAT,
    DEFAULT_SITES,
    DEFAULT_SETTINGS,
    DEFAULT_CUSTOM_PROMPTS,
    resolveCustomPrompts,
    BLOCKED_HOSTS,
    BLOCKED_SITE_LABELS,
    DEFAULT_MATCHES,
    isBlockedHost,
    isKnownAiHost,
    PARENT_DOMAIN_EXACT_ONLY,
    TOKEN_LIMITS,
    CREDIT_COSTS,
    PLANS,
    FREE_DAILY_LIMIT,
    BASE_PROMPTS,
    buildPrompts,
    cleanOutput,
    cleanCompressOutput,
    cleanGrammarOutput,
    parseEnhanceResponse,
    parseScoreResponse,
    hostMatches,
    isSiteAllowed,
    getChatId,
    callGroq,
    callSnowBearApi,
    runActionViaBackground,
    formatActionResult,
    formatScoreApiResponse,
    getBackendUrl,
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api
  } else {
    root.SnowBearShared = api
  }
})(typeof globalThis !== 'undefined' ? globalThis : window)
