// SnowBear shared utilities — prompts, settings, site matching
;(function (root) {
  const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'
  const MODEL = 'llama-3.1-8b-instant'
  const RATE_LIMIT_PER_KEY = 30
  const NO_FORMAT =
    'Use plain text only. No asterisks, no markdown, no bold, no quotes, no labels.'

  function canUseBackgroundGroq() {
    return typeof chrome !== 'undefined' && typeof chrome.runtime?.sendMessage === 'function'
  }

  function groqTemperature(action) {
    if (action === 'grammar') return 0
    if (action === 'score') return 0.1
    return 0.2
  }

  function groqMaxTokens(action, prompt) {
    if (action === 'grammar') {
      return Math.min(TOKEN_LIMITS.grammar, Math.ceil(prompt.length / 3) + 20)
    }
    return TOKEN_LIMITS[action] || 300
  }

  async function callGroqViaBackground(action, prompt, prompts) {
    const res = await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        {
          type: 'GROQ_COMPLETE',
          userContent: prompts[action](prompt),
          temperature: groqTemperature(action),
          maxTokens: groqMaxTokens(action, prompt),
        },
        (reply) => {
          if (chrome.runtime.lastError) {
            resolve({ error: chrome.runtime.lastError.message })
            return
          }
          resolve(reply || { error: 'No response from SnowBear background.' })
        }
      )
    })
    if (res.error) throw new Error(res.error)
    return res.result || ''
  }

  const DEFAULT_SITES = [
    { pattern: 'chatgpt.com', label: 'ChatGPT' },
    { pattern: 'chat.openai.com', label: 'ChatGPT' },
    { pattern: 'grok.com', label: 'Grok' },
    { pattern: 'x.com', label: 'Grok / X' },
    { pattern: 'claude.ai', label: 'Claude' },
    { pattern: 'gemini.google.com', label: 'Gemini' },
    { pattern: 'perplexity.ai', label: 'Perplexity' },
    { pattern: 'copilot.microsoft.com', label: 'Copilot' },
    { pattern: 'poe.com', label: 'Poe' },
    { pattern: 'you.com', label: 'You.com' },
    { pattern: 'deepseek.com', label: 'DeepSeek' },
  ]

  const DEFAULT_SETTINGS = {
    enabled: true,
    customWebsites: [],
    advancedMode: false,
    customPrompts: { enhance: '', compress: '', grammar: '', score: '' },
  }

  const BLOCKED_HOSTS = [
    'translate.google.com',
    'docs.google.com',
    'mail.google.com',
    'drive.google.com',
    'maps.google.com',
    'www.google.com',
    'google.com',
    'accounts.google.com',
  ]

  const DEFAULT_MATCHES = [
    'https://chatgpt.com/*',
    'https://chat.openai.com/*',
    'https://grok.com/*',
    'https://x.com/*',
    'https://twitter.com/*',
    'https://claude.ai/*',
    'https://gemini.google.com/*',
    'https://perplexity.ai/*',
    'https://copilot.microsoft.com/*',
    'https://poe.com/*',
    'https://you.com/*',
    'https://deepseek.com/*',
    'https://www.deepseek.com/*',
  ]

  const TOKEN_LIMITS = { enhance: 700, compress: 320, grammar: 200, score: 280 }
  const CREDIT_COSTS = { enhance: 2, compress: 1, grammar: 1, score: 0 }
  const PLANS = {
    free: { name: 'Free Plan', credits: 10, price: 'Free', customInstructions: false },
    polar: { name: 'Polar Plan', credits: 100, price: '$4.99/mo', customInstructions: true },
    unlimited: { name: 'Unlimited Plan', credits: Infinity, price: '$20/mo', customInstructions: true },
  }
  const FREE_DAILY_LIMIT = 10

  const BASE_PROMPTS = {
    enhance: (p) =>
      `You are a senior prompt engineer. Rewrite the prompt below into a clearer, more specific, and professional version — preserving its original goal and intent completely.

Improve:
- Clarity: remove ambiguity, vague pronouns, and unclear references
- Structure: organize into logical order (context → task → constraints → output format)
- Missing pieces: add any obviously missing context, constraints, audience, tone, or success criteria that the original implies but doesn't state
- Specificity: replace vague verbs/asks ("help with", "make better") with concrete, actionable instructions
- Tone: professional, precise, no filler words
- Output requirements: explicitly state the expected format, length, and style of the final output if implied

Rules:
- Do NOT change the core goal or intent of the original prompt
- Do NOT invent new requirements unrelated to the original ask
- Do NOT add explanation, notes, or commentary
- Output ONLY the rewritten prompt — nothing else
- ${NO_FORMAT}

PROMPT TO ENHANCE:
"""
${p}
"""`,

    compress: (p) =>
      `You are an advanced prompt compressor. Rewrite the prompt below into a tighter, smarter version that fully preserves its purpose and intent.

Rules:
- Identify the core goal — every line you keep must serve that goal
- Cut repeated ideas, restated points, and low-value filler (even if not literally duplicate wording)
- Merge overlapping instructions into one clear instruction
- Do NOT add new context, assumptions, or requirements
- Do NOT lose any instruction that affects the outcome — only remove what's redundant or non-essential
- If two parts say the same thing differently, keep only the clearest one
- Output ONLY the compressed prompt, no explanation
- ${NO_FORMAT}

PROMPT TO COMPRESS:
"""
${p}
"""`,

    grammar: (p) =>
      `You are a universal grammar-correction engine. Fix every grammar, spelling, and punctuation mistake in the text below and tidy the wording just enough to sound professional.

STRICT RULES — follow exactly:
- Only fix grammar, spelling, and punctuation errors
- You may adjust wording only as needed to sound professional — never to add meaning
- Do NOT add new words, sentences, details, or explanations
- Do NOT expand, summarize, or enhance for style beyond correcting errors
- Do NOT change the meaning, intent, or tone
- Keep nearly the same length (only fix errors)
- Output ONLY the corrected text — no quotes, no preamble, no notes
- ${NO_FORMAT}

Text to fix:
${p}`,

    score: (p) =>
      `You are a strict, honest prompt evaluator. Score the prompt below out of 100. Do NOT inflate the score — be critical and realistic.

Score across these categories (give points for each, then total):
- Clarity (0-20): Is the ask unambiguous?
- Specificity (0-20): Concrete details vs vague language?
- Context (0-20): Enough background/constraints given?
- Structure (0-20): Logically organized, easy to parse?
- Output Definition (0-20): Is the desired output format/result clearly stated?

Do not add praise, encouragement, or unrelated commentary.
${NO_FORMAT}

Output format:
Score: X/100
Breakdown:
- Clarity: X/20
- Specificity: X/20
- Context: X/20
- Structure: X/20
- Output Definition: X/20
Top 2 weaknesses:
- weakness1
- weakness2
One-line fix suggestion: suggestion

PROMPT TO SCORE:
"""
${p}
"""`,
  }

  function buildPrompts(customPrompts = {}) {
    const prompts = {}
    for (const action of Object.keys(BASE_PROMPTS)) {
      // Score always uses the built-in honest evaluator — no custom override
      if (action === 'score') {
        prompts[action] = BASE_PROMPTS[action]
        continue
      }
      const custom = customPrompts[action]?.trim()
      if (custom) {
        prompts[action] = (p) => custom.replace(/\{\{prompt\}\}/g, p).replace(/\{\{PROMPT\}\}/g, p)
      } else {
        prompts[action] = BASE_PROMPTS[action]
      }
    }
    return prompts
  }

  function cleanOutput(text) {
    return text
      .replace(/\*+/g, '')
      .replace(/_{2,}/g, '')
      .replace(/^#+\s*/gm, '')
      .replace(/^>\s*/gm, '')
      .replace(/```[\s\S]*?```/g, '')
      .replace(/^["'`]+|["'`]+$/g, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim()
  }

  function cleanGrammarOutput(original, result) {
    const text = cleanOutput(result)
    if (text.length > original.length * 1.2) return cleanOutput(original)
    return text
  }

  function parseEnhanceResponse(raw) {
    const text = raw.trim()
    const enhancedMatch = text.match(
      /-?\s*Enhanced Prompt:\s*([\s\S]*?)(?=-?\s*Assumptions\s*\(if any\):|$)/i
    )
    const assumptionsMatch = text.match(
      /-?\s*Assumptions\s*\(if any\):\s*([\s\S]*?)(?=-?\s*Suggestions for better results:|$)/i
    )
    const suggestionsMatch = text.match(/-?\s*Suggestions for better results:\s*([\s\S]*?)$/i)

    const enhanced = enhancedMatch?.[1]?.trim()
    if (!enhanced) {
      // Current enhance prompt outputs ONLY the rewritten prompt, no headers —
      // this is the normal path now. Kept the header-aware parse above for
      // resilience in case a custom prompt or the model still emits one.
      return { enhanced: cleanOutput(text), assumptions: '', suggestions: '' }
    }

    return {
      enhanced: cleanOutput(enhanced),
      assumptions: cleanOutput(assumptionsMatch?.[1]?.trim() || ''),
      suggestions: cleanOutput(suggestionsMatch?.[1]?.trim() || ''),
    }
  }

  function parseScoreResponse(raw) {
    const text = raw.trim()
    const scoreMatch = text.match(/Score:\s*(\d+)/i)
    const breakdownMatch = text.match(/Breakdown:\s*([\s\S]*?)(?=Top 2 weaknesses:|$)/i)
    const weaknessesMatch = text.match(
      /Top 2 weaknesses:\s*([\s\S]*?)(?=One-line fix suggestion:?|$)/i
    )
    const fixMatch = text.match(/One-line fix suggestion:?\s*([\s\S]*)$/i)

    const weaknesses = (weaknessesMatch?.[1] || '')
      .split('\n')
      .map((l) => l.replace(/^[-•]\s*/, '').trim())
      .filter(Boolean)

    return {
      score: scoreMatch ? Math.min(100, parseInt(scoreMatch[1], 10)) : null,
      breakdown: breakdownMatch?.[1]?.trim() || '',
      weaknesses,
      fix: cleanOutput(fixMatch?.[1]?.trim() || ''),
      raw: text,
    }
  }

  function hostMatches(hostname, pattern) {
    const h = hostname.toLowerCase()
    const p = pattern.toLowerCase().trim()
    if (!p) return false
    if (p.startsWith('*.')) return h === p.slice(2) || h.endsWith('.' + p.slice(2))
    return h === p || h.endsWith('.' + p)
  }

  function isBlockedHost(hostname) {
    const h = hostname.toLowerCase()
    return BLOCKED_HOSTS.some((b) => h === b || h.endsWith('.' + b))
  }

  function isSiteAllowed(hostname, settings = DEFAULT_SETTINGS) {
    if (!settings.enabled) return false
    if (isBlockedHost(hostname)) return false
    const allSites = [...DEFAULT_SITES.map((s) => s.pattern), ...(settings.customWebsites || [])]
    return allSites.some((p) => hostMatches(hostname, p))
  }

  function getChatId() {
    const path = location.pathname + location.search
    const hash = location.hash
    const m =
      path.match(/\/c\/([a-zA-Z0-9-]+)/) ||
      path.match(/\/chat\/([a-zA-Z0-9-]+)/) ||
      hash.match(/#([a-zA-Z0-9-]+)/)
    return m ? m[1] : location.hostname + path.split('?')[0]
  }

  function getBackendUrl() {
    if (typeof WEBSITE_CONFIG !== 'undefined' && WEBSITE_CONFIG.backendUrl) {
      return WEBSITE_CONFIG.backendUrl.replace(/\/$/, '')
    }
    return null
  }

  function formatScoreApiResponse(data) {
    const suggestions = Array.isArray(data?.suggestions) ? data.suggestions : []
    const weaknesses = suggestions.slice(0, 2)
    return [
      `Score: ${data.score}/100`,
      'Breakdown:',
      `- Clarity: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Specificity: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Context: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Structure: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      `- Output Definition: ${Math.min(20, Math.round((data.score || 0) * 0.2))}/20`,
      'Top 2 weaknesses:',
      ...weaknesses.map((item) => `- ${item}`),
      `One-line fix suggestion: ${suggestions[0] || 'Add clearer context and output format.'}`,
    ].join('\n')
  }

  async function callSnowBearApi(action, prompt, prompts) {
    const backend = getBackendUrl()
    if (!backend) return callGroq(action, prompt, prompts)

    const endpoint = action === 'score' ? 'score' : action
    const res = await fetch(`${backend}/api/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    })

    if (!res.ok) {
      let detail = ''
      try {
        detail = (await res.json())?.error || ''
      } catch (_) {}
      throw new Error(detail || `SnowBear server error ${res.status}`)
    }

    const data = await res.json()
    if (action === 'score') return formatScoreApiResponse(data)
    return data.result || ''
  }

  async function callGroq(action, prompt, prompts) {
    if (canUseBackgroundGroq()) {
      return callGroqViaBackground(action, prompt, prompts)
    }
    throw new Error('Groq service unavailable. Reload the SnowBear extension.')
  }

  const api = {
    GROQ_URL,
    MODEL,
    RATE_LIMIT_PER_KEY,
    NO_FORMAT,
    DEFAULT_SITES,
    DEFAULT_SETTINGS,
    BLOCKED_HOSTS,
    DEFAULT_MATCHES,
    isBlockedHost,
    TOKEN_LIMITS,
    CREDIT_COSTS,
    PLANS,
    FREE_DAILY_LIMIT,
    BASE_PROMPTS,
    buildPrompts,
    cleanOutput,
    cleanGrammarOutput,
    parseEnhanceResponse,
    parseScoreResponse,
    hostMatches,
    isSiteAllowed,
    getChatId,
    callGroq,
    callSnowBearApi,
    getBackendUrl,
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api
  } else {
    root.SnowBearShared = api
  }
})(typeof globalThis !== 'undefined' ? globalThis : window)
