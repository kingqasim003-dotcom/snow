// SnowBear v2.0 — auth-gated, site-aware, context-persistent prompt tools
;(function () {
  const SB = SnowBearShared
  const BEAR_URL = chrome.runtime.getURL('bear-prompt.png')
  const ICON_URL = chrome.runtime.getURL('icon.png')

  const INPUT_SELECTORS = [
    '#prompt-textarea',
    'textarea[data-testid="prompt-textarea"]',
    'div#prompt-textarea[contenteditable="true"]',
    'div.ProseMirror[contenteditable="true"]',
    'div[contenteditable="true"][data-placeholder]',
    'div[contenteditable="true"][role="textbox"]',
    'rich-textarea textarea',
    'textarea[placeholder]',
    'textarea',
    'div[contenteditable="true"]',
  ]

  const PLUS_SELECTORS = [
    'button[data-testid="composer-plus-btn"]',
    'button[aria-label="Add files and more"]',
    'button[aria-label*="Attach"]',
    'button[aria-label*="Add"]',
    'button[aria-label*="Upload"]',
    'button.composer-btn',
  ]

  const FOOTER_SELECTORS = [
    '[data-testid="composer-footer-actions"]',
    '[data-testid="composer-footer"]',
    'div[class*="composer-footer"]',
    'div[class*="input-footer"]',
    'div[class*="toolbar"]',
  ]

  const ICONS = {
    enhance: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8L12 3z"/><path d="M19 14l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9.9-2.1z"/></svg>`,
    compress: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 9H4V5"/><path d="M4 9l4-4"/><path d="M16 15h4v4"/><path d="M20 15l-4 4"/><path d="M16 9h4V5"/><path d="M20 9l-4-4"/><path d="M8 15H4v4"/><path d="M4 15l4 4"/></svg>`,
    grammar: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16"/><path d="M6 16l6-10 6 10"/><path d="M8.5 12h7"/></svg>`,
    score: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h16"/><path d="M6 17V9"/><path d="M10 17V5"/><path d="M14 17v-6"/><path d="M18 17v-3"/></svg>`,
  }

  const TOOLS = [
    { action: 'enhance', label: 'Enhance', desc: 'Optimize prompt' },
    { action: 'compress', label: 'Compress', desc: 'Save tokens' },
    { action: 'grammar', label: 'Fix Grammar', desc: 'Grammar only' },
    { action: 'score', label: 'Score', desc: 'Honest 0–100' },
  ]

  let wrap = null
  let menuOpen = false
  let busy = false
  let abortCtrl = null
  let authenticated = false
  let settings = { ...SB.DEFAULT_SETTINGS }
  let prompts = SB.buildPrompts()
  let currentChatId = SB.getChatId()
  let contextRestored = false
  let saveTimer = null
  let pulseTimer = null
  let boundInput = null

  function storageGet(keys) {
    return new Promise((resolve) => chrome.storage.local.get(keys, resolve))
  }

  function sendMsg(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (res) => {
          if (chrome.runtime.lastError) resolve(null)
          else resolve(res)
        })
      } catch (_) {
        resolve(null)
      }
    })
  }

  function canUseCustomPrompts(plan) {
    const p = plan === 'pro' ? 'unlimited' : plan || 'free'
    return p === 'polar' || p === 'unlimited'
  }

  async function loadState() {
    const data = await storageGet(['snowbear_user', 'snowbear_settings'])
    authenticated = !!data.snowbear_user?.uid
    const plan = data.snowbear_user?.plan || 'free'
    settings = { ...SB.DEFAULT_SETTINGS, ...(data.snowbear_settings || {}) }
    prompts = SB.buildPrompts(
      settings.advancedMode && canUseCustomPrompts(plan) ? settings.customPrompts : {}
    )
  }

  function isVisible(el) {
    const r = el.getBoundingClientRect()
    return r.width > 20 && r.height > 8 && r.bottom > 0 && r.top < window.innerHeight
  }

  function isChatLikeInput(el) {
    if (!el || el.closest('#snowbear-root')) return false
    if (el.id === 'prompt-textarea' || el.dataset?.testid?.includes('prompt')) return true
    if (el.closest('[class*="composer"], [class*="chat-input"], [data-testid*="composer"]')) return true
    const hint = [
      el.placeholder,
      el.getAttribute('data-placeholder'),
      el.getAttribute('aria-label'),
      el.getAttribute('name'),
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase()
    if (/message|prompt|ask|chat|send|type a|write/.test(hint)) return true
    if (el.isContentEditable && el.getAttribute('role') === 'textbox') return true
    return false
  }

  function isGenericSelector(sel) {
    return sel === 'textarea' || sel === 'div[contenteditable="true"]' || sel === 'textarea[placeholder]'
  }

  function findInput() {
    const candidates = []
    for (const sel of INPUT_SELECTORS) {
      document.querySelectorAll(sel).forEach((el) => {
        if (!isVisible(el)) return
        if (isGenericSelector(sel) && !isChatLikeInput(el)) return
        candidates.push(el)
      })
    }
    if (!candidates.length) return null
    return candidates.sort((a, b) => {
      const ra = a.getBoundingClientRect()
      const rb = b.getBoundingClientRect()
      return rb.width * rb.height - ra.width * ra.height
    })[0]
  }

  function getScope(input) {
    return (
      input.closest('form') ||
      input.closest('[class*="composer"]') ||
      input.closest('[class*="input"]') ||
      input.closest('main') ||
      document.body
    )
  }

  function findComposerShell(input) {
    let best = input.parentElement
    let bestArea = 0
    let el = input
    for (let i = 0; i < 12; i++) {
      el = el.parentElement
      if (!el || el === document.body) break
      const r = el.getBoundingClientRect()
      const area = r.width * r.height
      if (r.width > 180 && r.height > 50 && r.height < window.innerHeight * 0.9 && area > bestArea) {
        best = el
        bestArea = area
      }
    }
    return best || input.parentElement
  }

  function findFooterRow(input) {
    const scope = getScope(input)
    const shell = findComposerShell(input)
    const shellRect = shell.getBoundingClientRect()

    for (const sel of FOOTER_SELECTORS) {
      const footer = scope.querySelector(sel) || shell.querySelector(sel)
      if (footer && isVisible(footer)) return footer
    }

    for (const sel of PLUS_SELECTORS) {
      const plus = scope.querySelector(sel) || shell.querySelector(sel)
      if (plus?.parentElement && isVisible(plus)) return plus.parentElement
    }

    let bestRow = null
    let bestScore = 0
    shell.querySelectorAll('div, footer, nav').forEach((row) => {
      const r = row.getBoundingClientRect()
      const nearBottom = r.bottom >= shellRect.bottom - 55 && r.top <= shellRect.bottom
      const short = r.height >= 28 && r.height <= 64
      const wide = r.width > 120
      const hasBtn = row.querySelector('button, [role="button"]')
      if (nearBottom && short && wide && hasBtn) {
        const score = r.width - Math.abs(r.bottom - shellRect.bottom)
        if (score > bestScore) {
          bestScore = score
          bestRow = row
        }
      }
    })
    return bestRow
  }

  function findInsertPoint(input) {
    const scope = getScope(input)
    const shell = findComposerShell(input)

    for (const sel of PLUS_SELECTORS) {
      const plus = scope.querySelector(sel) || shell.querySelector(sel)
      if (plus && isVisible(plus)) return { mode: 'after', target: plus }
    }

    const footer = findFooterRow(input)
    if (footer) {
      const firstBtn = footer.querySelector('button, [role="button"]')
      if (firstBtn) return { mode: 'after', target: firstBtn }
      return { mode: 'prepend', target: footer }
    }

    return null
  }

  function getVal(el) {
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return el.value
    return el.innerText || el.textContent || ''
  }

  function setVal(el, text) {
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement : HTMLInputElement
      const setter = Object.getOwnPropertyDescriptor(proto.prototype, 'value')?.set
      setter?.call(el, text)
      el.dispatchEvent(new Event('input', { bubbles: true }))
    } else {
      el.focus()
      el.textContent = text
      el.dispatchEvent(new InputEvent('input', { bubbles: true }))
    }
    scheduleSave(text)
  }

  function scheduleSave(text) {
    clearTimeout(saveTimer)
    saveTimer = setTimeout(() => {
      sendMsg({ type: 'SAVE_CHAT_CONTEXT', chatId: currentChatId, text })
    }, 600)
  }

  async function restoreContext(input) {
    if (contextRestored) return
    const val = getVal(input).trim()
    if (val) {
      contextRestored = true
      return
    }
    const res = await sendMsg({ type: 'GET_CHAT_CONTEXT', chatId: currentChatId })
    if (res?.text?.trim()) {
      setVal(input, res.text)
      contextRestored = true
    }
  }

  function bindInputEvents(input) {
    if (boundInput === input) return
    boundInput = input

    input.addEventListener('input', () => {
      scheduleSave(getVal(input))
    })

    input.addEventListener('paste', () => {
      clearTimeout(pulseTimer)
      pulseTimer = setTimeout(() => {
        wrap?.querySelector('.snowbear-trigger')?.classList.add('snowbear-trigger--pulse')
        setTimeout(() => {
          wrap?.querySelector('.snowbear-trigger')?.classList.remove('snowbear-trigger--pulse')
        }, 2400)
      }, 1500)
    })
  }

  function showUpgradeModal(status) {
    document.querySelectorAll('.snowbear-upgrade-overlay').forEach((el) => el.remove())

    const overlay = document.createElement('div')
    overlay.className = 'snowbear-upgrade-overlay'

    const used = status?.used ?? 0
    const remaining = status?.remaining ?? 0
    const cost = status?.cost ?? 0

    overlay.innerHTML = `
      <div class="snowbear-upgrade-card" role="dialog" aria-label="Upgrade SnowBear">
        <img class="snowbear-upgrade-card__icon" src="${ICON_URL}" alt="" draggable="false"/>
        <h2 class="snowbear-upgrade-card__title">Not Enough Credits</h2>
        <p class="snowbear-upgrade-card__desc">This action needs ${cost} credit${cost > 1 ? 's' : ''}. Buy more credits or upgrade your plan.</p>
        <span class="snowbear-upgrade-card__count">${remaining} credits remaining · ${used} used this month</span>
        <button type="button" class="snowbear-upgrade-card__btn snowbear-upgrade-card__btn--primary" data-action="upgrade">View Plans</button>
        <button type="button" class="snowbear-upgrade-card__btn snowbear-upgrade-card__btn--secondary" data-action="credits">Buy 100 Credits ($5)</button>
        <button type="button" class="snowbear-upgrade-card__btn snowbear-upgrade-card__btn--ghost" data-action="close">Close</button>
      </div>
    `

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove()
    })

    overlay.querySelector('[data-action="close"]')?.addEventListener('click', () => overlay.remove())

    overlay.querySelector('[data-action="upgrade"]')?.addEventListener('click', () => {
      window.open('https://snowbear-online.firebaseapp.com/upgrade', '_blank')
    })

    overlay.querySelector('[data-action="credits"]')?.addEventListener('click', () => {
      window.open('https://snowbear-online.firebaseapp.com/credits', '_blank')
    })

    document.body.appendChild(overlay)
  }

  async function getUsageStatus(action) {
    const data = await storageGet(['snowbear_user'])
    const uid = data.snowbear_user?.uid
    if (!uid) return { allowed: false, plan: 'free', message: 'Sign in first.' }
    return (await sendMsg({ type: 'USAGE_STATUS', uid, action })) || { allowed: false, plan: 'free' }
  }

  function toast(msg, ms = 2800) {
    document.querySelectorAll('.snowbear-toast').forEach((t) => t.remove())
    const t = document.createElement('div')
    t.className = 'snowbear-toast'
    t.textContent = msg
    document.body.appendChild(t)
    setTimeout(() => t.remove(), ms)
  }

  function toastEnhanceMeta(assumptions, suggestions, ms, duration = 6000) {
    document.querySelectorAll('.snowbear-toast').forEach((t) => t.remove())
    const t = document.createElement('div')
    t.className = 'snowbear-toast snowbear-toast--rich'

    const status = document.createElement('div')
    status.className = 'snowbear-toast__status'
    status.textContent = ms ? `Enhanced · ${ms}ms` : 'Enhanced'
    t.appendChild(status)

    const hasAssumptions = assumptions && !/^none\.?$/i.test(assumptions.trim())
    const hasSuggestions = suggestions && suggestions.trim().length > 0

    if (hasAssumptions) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Assumptions'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = assumptions
      t.appendChild(p)
    }

    if (hasSuggestions) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Suggestions'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = suggestions
      t.appendChild(p)
    }

    if (!hasAssumptions && !hasSuggestions) {
      t.className = 'snowbear-toast'
      t.textContent = ms ? `Enhanced (${ms}ms)` : 'Enhanced'
      duration = 2800
    }

    document.body.appendChild(t)
    setTimeout(() => t.remove(), duration)
  }

  function toastScore(parsed, ms) {
    document.querySelectorAll('.snowbear-toast').forEach((t) => t.remove())
    const t = document.createElement('div')
    t.className = 'snowbear-toast snowbear-toast--rich'

    const status = document.createElement('div')
    status.className = 'snowbear-toast__status'
    status.textContent = parsed.score != null ? `Score: ${parsed.score}/100 · ${ms}ms` : `Scored · ${ms}ms`
    t.appendChild(status)

    if (parsed.breakdown) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Breakdown'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = parsed.breakdown
      t.appendChild(p)
    }

    if (parsed.weaknesses.length) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Weaknesses'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = parsed.weaknesses.map((w) => `• ${w}`).join('\n')
      t.appendChild(p)
    }

    if (parsed.fix) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Fix'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = parsed.fix
      t.appendChild(p)
    }

    document.body.appendChild(t)
    setTimeout(() => t.remove(), 7000)
  }

  async function callGroq(action, prompt) {
    if (abortCtrl) abortCtrl.abort()
    abortCtrl = new AbortController()
    return SB.callSnowBearApi(action, prompt, prompts)
  }

  function closeMenu() {
    menuOpen = false
    wrap?.querySelector('.snowbear-toolbar')?.classList.remove('snowbear-toolbar--open')
    wrap?.querySelector('.snowbear-trigger')?.classList.remove('snowbear-trigger--open')
  }

  async function openMenu() {
    if (!authenticated) {
      toast('Please sign in via the SnowBear extension icon first.')
      return
    }
    menuOpen = true
    wrap?.querySelector('.snowbear-toolbar')?.classList.add('snowbear-toolbar--open')
    wrap?.querySelector('.snowbear-trigger')?.classList.add('snowbear-trigger--open')
  }

  async function toggleMenu() {
    if (busy) return
    if (menuOpen) closeMenu()
    else await openMenu()
  }

  function buildUI() {
    wrap = document.createElement('div')
    wrap.className = 'snowbear-wrap'
    wrap.id = 'snowbear-root'

    const trigger = document.createElement('button')
    trigger.className = 'snowbear-trigger'
    trigger.type = 'button'
    trigger.setAttribute('aria-label', 'SnowBear')
    trigger.innerHTML = `<img src="${BEAR_URL}" alt="" draggable="false"/>`
    trigger.addEventListener('click', async (e) => {
      e.stopPropagation()
      e.preventDefault()
      if (!authenticated) {
        toast('Sign in or sign up — click the SnowBear icon in your toolbar.')
        return
      }
      if (menuOpen) {
        closeMenu()
        return
      }
      await openMenu()
    })

    const toolbar = document.createElement('div')
    toolbar.className = 'snowbear-toolbar'
    toolbar.setAttribute('role', 'toolbar')

    TOOLS.forEach((tool) => {
      const btn = document.createElement('button')
      btn.className = 'snowbear-seg'
      btn.type = 'button'
      btn.dataset.action = tool.action
      btn.title = tool.desc
      btn.innerHTML = `
        <span class="snowbear-seg__icon">${ICONS[tool.action]}</span>
        <span class="snowbear-seg__label">${tool.label}</span>
      `
      btn.addEventListener('click', (e) => {
        e.stopPropagation()
        closeMenu()
        run(tool.action, btn)
      })
      toolbar.appendChild(btn)
    })

    wrap.appendChild(trigger)
    wrap.appendChild(toolbar)

    document.addEventListener('click', (e) => {
      if (!wrap?.contains(e.target)) closeMenu()
    })
  }

  function positionFallback(input) {
    if (!wrap || !input) return
    try {
      const shell = findComposerShell(input)
      if (!shell?.isConnected) return
      const r = shell.getBoundingClientRect()
      wrap.style.top = `${r.bottom - 44}px`
      wrap.style.left = `${r.left + 12}px`
    } catch (_) {}
  }

  function insertIntoFooter(input) {
    if (!wrap || !input) return false
    try {
      const point = findInsertPoint(input)
      if (!point?.target?.isConnected) return false

      wrap.classList.remove('snowbear-wrap--fixed')
      wrap.style.top = ''
      wrap.style.left = ''

      if (point.mode === 'after') {
        if (wrap.previousElementSibling !== point.target) {
          point.target.insertAdjacentElement('afterend', wrap)
        }
      } else if (point.mode === 'prepend') {
        if (wrap.parentElement !== point.target) {
          point.target.insertBefore(wrap, point.target.firstChild)
        }
      }
      return true
    } catch (_) {
      return false
    }
  }

  function attachFixed(input) {
    if (!wrap) return
    try {
      wrap.classList.add('snowbear-wrap--fixed')
      if (wrap.parentElement !== document.body) document.body.appendChild(wrap)
      positionFallback(input)
    } catch (_) {}
  }

  async function consumeUsage(action) {
    const data = await storageGet(['snowbear_user'])
    const uid = data.snowbear_user?.uid
    if (!uid) return { allowed: false, message: 'Sign in via the SnowBear extension icon first.' }
    const res = await sendMsg({ type: 'USAGE_CONSUME', uid, action })
    return res || { allowed: false, message: 'Could not check credits.' }
  }

  async function run(action, btn) {
    if (busy) return
    if (!authenticated) return toast('Sign in via the SnowBear toolbar icon first.')

    const input = findInput()
    if (!input) return toast('No prompt box found.')
    const prompt = getVal(input).trim()
    if (!prompt) return toast('Type a prompt first.')

    const usage = await consumeUsage(action)
    if (!usage.allowed) {
      showUpgradeModal(usage)
      return
    }

    busy = true
    btn?.classList.add('snowbear-seg--active')
    wrap?.querySelectorAll('.snowbear-seg').forEach((b) => (b.disabled = true))
    toast('Processing…', 8000)

    const t0 = performance.now()
    try {
      const result = await callGroq(action, prompt)
      const ms = Math.round(performance.now() - t0)

      if (action === 'score') {
        const parsed = SB.parseScoreResponse(result)
        toastScore(parsed, ms)
      } else if (action === 'enhance') {
        const { enhanced, assumptions, suggestions } = SB.parseEnhanceResponse(result)
        setVal(findInput() || input, enhanced)
        toastEnhanceMeta(assumptions, suggestions, ms)
      } else {
        const output =
          action === 'grammar' ? SB.cleanGrammarOutput(prompt, result) : SB.cleanOutput(result)
        setVal(findInput() || input, output)
        const done = { compress: 'Compressed', grammar: 'Grammar fixed' }
        toast(`${done[action]} (${ms}ms)`)
      }
    } catch (err) {
      if (err.name !== 'AbortError') toast(err.message || 'API error')
    } finally {
      busy = false
      btn?.classList.remove('snowbear-seg--active')
      wrap?.querySelectorAll('.snowbear-seg').forEach((b) => (b.disabled = false))
    }
  }

  function teardown() {
    try {
      wrap?.remove()
    } catch (_) {}
    wrap = null
    boundInput = null
    lastMountedInput = null
    closeMenu()
  }

  let mountPending = false
  let mountTimer = null
  let lastMountedInput = null

  function scheduleMount() {
    clearTimeout(mountTimer)
    mountTimer = setTimeout(() => mount(), 200)
  }

  async function mount() {
    if (mountPending) return
    mountPending = true
    try {
      if (typeof SnowBearShared === 'undefined') return

      await loadState()

      if (!SB.isSiteAllowed(location.hostname, settings)) {
        teardown()
        lastMountedInput = null
        return
      }

      const chatId = SB.getChatId()
      if (chatId !== currentChatId) {
        currentChatId = chatId
        contextRestored = false
        lastMountedInput = null
      }

      const input = findInput()
      if (!input) {
        teardown()
        lastMountedInput = null
        return
      }

      if (wrap?.isConnected && input === lastMountedInput) {
        if (!insertIntoFooter(input)) positionFallback(input)
        return
      }

      if (!wrap) buildUI()
      if (!wrap) return

      bindInputEvents(input)
      restoreContext(input)

      const inserted = insertIntoFooter(input)
      if (!inserted) attachFixed(input)
      lastMountedInput = input
    } catch (err) {
      console.debug('[SnowBear]', err)
      teardown()
    } finally {
      mountPending = false
    }
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return
      if (changes.snowbear_user) {
        const plan = changes.snowbear_user.newValue?.plan
        if (plan === 'unlimited' || plan === 'pro' || plan === 'polar') {
          document.querySelectorAll('.snowbear-upgrade-overlay').forEach((el) => el.remove())
        }
        loadState().then(() => scheduleMount())
        return
      }
      if (changes.snowbear_settings) scheduleMount()
    })

    if (document.body) {
      new MutationObserver(scheduleMount).observe(document.body, { childList: true, subtree: true })
    }
    window.addEventListener('resize', scheduleMount)
    window.addEventListener('scroll', scheduleMount, { capture: true, passive: true })
    setInterval(scheduleMount, 3000)
    mount()
  } catch (err) {
    console.debug('[SnowBear] init failed', err)
  }
})()