// SnowBear v2.0 — auth-gated, site-aware, context-persistent prompt tools
;(function () {
  function extensionContextOk() {
    try {
      return !!(
        typeof chrome !== 'undefined' &&
        chrome.runtime?.id &&
        typeof chrome.runtime.getURL === 'function' &&
        typeof SnowBearShared !== 'undefined'
      )
    } catch (_) {
      return false
    }
  }

  if (!extensionContextOk()) return

  const SB = SnowBearShared
  const BEAR_URL = chrome.runtime.getURL('bear-prompt.png')
  const ICON_URL = chrome.runtime.getURL('icon.png')

  // Preload bear so the prompt-bar icon paints immediately
  ;(function preloadBearAsset() {
    const img = new Image()
    img.src = BEAR_URL
  })()

  const BASE_INPUT_SELECTORS = [
    '#prompt-textarea',
    '#chat-input',
    '#userInput',
    'textarea[data-testid="prompt-textarea"]',
    'textarea[data-testid="chat-input"]',
    'textarea[name="prompt"]',
    'textarea[id*="prompt" i]',
    'textarea[class*="prompt" i]',
    'input[name="prompt"]',
    'input[id*="prompt" i]',
    'input[placeholder*="prompt" i]',
    'input[placeholder*="describe" i]',
    'input[placeholder*="message" i]',
    'input[placeholder*="ask" i]',
    'div#prompt-textarea[contenteditable="true"]',
    'div.ProseMirror[contenteditable="true"]',
    'div[data-lexical-editor="true"]',
    'div[data-slate-editor="true"]',
    'div.ql-editor[contenteditable="true"]',
    'div.tiptap[contenteditable="true"]',
    'div.cm-content[contenteditable="true"]',
    'div[contenteditable="plaintext-only"]',
    'div[contenteditable="true"][data-placeholder]',
    'div[contenteditable="true"][aria-multiline="true"]',
    'div[contenteditable="true"][role="textbox"]',
    'div[contenteditable="true"][aria-label*="prompt" i]',
    'div[contenteditable="true"][aria-label*="message" i]',
    'div[contenteditable="true"][aria-label*="describe" i]',
    'div[contenteditable="true"][aria-label*="ask" i]',
    'rich-textarea textarea',
    'sl-textarea textarea',
    'textarea[placeholder*="prompt" i]',
    'textarea[placeholder*="describe" i]',
    'textarea[placeholder*="message" i]',
    'textarea[placeholder*="ask" i]',
    'textarea[placeholder*="type" i]',
    'textarea[placeholder*="chat" i]',
    'textarea[placeholder*="write" i]',
    'textarea[placeholder]',
    'textarea',
    'div[contenteditable="true"]',
    'div[contenteditable=""]',
    'p[contenteditable="true"]',
    '[role="textbox"][contenteditable]',
    '[data-testid*="prompt" i] [contenteditable]',
    '[data-testid*="composer" i] [contenteditable]',
    '[class*="ProseMirror"]',
    '[class*="tiptap"]',
    '[class*="ql-editor"]',
    'form textarea',
    'footer textarea',
    '[class*="composer"] textarea',
    '[class*="prompt"] textarea',
    '[class*="chat-input"] textarea',
    '[class*="Prompt"] textarea',
    '[class*="composer"] div[contenteditable="true"]',
    '[class*="composer"] div[contenteditable=""]',
    '[class*="prompt"] div[contenteditable="true"]',
    '[class*="prompt"] div[contenteditable=""]',
    '[class*="chat"] div[contenteditable="true"]',
    '[class*="chat"] div[contenteditable=""]',
    '[class*="input"] div[contenteditable="true"]',
    '[class*="editor"] div[contenteditable="true"]',
  ]

  const HOST_INPUT_SELECTORS = {
    'chatgpt.com': [
      '#prompt-textarea',
      'div#prompt-textarea[contenteditable="true"]',
      'textarea[data-testid="prompt-textarea"]',
    ],
    'claude.ai': [
      'div.ProseMirror[contenteditable="true"]',
      'fieldset div[contenteditable="true"]',
      'div[enterkeyhint="enter"][contenteditable="true"]',
    ],
    'gemini.google.com': [
      'rich-textarea textarea',
      'div.ql-editor[contenteditable="true"]',
      'div.input-area div[contenteditable="true"]',
    ],
    'copilot.microsoft.com': [
      'textarea#userInput',
      'textarea[data-testid="composer-input"]',
      'div[contenteditable="true"][role="textbox"]',
    ],
    'perplexity.ai': [
      'textarea[placeholder*="Ask" i]',
      'div[class*="rounded"] textarea',
      'textarea',
    ],
    'chat.deepseek.com': ['textarea', 'div[contenteditable="true"]'],
    'grok.com': ['textarea', 'div[contenteditable="true"][role="textbox"]'],
    'chat.mistral.ai': ['textarea', 'div.ProseMirror[contenteditable="true"]'],
    'poe.com': ['textarea[class*="GrowingTextArea"]', 'textarea'],
    'you.com': ['textarea#search-input', 'textarea'],
    'pi.ai': ['textarea', 'div[contenteditable="true"]'],
    'chat.qwen.ai': ['textarea', 'div[contenteditable="true"]'],
    'huggingface.co': ['textarea', 'div[contenteditable="true"]'],
    'leonardo.ai': ['textarea', 'input[type="text"]'],
    'ideogram.ai': ['textarea', 'div[contenteditable="true"]'],
    'firefly.adobe.com': ['textarea', 'div[contenteditable="true"]'],
    'canva.com': ['div[contenteditable="true"]', 'textarea', 'input[type="text"]'],
    'playground.com': ['textarea', 'input[type="text"]'],
    'midjourney.com': ['textarea', 'input[type="text"]'],
    'openart.ai': ['textarea', 'div[contenteditable="true"]'],
    'krea.ai': ['textarea', 'input[type="text"]'],
    'runwayml.com': ['textarea', 'div[contenteditable="true"]'],
    'pika.art': ['textarea', 'input[type="text"]'],
    'suno.com': ['textarea', 'div[contenteditable="true"]'],
    'udio.com': ['textarea', 'div[contenteditable="true"]'],
    'elevenlabs.io': ['textarea', 'div[contenteditable="true"]'],
    'cursor.com': ['textarea', 'div[contenteditable="true"]'],
    'bolt.new': ['textarea', 'div.cm-content'],
    'lovable.dev': ['textarea', 'div[contenteditable="true"]'],
    'v0.dev': ['textarea', 'div[contenteditable="true"]'],
    'replit.com': ['textarea', 'div.cm-content'],
    'notion.so': ['div[contenteditable="true"]', 'textarea'],
    'gamma.app': ['textarea', 'div[contenteditable="true"]'],
    'character.ai': ['textarea', 'div[contenteditable="true"]'],
    'novelai.net': ['textarea', 'div[contenteditable="true"]'],
    'janitorai.com': ['textarea', 'div[contenteditable="true"]'],
  }

  function getInputSelectors() {
    const host = location.hostname.toLowerCase()
    const hostSels = []
    for (const [pattern, sels] of Object.entries(HOST_INPUT_SELECTORS)) {
      if (SB.hostMatches(host, pattern)) hostSels.push(...sels)
    }
    const seen = new Set()
    const merged = []
    for (const sel of [...hostSels, ...BASE_INPUT_SELECTORS]) {
      if (seen.has(sel)) continue
      seen.add(sel)
      merged.push(sel)
    }
    return merged
  }

  function queryAllDeep(selector, root = document) {
    const results = []
    const seen = new Set()
    const walk = (node) => {
      if (!node || !node.querySelectorAll) return
      try {
        node.querySelectorAll(selector).forEach((el) => {
          if (!seen.has(el)) {
            seen.add(el)
            results.push(el)
          }
        })
        node.querySelectorAll('*').forEach((el) => {
          if (el.shadowRoot) walk(el.shadowRoot)
        })
      } catch (_) {}
    }
    walk(root)
    return results
  }

  const PLUS_SELECTORS = [
    'button[data-testid="composer-plus-btn"]',
    'button[aria-label="Add files and more"]',
    'button[aria-label*="Attach"]',
    'button[aria-label*="Add"]',
    'button[aria-label*="Upload"]',
    'button.composer-btn',
  ]

  const FOOTER_SELECTORS = [
    '[data-testid="composer-footer-actions"]',
    '[data-testid="composer-footer"]',
    '[data-testid="composer-trailing-actions"]',
    '[data-testid="composer-leading-actions"]',
    'div[class*="composer-footer"]',
    'div[class*="composer-actions"]',
    'div[class*="input-footer"]',
    'div[class*="prompt-footer"]',
    'div[class*="chat-footer"]',
    'div[class*="toolbar"]',
    'div[class*="trailing"]',
    'div[class*="actions"]',
  ]

  const SEND_SELECTORS = [
    'button[data-testid="send-button"]',
    'button[data-testid="composer-send-button"]',
    'button[aria-label*="Send" i]',
    'button[aria-label*="Submit" i]',
    'button[type="submit"]',
  ]

  const ICONS = {
    enhance: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8L12 3z"/><path d="M19 14l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9.9-2.1z"/></svg>`,
    compress: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 9H4V5"/><path d="M4 9l4-4"/><path d="M16 15h4v4"/><path d="M20 15l-4 4"/><path d="M16 9h4V5"/><path d="M20 9l-4-4"/><path d="M8 15H4v4"/><path d="M4 15l4 4"/></svg>`,
    grammar: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16"/><path d="M6 16l6-10 6 10"/><path d="M8.5 12h7"/></svg>`,
    score: `<svg viewBox="0 0 24 24" fill="none" stroke="#6EC6FF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h16"/><path d="M6 17V9"/><path d="M10 17V5"/><path d="M14 17v-6"/><path d="M18 17v-3"/></svg>`,
  }

  const TOOLS = [
    { action: 'enhance', label: 'Enhance', desc: 'Optimize prompt' },
    { action: 'compress', label: 'Compress', desc: 'Save tokens' },
    { action: 'grammar', label: 'Fix Grammar', desc: 'Grammar only' },
    { action: 'score', label: 'Score', desc: 'Honest 0–100' },
  ]

  let wrap = null
  let menuOpen = false
  let busy = false
  let abortCtrl = null
  let authenticated = false
  let settings = { ...SB.DEFAULT_SETTINGS }
  let prompts = SB.buildPrompts()
  let currentChatId = SB.getChatId()
  let contextRestored = false
  let saveTimer = null
  let pulseTimer = null
  let boundInput = null
  let focusedPromptInput = null

  function storageGet(keys) {
    return new Promise((resolve) => chrome.storage.local.get(keys, resolve))
  }

  function isRetryableMsgError(message) {
    return /message port closed|extension context invalidated|receiving end does not exist|starting/i.test(
      message || ''
    )
  }

  function sendMsgOnce(msg, timeoutMs = 20000) {
    return new Promise((resolve) => {
      let settled = false
      const finish = (value) => {
        if (settled) return
        settled = true
        resolve(value)
      }

      const timer =
        timeoutMs > 0
          ? setTimeout(() => finish({ ok: false, error: 'Request timed out. Reload the extension and try again.' }), timeoutMs)
          : null

      try {
        chrome.runtime.sendMessage(msg, (res) => {
          if (timer) clearTimeout(timer)
          if (chrome.runtime.lastError) {
            finish({ ok: false, error: chrome.runtime.lastError.message })
            return
          }
          finish(res ?? { ok: false, error: 'No response from SnowBear background.' })
        })
      } catch (err) {
        if (timer) clearTimeout(timer)
        finish({ ok: false, error: err?.message || 'Could not reach SnowBear background.' })
      }
    })
  }

  async function sendMsg(msg, opts = {}) {
    const retries = opts.retries ?? 2
    const timeoutMs = opts.timeoutMs ?? 20000

    for (let attempt = 0; attempt <= retries; attempt++) {
      if (attempt > 0) {
        await sendMsgOnce({ type: 'PING' }, 4000)
        await new Promise((resolve) => setTimeout(resolve, 120 * attempt))
      }

      const res = await sendMsgOnce(msg, timeoutMs)
      if (!res?.error) return res
      if (!isRetryableMsgError(res.error) || attempt === retries) {
        return { ok: false, error: res.error }
      }
    }

    return { ok: false, error: 'SnowBear background is unavailable. Reload the extension and try again.' }
  }

  function canUseCustomPrompts(plan) {
    const p = plan === 'pro' ? 'unlimited' : plan || 'free'
    return p === 'polar' || p === 'unlimited'
  }

  async function loadState() {
    const data = await storageGet(['snowbear_user', 'snowbear_settings'])
    authenticated = !!data.snowbear_user?.uid
    const plan = data.snowbear_user?.plan || 'free'
    settings = { ...SB.DEFAULT_SETTINGS, ...(data.snowbear_settings || {}) }
    prompts = SB.buildPrompts(settings.customPrompts || {}, {
      useCustom: settings.advancedMode && canUseCustomPrompts(plan),
    })
  }

  function isEditableInput(el) {
    if (!el) return false
    if (el.isContentEditable) return true
    if (el.getAttribute?.('role') === 'textbox') return true
    if (el.tagName === 'TEXTAREA') return true
    if (el.tagName === 'INPUT') {
      const type = (el.type || 'text').toLowerCase()
      return type === 'text' || type === ''
    }
    return false
  }

  function isHiddenInput(el) {
    if (!el?.isConnected) return true
    try {
      const style = getComputedStyle(el)
      if (style.display === 'none' || style.visibility === 'hidden') return true
      if (parseFloat(style.opacity) === 0) return true
      if (el.getAttribute('aria-hidden') === 'true') return true
      const r = el.getBoundingClientRect()
      if (r.width <= 1 || r.height <= 1) return true
      if (r.bottom < 0 || r.top > window.innerHeight + 40) return true
      if (el.tagName === 'TEXTAREA' && (el.clientHeight <= 2 || style.height === '0px')) return true
    } catch (_) {
      return true
    }
    return false
  }

  function isVisible(el) {
    if (isHiddenInput(el)) return false
    const r = el.getBoundingClientRect()
    const onAiSite = SB.isKnownAiHost(location.hostname)
    const minW = onAiSite ? 28 : 20
    const minH = onAiSite ? 10 : 8
    return r.width > minW && r.height > minH && r.bottom > 0 && r.top < window.innerHeight
  }

  function getPromptHint(el) {
    return [
      el.placeholder,
      el.getAttribute('data-placeholder'),
      el.getAttribute('aria-label'),
      el.getAttribute('aria-placeholder'),
      el.getAttribute('name'),
      el.id,
      el.className,
      el.closest('[class*="composer"], [class*="prompt"], [class*="chat"]')?.className,
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase()
  }

  function isPromptBarInput(el) {
    if (!el || !isEditableInput(el)) return false
    const onAiSite = SB.isKnownAiHost(location.hostname)
    if (onAiSite) return true

    const r = el.getBoundingClientRect()
    const distFromBottom = window.innerHeight - r.bottom
    const inComposer = el.closest(
      '[class*="composer"], [class*="prompt"], [class*="chat-input"], [class*="message-input"], [class*="input-area"], [data-testid*="composer"], [data-testid*="prompt"]'
    )
    const hint = getPromptHint(el)
    const promptHint = /message|prompt|ask|chat|send|type|write|comment|reply|query|compose|draft|describe|generate|create/.test(
      hint
    )

    if (inComposer) return true
    if (el.isContentEditable && el.getAttribute('role') === 'textbox') return true
    if (promptHint && distFromBottom < 360) return true
    if (el.tagName === 'TEXTAREA' && distFromBottom < 300) return true
    return false
  }

  function resolvePromptInput(el) {
    if (!el) return null

    if (isHiddenInput(el)) {
      const scope =
        el.closest(
          '[class*="composer"], [class*="prompt"], [class*="chat"], [class*="input"], form, rich-textarea, [data-testid*="composer"]'
        ) || el.parentElement
      if (scope) {
        const visible = scope.querySelector(
          '#prompt-textarea[contenteditable], div[contenteditable="true"], div[contenteditable=""], [role="textbox"][contenteditable], div.ProseMirror, div[data-lexical-editor="true"], div.ql-editor'
        )
        if (visible && !isHiddenInput(visible)) return visible
      }
    }

    if (el.isContentEditable) {
      const r = el.getBoundingClientRect()
      if (r.height < 14) {
        const parent = el.parentElement
        if (parent?.isContentEditable && !isHiddenInput(parent)) return parent
      }
      return el
    }

    if (el.tagName === 'TEXTAREA' && el.closest('rich-textarea')) {
      const visible = el.closest('rich-textarea')?.querySelector(
        'div[contenteditable="true"], div[contenteditable=""], [role="textbox"]'
      )
      if (visible && !isHiddenInput(visible)) return visible
    }

    return el
  }

  function isExcludedInput(el) {
    if (!el || el.closest('#snowbear-root')) return true
    if (!isEditableInput(el)) return true
    if (!isPromptBarInput(el)) return true
    if (isHiddenInput(el)) return true
    if (el.type === 'search' || el.inputMode === 'search') return true
    if (el.closest('[role="search"]')) return true
    const onAiSite = SB.isKnownAiHost(location.hostname)
    if (!onAiSite && el.closest('header, nav') && el.tagName !== 'TEXTAREA' && !el.isContentEditable) {
      const r = el.getBoundingClientRect()
      if (r.height < 44) return true
    }
    const r = el.getBoundingClientRect()
    const minW = onAiSite ? 40 : 60
    const minH = onAiSite ? 12 : 20
    if (r.width < minW || r.height < minH) return true
    if (!onAiSite && el.tagName === 'INPUT' && r.width < 120) return true
    return false
  }

  function scorePromptInput(el) {
    const r = el.getBoundingClientRect()
    let score = r.width * r.height
    const onAiSite = SB.isKnownAiHost(location.hostname)

    const distFromBottom = window.innerHeight - r.bottom
    if (distFromBottom < 280) score += 8000
    if (distFromBottom < 140) score += 12000
    if (distFromBottom < 80) score += 8000
    if (onAiSite && distFromBottom < 320) score += 10000

    if (el.closest('[class*="composer"], [class*="prompt"], [class*="chat"], [class*="input"], [class*="message"], [class*="editor"], [class*="generate"], form, main, [role="main"], footer')) {
      score += 2500
    }
    if (el.id?.includes('prompt') || el.dataset?.testid?.includes('prompt')) score += 6000

    const hint = getPromptHint(el)
    if (/message|prompt|ask|chat|send|type|write|comment|reply|query|input|compose|draft|text|describe|generate|create|lyrics|script|idea/.test(hint)) {
      score += 3000
    }

    if (isHiddenInput(el)) score -= 50000
    if (el.isContentEditable) score += 12000
    if (el.getAttribute('role') === 'textbox') score += 4000
    if (el.id === 'prompt-textarea' || el.dataset?.testid?.includes('prompt')) score += 8000
    if (el.classList?.contains('ProseMirror') || el.dataset?.lexicalEditor != null) score += 6000
    if (el.tagName === 'TEXTAREA') score += 1500
    if (onAiSite && el.isContentEditable) score += 10000
    if (onAiSite && el.tagName === 'TEXTAREA' && !el.closest('rich-textarea')) score += 3000
    if (el === focusedPromptInput) score += 15000
    if (el === document.activeElement || el.contains(document.activeElement)) score += 8000
    if (!onAiSite && r.top < 60) score -= 4000
    if (onAiSite && r.top < 40 && distFromBottom > 200) score -= 2000

    return score
  }

  function collectPromptCandidates() {
    const candidates = []
    const seen = new Set()
    const add = (el) => {
      const resolved = resolvePromptInput(el)
      if (!resolved || seen.has(resolved)) return
      seen.add(resolved)
      if (!isVisible(resolved)) return
      if (isExcludedInput(resolved)) return
      candidates.push(resolved)
    }

    for (const sel of getInputSelectors()) {
      queryAllDeep(sel).forEach(add)
    }

    queryAllDeep(
      '[contenteditable="true"], [contenteditable=""], [role="textbox"][contenteditable], div.ProseMirror, div[data-lexical-editor="true"]'
    ).forEach(add)

    return candidates
  }

  function findInput() {
    if (
      focusedPromptInput?.isConnected &&
      !isHiddenInput(focusedPromptInput) &&
      !isExcludedInput(focusedPromptInput)
    ) {
      return focusedPromptInput
    }

    const candidates = collectPromptCandidates()
    if (!candidates.length) return null

    const ranked = candidates.sort((a, b) => scorePromptInput(b) - scorePromptInput(a))
    const best = ranked[0]

    if (
      lastMountedInput?.isConnected &&
      !isHiddenInput(lastMountedInput) &&
      !isExcludedInput(lastMountedInput)
    ) {
      if (best === lastMountedInput) return lastMountedInput
      const currentScore = scorePromptInput(lastMountedInput)
      const bestScore = scorePromptInput(best)
      if (bestScore - currentScore < INPUT_SWITCH_MARGIN) return lastMountedInput
    }

    return best
  }

  function getScope(input) {
    return (
      input.closest('form') ||
      input.closest('[class*="composer"]') ||
      input.closest('[class*="input"]') ||
      input.closest('main') ||
      document.body
    )
  }

  function findComposerShell(input) {
    let best = input.parentElement
    let bestArea = 0
    let el = input
    for (let i = 0; i < 12; i++) {
      el = el.parentElement
      if (!el || el === document.body) break
      const r = el.getBoundingClientRect()
      const area = r.width * r.height
      if (r.width > 180 && r.height > 50 && r.height < window.innerHeight * 0.9 && area > bestArea) {
        best = el
        bestArea = area
      }
    }
    return best || input.parentElement
  }

  function findFooterRow(input) {
    const scope = getScope(input)
    const shell = findComposerShell(input)
    const shellRect = shell.getBoundingClientRect()

    for (const sel of FOOTER_SELECTORS) {
      const footer = scope.querySelector(sel) || shell.querySelector(sel)
      if (footer && isVisible(footer)) return footer
    }

    for (const sel of PLUS_SELECTORS) {
      const plus = scope.querySelector(sel) || shell.querySelector(sel)
      if (plus?.parentElement && isVisible(plus)) return plus.parentElement
    }

    let bestRow = null
    let bestScore = 0
    shell.querySelectorAll('div, footer, nav').forEach((row) => {
      const r = row.getBoundingClientRect()
      const nearBottom = r.bottom >= shellRect.bottom - 55 && r.top <= shellRect.bottom
      const short = r.height >= 28 && r.height <= 64
      const wide = r.width > 120
      const hasBtn = row.querySelector('button, [role="button"]')
      if (nearBottom && short && wide && hasBtn) {
        const score = r.width - Math.abs(r.bottom - shellRect.bottom)
        if (score > bestScore) {
          bestScore = score
          bestRow = row
        }
      }
    })
    return bestRow
  }

  function findInsertPoint(input) {
    const scope = getScope(input)
    const shell = findComposerShell(input)

    for (const sel of PLUS_SELECTORS) {
      const plus = scope.querySelector(sel) || shell.querySelector(sel)
      if (plus && isVisible(plus)) return { mode: 'after', target: plus }
    }

    for (const sel of SEND_SELECTORS) {
      const send = scope.querySelector(sel) || shell.querySelector(sel)
      if (send && isVisible(send)) return { mode: 'before', target: send }
    }

    const footer = findFooterRow(input)
    if (footer) {
      const firstBtn = footer.querySelector('button, [role="button"]')
      if (firstBtn) return { mode: 'after', target: firstBtn }
      return { mode: 'prepend', target: footer }
    }

    const editableRow = input.closest(
      '[class*="composer"], [class*="prompt"], [class*="input"], [class*="chat"], form, footer'
    )
    if (editableRow && isVisible(editableRow)) {
      const r = input.getBoundingClientRect()
      if (window.innerHeight - r.bottom < 320) {
        const btn = editableRow.querySelector('button, [role="button"]')
        if (btn && isVisible(btn)) return { mode: 'before', target: btn }
        return { mode: 'append', target: editableRow }
      }
    }

    const row = input.parentElement
    if (row && isVisible(row)) {
      const r = input.getBoundingClientRect()
      if (window.innerHeight - r.bottom < 280) return { mode: 'after', target: input }
    }

    return null
  }

  function getVal(el) {
    if (!el) return ''
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return el.value
    return el.innerText || el.textContent || ''
  }

  function setVal(el, text) {
    if (!el) return
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement : HTMLInputElement
      const setter = Object.getOwnPropertyDescriptor(proto.prototype, 'value')?.set
      setter?.call(el, text)
      el.dispatchEvent(new Event('input', { bubbles: true }))
      el.dispatchEvent(new Event('change', { bubbles: true }))
    } else {
      el.focus()
      try {
        const sel = window.getSelection()
        const range = document.createRange()
        range.selectNodeContents(el)
        sel.removeAllRanges()
        sel.addRange(range)
        const inserted = document.execCommand('insertText', false, text)
        if (!inserted) {
          el.textContent = text
        }
      } catch (_) {
        el.textContent = text
      }
      el.dispatchEvent(
        new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })
      )
      el.dispatchEvent(new Event('change', { bubbles: true }))
    }
    scheduleSave(text)
  }

  function scheduleSave(text) {
    clearTimeout(saveTimer)
    saveTimer = setTimeout(() => {
      sendMsg({ type: 'SAVE_CHAT_CONTEXT', chatId: currentChatId, text })
    }, 600)
  }

  async function restoreContext(input) {
    if (contextRestored) return
    const val = getVal(input).trim()
    if (val) {
      contextRestored = true
      return
    }
    const res = await sendMsg({ type: 'GET_CHAT_CONTEXT', chatId: currentChatId })
    if (res?.text?.trim()) {
      setVal(input, res.text)
      contextRestored = true
    }
  }

  function bindInputEvents(input) {
    if (boundInput === input) return
    boundInput = input

    input.addEventListener('input', () => {
      scheduleSave(getVal(input))
    })

    input.addEventListener('paste', () => {
      clearTimeout(pulseTimer)
      pulseTimer = setTimeout(() => {
        wrap?.querySelector('.snowbear-trigger')?.classList.add('snowbear-trigger--pulse')
        setTimeout(() => {
          wrap?.querySelector('.snowbear-trigger')?.classList.remove('snowbear-trigger--pulse')
        }, 2400)
      }, 1500)
    })
  }

  function showUpgradeModal(status) {
    document.querySelectorAll('.snowbear-upgrade-overlay').forEach((el) => el.remove())

    const overlay = document.createElement('div')
    overlay.className = 'snowbear-upgrade-overlay'

    const used = status?.used ?? 0
    const remaining = status?.remaining ?? 0
    const cost = status?.cost ?? 0

    overlay.innerHTML = `
      <div class="snowbear-upgrade-card" role="dialog" aria-label="Upgrade SnowBear">
        <img class="snowbear-upgrade-card__icon" src="${ICON_URL}" alt="" draggable="false"/>
        <h2 class="snowbear-upgrade-card__title">Not Enough Credits</h2>
        <p class="snowbear-upgrade-card__desc">This action needs ${cost} credit${cost > 1 ? 's' : ''}. Buy more credits or upgrade your plan.</p>
        <span class="snowbear-upgrade-card__count">${remaining} credits remaining · ${used} used this month</span>
        <button type="button" class="snowbear-upgrade-card__btn snowbear-upgrade-card__btn--primary" data-action="upgrade">View Plans</button>
        <button type="button" class="snowbear-upgrade-card__btn snowbear-upgrade-card__btn--secondary" data-action="credits">Buy 100 Credits</button>
        <button type="button" class="snowbear-upgrade-card__btn snowbear-upgrade-card__btn--ghost" data-action="close">Close</button>
      </div>
    `

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove()
    })

    overlay.querySelector('[data-action="close"]')?.addEventListener('click', () => overlay.remove())

    const siteBase = SB.getBackendUrl()

    overlay.querySelector('[data-action="upgrade"]')?.addEventListener('click', () => {
      window.open(`${siteBase}/pricing`, '_blank')
    })

    overlay.querySelector('[data-action="credits"]')?.addEventListener('click', () => {
      window.open(`${siteBase}/credits`, '_blank')
    })

    document.body.appendChild(overlay)
  }

  async function getUsageStatus(action) {
    const data = await storageGet(['snowbear_user'])
    const uid = data.snowbear_user?.uid
    if (!uid) return { allowed: false, plan: 'free', message: 'Sign in first.' }
    return (await sendMsg({ type: 'USAGE_STATUS', uid, action })) || { allowed: false, plan: 'free' }
  }

  function toast(msg, ms = 2800) {
    document.querySelectorAll('.snowbear-toast').forEach((t) => t.remove())
    const t = document.createElement('div')
    t.className = 'snowbear-toast'
    t.textContent = msg
    document.body.appendChild(t)
    setTimeout(() => t.remove(), ms)
  }

  function toastEnhanceMeta(assumptions, suggestions, ms, duration = 6000) {
    document.querySelectorAll('.snowbear-toast').forEach((t) => t.remove())
    const t = document.createElement('div')
    t.className = 'snowbear-toast snowbear-toast--rich'

    const status = document.createElement('div')
    status.className = 'snowbear-toast__status'
    status.textContent = ms ? `Enhanced · ${ms}ms` : 'Enhanced'
    t.appendChild(status)

    const hasAssumptions = assumptions && !/^none\.?$/i.test(assumptions.trim())
    const hasSuggestions = suggestions && suggestions.trim().length > 0

    if (hasAssumptions) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Assumptions'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = assumptions
      t.appendChild(p)
    }

    if (hasSuggestions) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Suggestions'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = suggestions
      t.appendChild(p)
    }

    if (!hasAssumptions && !hasSuggestions) {
      t.className = 'snowbear-toast'
      t.textContent = ms ? `Enhanced (${ms}ms)` : 'Enhanced'
      duration = 2800
    }

    document.body.appendChild(t)
    setTimeout(() => t.remove(), duration)
  }

  function toastScore(parsed, ms) {
    document.querySelectorAll('.snowbear-toast').forEach((t) => t.remove())
    const t = document.createElement('div')
    t.className = 'snowbear-toast snowbear-toast--rich'

    const status = document.createElement('div')
    status.className = 'snowbear-toast__status'
    status.textContent = parsed.score != null ? `Score: ${parsed.score}/100 · ${ms}ms` : `Scored · ${ms}ms`
    t.appendChild(status)

    if (parsed.breakdown) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Breakdown'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = parsed.breakdown
      t.appendChild(p)
    }

    if (parsed.weaknesses.length) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Weaknesses'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = parsed.weaknesses.map((w) => `• ${w}`).join('\n')
      t.appendChild(p)
    }

    if (parsed.fix) {
      const h = document.createElement('div')
      h.className = 'snowbear-toast__heading'
      h.textContent = 'Fix'
      t.appendChild(h)
      const p = document.createElement('div')
      p.className = 'snowbear-toast__body'
      p.textContent = parsed.fix
      t.appendChild(p)
    }

    document.body.appendChild(t)
    setTimeout(() => t.remove(), 7000)
  }

  async function callGroq(action, prompt) {
    if (abortCtrl) abortCtrl.abort()
    abortCtrl = new AbortController()
    return SB.callSnowBearApi(action, prompt, prompts)
  }

  function closeMenu() {
    menuOpen = false
    wrap?.querySelector('.snowbear-toolbar')?.classList.remove('snowbear-toolbar--open')
    wrap?.querySelector('.snowbear-trigger')?.classList.remove('snowbear-trigger--open')
  }

  async function openMenu() {
    if (!authenticated) {
      toast('Please sign in via the SnowBear extension icon first.')
      return
    }
    menuOpen = true
    wrap?.querySelector('.snowbear-toolbar')?.classList.add('snowbear-toolbar--open')
    wrap?.querySelector('.snowbear-trigger')?.classList.add('snowbear-trigger--open')
  }

  async function toggleMenu() {
    if (busy) return
    if (menuOpen) closeMenu()
    else await openMenu()
  }

  function buildUI() {
    wrap = document.createElement('div')
    wrap.className = 'snowbear-wrap'
    wrap.id = 'snowbear-root'

    const trigger = document.createElement('button')
    trigger.className = 'snowbear-trigger'
    trigger.type = 'button'
    trigger.setAttribute('aria-label', 'SnowBear')
    trigger.innerHTML = `<img src="${BEAR_URL}" alt="" draggable="false"/>`
    trigger.addEventListener('click', async (e) => {
      e.stopPropagation()
      e.preventDefault()
      if (!authenticated) {
        toast('Sign in or sign up — click the SnowBear icon in your toolbar.')
        return
      }
      if (menuOpen) {
        closeMenu()
        return
      }
      await openMenu()
    })

    const toolbar = document.createElement('div')
    toolbar.className = 'snowbear-toolbar'
    toolbar.setAttribute('role', 'toolbar')

    TOOLS.forEach((tool) => {
      const btn = document.createElement('button')
      btn.className = 'snowbear-seg'
      btn.type = 'button'
      btn.dataset.action = tool.action
      btn.title = tool.desc
      btn.innerHTML = `
        <span class="snowbear-seg__icon">${ICONS[tool.action]}</span>
        <span class="snowbear-seg__label">${tool.label}</span>
      `
      btn.addEventListener('click', (e) => {
        e.stopPropagation()
        closeMenu()
        run(tool.action, btn)
      })
      toolbar.appendChild(btn)
    })

    wrap.appendChild(trigger)
    wrap.appendChild(toolbar)

    document.addEventListener('click', (e) => {
      if (!wrap?.contains(e.target)) closeMenu()
    })
  }

  function positionFallback(input) {
    if (!wrap || !input) return
    try {
      const r = input.getBoundingClientRect()
      wrap.style.top = `${Math.max(8, r.bottom - 42)}px`
      wrap.style.left = `${Math.max(8, r.left + 8)}px`
    } catch (_) {}
  }

  function insertIntoFooter(input, forceNew = false) {
    if (!wrap || !input) return false
    try {
      let point = null
      if (!forceNew && insertPointValid(lastInsertPoint)) {
        point = lastInsertPoint
      } else {
        point = findInsertPoint(input)
        if (!insertPointValid(point)) return false
        lastInsertPoint = point
      }

      if (isWrapAtPoint(point)) {
        wrap.classList.remove('snowbear-wrap--fixed')
        wrap.style.top = ''
        wrap.style.left = ''
        return true
      }

      wrap.classList.add('snowbear-wrap--settling')
      wrap.classList.remove('snowbear-wrap--fixed')
      wrap.style.top = ''
      wrap.style.left = ''

      if (point.mode === 'after') {
        point.target.insertAdjacentElement('afterend', wrap)
      } else if (point.mode === 'before') {
        point.target.insertAdjacentElement('beforebegin', wrap)
      } else if (point.mode === 'append') {
        point.target.appendChild(wrap)
      } else if (point.mode === 'prepend') {
        point.target.insertBefore(wrap, point.target.firstChild)
      }

      requestAnimationFrame(() => {
        wrap?.classList.remove('snowbear-wrap--settling')
      })
      return true
    } catch (_) {
      return false
    }
  }

  function attachFixed(input) {
    if (!wrap) return
    try {
      wrap.classList.add('snowbear-wrap--fixed')
      if (wrap.parentElement !== document.body) document.body.appendChild(wrap)
      positionFallback(input)
    } catch (_) {}
  }

  async function run(action, btn) {
    if (busy) return
    if (!authenticated) return toast('Sign in via the SnowBear toolbar icon first.')

    const input = findInput()
    if (!input) return toast('No prompt box found.')
    const prompt = getVal(input).trim()
    if (!prompt) return toast('Type a prompt first.')

    const data = await storageGet(['snowbear_user'])
    const uid = data.snowbear_user?.uid
    if (!uid) return toast('Sign in via the SnowBear extension icon first.')

    busy = true
    btn?.classList.add('snowbear-seg--active')
    wrap?.querySelectorAll('.snowbear-seg').forEach((b) => (b.disabled = true))
    const slowToast = setTimeout(() => toast('Processing…', 5000), 500)

    const t0 = performance.now()
    try {
      let res = await sendMsg({
        type: 'RUN_ACTION',
        uid,
        action,
        prompt,
        backend: SB.getBackendUrl(),
      })
      clearTimeout(slowToast)

      if (!res?.ok && res?.error && isRetryableMsgError(res.error)) {
        const usage = await sendMsg({ type: 'USAGE_CONSUME', uid, action })
        if (!usage?.allowed) {
          showUpgradeModal(usage || { allowed: false, message: res.error })
          return
        }
        const result = await callGroq(action, prompt)
        const ms = Math.round(performance.now() - t0)
        if (action === 'score') {
          const parsed = SB.parseScoreResponse(result)
          toastScore(parsed, ms)
        } else if (action === 'enhance') {
          const { enhanced, assumptions, suggestions } = SB.parseEnhanceResponse(result)
          setVal(findInput() || input, enhanced)
          toastEnhanceMeta(assumptions, suggestions, ms)
        } else {
          const output =
            action === 'grammar'
              ? SB.cleanGrammarOutput(prompt, result)
              : action === 'compress'
                ? SB.cleanCompressOutput(prompt, result)
                : SB.cleanOutput(result)
          setVal(findInput() || input, output)
          const done = { compress: 'Compressed', grammar: 'Grammar fixed' }
          toast(`${done[action]} (${ms}ms)`)
        }
        return
      }

      if (!res?.ok) {
        if (res?.usage && !res.usage.allowed) showUpgradeModal(res.usage)
        else toast(res?.error || 'API error')
        return
      }

      const result = SB.formatActionResult(action, res.data)
      const ms = Math.round(performance.now() - t0)

      if (action === 'score') {
        const parsed = SB.parseScoreResponse(result)
        toastScore(parsed, ms)
      } else if (action === 'enhance') {
        const { enhanced, assumptions, suggestions } = SB.parseEnhanceResponse(result)
        setVal(findInput() || input, enhanced)
        toastEnhanceMeta(assumptions, suggestions, ms)
      } else {
        const output =
          action === 'grammar'
            ? SB.cleanGrammarOutput(prompt, result)
            : action === 'compress'
              ? SB.cleanCompressOutput(prompt, result)
              : SB.cleanOutput(result)
        setVal(findInput() || input, output)
        const done = { compress: 'Compressed', grammar: 'Grammar fixed' }
        toast(`${done[action]} (${ms}ms)`)
      }
    } catch (err) {
      clearTimeout(slowToast)
      if (err.name !== 'AbortError') toast(err.message || 'API error')
    } finally {
      clearTimeout(slowToast)
      busy = false
      btn?.classList.remove('snowbear-seg--active')
      wrap?.querySelectorAll('.snowbear-seg').forEach((b) => (b.disabled = false))
    }
  }

  function teardown() {
    clearTimeout(teardownTimer)
    clearTimeout(lightUpdateTimer)
    try {
      wrap?.remove()
    } catch (_) {}
    wrap = null
    boundInput = null
    lastMountedInput = null
    lastInsertPoint = null
    closeMenu()
  }

  let mountPending = false
  let mountTimer = null
  let mountRaf = null
  let lastMountedInput = null
  let lastInsertPoint = null
  let successfulMounts = 0
  let teardownTimer = null
  let lightUpdateTimer = null
  let scrollRaf = null
  const INPUT_SWITCH_MARGIN = 8000

  function insertPointValid(point) {
    return !!(point?.target?.isConnected && isVisible(point.target))
  }

  function isWrapAtPoint(point) {
    if (!wrap || !point?.target) return false
    if (point.mode === 'after') return wrap.previousElementSibling === point.target
    if (point.mode === 'before') return wrap.nextElementSibling === point.target
    if (point.mode === 'append') {
      return wrap.parentElement === point.target && wrap === point.target.lastElementChild
    }
    if (point.mode === 'prepend') {
      return wrap.parentElement === point.target && wrap === point.target.firstElementChild
    }
    return false
  }

  function scheduleMount(fast) {
    clearTimeout(teardownTimer)
    clearTimeout(mountTimer)
    if (mountRaf) cancelAnimationFrame(mountRaf)
    const delay = fast || successfulMounts < 3 ? 0 : 120
    if (delay === 0) {
      mountRaf = requestAnimationFrame(() => {
        mountRaf = null
        mount()
      })
      return
    }
    mountTimer = setTimeout(() => mount(), delay)
  }

  function scheduleLightUpdate() {
    clearTimeout(lightUpdateTimer)
    lightUpdateTimer = setTimeout(() => {
      if (!wrap?.isConnected || !lastMountedInput?.isConnected) return
      if (isHiddenInput(lastMountedInput) || isExcludedInput(lastMountedInput)) {
        lastInsertPoint = null
        scheduleMount(true)
        return
      }
      if (wrap.classList.contains('snowbear-wrap--fixed')) {
        positionFallback(lastMountedInput)
        return
      }
      if (insertPointValid(lastInsertPoint) && isWrapAtPoint(lastInsertPoint)) return
      insertIntoFooter(lastMountedInput, true)
    }, 180)
  }

  function scheduleTeardown() {
    clearTimeout(teardownTimer)
    teardownTimer = setTimeout(() => {
      if (!findInput()) {
        lastInsertPoint = null
        teardown()
      }
    }, 900)
  }

  function mount() {
    if (mountPending) return
    if (!extensionContextOk()) {
      teardown()
      return
    }
    mountPending = true
    try {
      if (typeof SnowBearShared === 'undefined') return

      if (!SB.isSiteAllowed(location.hostname, settings)) {
        teardown()
        lastMountedInput = null
        return
      }

      const chatId = SB.getChatId()
      if (chatId !== currentChatId) {
        currentChatId = chatId
        contextRestored = false
        lastMountedInput = null
      }

      const input = findInput()
      if (!input) {
        if (wrap?.isConnected) scheduleTeardown()
        else lastMountedInput = null
        return
      }

      if (wrap?.isConnected && input === lastMountedInput) {
        if (insertPointValid(lastInsertPoint) && isWrapAtPoint(lastInsertPoint)) {
          if (wrap.classList.contains('snowbear-wrap--fixed')) positionFallback(input)
          successfulMounts++
          return
        }
        if (!insertIntoFooter(input)) attachFixed(input)
        successfulMounts++
        return
      }

      if (!wrap) buildUI()
      if (!wrap) return

      bindInputEvents(input)

      const inserted = insertIntoFooter(input)
      if (!inserted) attachFixed(input)
      lastMountedInput = input
      successfulMounts++

      // Refresh auth/settings after the bear is already visible
      loadState().then(() => {
        if (!SB.isSiteAllowed(location.hostname, settings)) teardown()
      })
      restoreContext(input)
    } catch (err) {
      console.debug('[SnowBear]', err)
      teardown()
    } finally {
      mountPending = false
    }
  }

  try {
    if (!chrome.storage?.onChanged) return

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return
      if (changes.snowbear_user) {
        const plan = changes.snowbear_user.newValue?.plan
        if (plan === 'unlimited' || plan === 'pro' || plan === 'polar') {
          document.querySelectorAll('.snowbear-upgrade-overlay').forEach((el) => el.remove())
        }
        loadState().then(() => scheduleMount())
        return
      }
      if (changes.snowbear_settings) scheduleMount()
    })

    loadState()
    sendMsg({ type: 'PING' })

    const onDomChange = (mutations) => {
      if (
        wrap?.isConnected &&
        lastMountedInput?.isConnected &&
        mutations?.every?.((m) => wrap.contains(m.target) || m.target === wrap)
      ) {
        return
      }
      if (wrap?.isConnected && lastMountedInput?.isConnected && successfulMounts > 2) {
        scheduleLightUpdate()
        return
      }
      scheduleMount(successfulMounts < 5)
    }
    if (document.body) {
      new MutationObserver(onDomChange).observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'style', 'hidden', 'aria-hidden'],
      })
    } else {
      document.addEventListener('DOMContentLoaded', () => scheduleMount(true), { once: true })
    }

    let resizeTimer = null
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer)
      resizeTimer = setTimeout(() => {
        if (wrap?.isConnected && lastMountedInput?.isConnected) scheduleLightUpdate()
        else scheduleMount(false)
      }, 150)
    })
    window.addEventListener(
      'scroll',
      () => {
        if (!wrap?.classList.contains('snowbear-wrap--fixed') || !lastMountedInput) return
        if (scrollRaf) return
        scrollRaf = requestAnimationFrame(() => {
          scrollRaf = null
          positionFallback(lastMountedInput)
        })
      },
      { capture: true, passive: true }
    )
    window.addEventListener(
      'focusin',
      (e) => {
        const t = e.target
        if (t && isEditableInput(t)) {
          const resolved = resolvePromptInput(t)
          if (resolved && !isExcludedInput(resolved)) focusedPromptInput = resolved
        }
        scheduleMount(true)
      },
      { capture: true, passive: true }
    )
    setInterval(() => {
      if (!wrap?.isConnected) scheduleMount(true)
    }, 4000)
    scheduleMount(true)
    setTimeout(() => scheduleMount(true), 120)
    setTimeout(() => scheduleMount(true), 400)
  } catch (err) {
    console.debug('[SnowBear] init failed', err)
  }
})()