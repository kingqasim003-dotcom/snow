const GROQ_CONFIG = {
  "apiKeys": [],
  "rateLimitPerKey": 30,
  "rateWindowMs": 60000,
  "model": "llama-3.1-8b-instant",
  "apiUrl": "https://api.groq.com/openai/v1/chat/completions",
  "requestTimeoutMs": 9000
};
