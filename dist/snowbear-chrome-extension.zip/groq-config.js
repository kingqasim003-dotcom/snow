// Groq API keys — rotated round-robin, 30 requests/minute per key
const GROQ_CONFIG = {
  apiKeys: [
    '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',
    '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',
    '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',
  ],
  rateLimitPerKey: 30,
  rateWindowMs: 60000,
  model: 'llama-3.1-8b-instant',
  apiUrl: 'https://api.groq.com/openai/v1/chat/completions',
  requestTimeoutMs: 30000,
}