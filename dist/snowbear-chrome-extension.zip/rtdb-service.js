// SnowBear Firebase Realtime Database (REST) — promo redeem & live user sync
const SnowBearRtdb = (function () {
  const DB_URL = (
    (typeof FIREBASE_CONFIG !== 'undefined' && FIREBASE_CONFIG.databaseURL) ||
    'https://snowbear-online-default-rtdb.asia-southeast1.firebasedatabase.app'
  ).replace(/\/$/, '')

  function websiteApiBase() {
    if (typeof WEBSITE_CONFIG !== 'undefined' && WEBSITE_CONFIG.backendUrl) {
      return WEBSITE_CONFIG.backendUrl.replace(/\/$/, '')
    }
    return 'http://localhost:3000'
  }

  function monthKey() {
    return new Date().toISOString().slice(0, 7)
  }

  function normalizeCode(code) {
    return (code || '').trim().toUpperCase().replace(/\s+/g, '')
  }

  function promoPathKey(code) {
    return normalizeCode(code).replace(/[.#$[\]/]/g, '')
  }

  function mapWebsitePlan(plan) {
    if (plan === 'polar') return 'pro'
    if (plan === 'unlimited' || plan === 'pro' || plan === 'free') return plan
    return 'free'
  }

  function effectiveWebsitePlan(plan, planExpiresAt) {
    const mapped = mapWebsitePlan(plan || 'free')
    if (mapped === 'free') return 'free'
    if (typeof planExpiresAt === 'number' && Date.now() >= planExpiresAt) return 'free'
    return mapped
  }

  async function expirePlanIfNeeded(uid, profile, idToken) {
    const plan = mapWebsitePlan(profile?.plan || 'free')
    if (plan === 'free' || typeof profile?.planExpiresAt !== 'number') return false
    if (Date.now() < profile.planExpiresAt) return false
    const month = monthKey()
    const purchased = profile?.credits?.purchased || 0
    await rtdbPatch(
      `users/${uid}`,
      {
        plan: 'free',
        planUpdatedAt: Date.now(),
        planExpiresAt: null,
        planBillingCycle: null,
        planActivatedAt: null,
        credits: { month, used: 0, purchased },
      },
      idToken
    )
    return true
  }

  async function rtdbError(res, fallback) {
    let detail = ''
    let correctUrl = ''
    try {
      const body = await res.json()
      detail = body?.error || ''
      correctUrl = body?.correctUrl || ''
    } catch (_) { /* ignore */ }
    if (correctUrl || detail.includes('different region')) {
      throw new Error(
        'Wrong database region. Reload extension in chrome://extensions, then try again.'
      )
    }
    if (res.status === 401 || res.status === 403 || detail === 'Permission denied') {
      throw new Error(
        'Sign in on snowbear.online (or localhost:3000), keep tab open, then redeem again.'
      )
    }
    if (res.status === 400) {
      throw new Error('Invalid session. Open snowbear.online signed in, then try again.')
    }
    throw new Error(detail || fallback || `Database error (${res.status}).`)
  }

  async function rtdbFetch(url, options) {
    try {
      return await fetch(url, options)
    } catch (_) {
      throw new Error(
        'Network error reaching Firebase. Check internet and reload the extension.'
      )
    }
  }

  function isPromoRedeemable(promo) {
    if (!promo || typeof promo !== 'object') return false
    if (promo.usedByUid) return false
    if (promo.active === false) return false
    return (promo.credits || 0) > 0
  }

  async function fetchPromoByCode(code, idToken) {
    const keys = [promoPathKey(code), normalizeCode(code)]
    for (const key of [...new Set(keys)]) {
      const promo = await rtdbGet(`promoCodes/${key}`, idToken)
      if (isPromoRedeemable(promo)) return { promo, key }
    }
    return null
  }

  async function rtdbGet(path, idToken) {
    if (!idToken) throw new Error('Sign in on snowbear.online first, then try again.')
    const url = `${DB_URL}/${path}.json?auth=${encodeURIComponent(idToken)}`
    const res = await rtdbFetch(url)
    if (!res.ok) await rtdbError(res, 'Could not read from database.')
    return res.json()
  }

  async function rtdbPatch(path, body, idToken) {
    if (!idToken) throw new Error('Sign in on snowbear.online first, then try again.')
    const url = `${DB_URL}/${path}.json?auth=${encodeURIComponent(idToken)}`
    const res = await rtdbFetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    if (!res.ok) await rtdbError(res, 'Could not update database.')
    return res.json()
  }

  async function rtdbPut(path, body, idToken) {
    if (!idToken) throw new Error('Sign in on snowbear.online first, then try again.')
    const url = `${DB_URL}/${path}.json?auth=${encodeURIComponent(idToken)}`
    const res = await rtdbFetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    if (!res.ok) await rtdbError(res, 'Could not write to database.')
    return res.json()
  }

  async function registerUserIfNeeded(uid, email, idToken) {
    if (!idToken || !uid || !email || !String(email).includes('@')) return
    let existing = null
    try {
      existing = await rtdbGet(`users/${uid}`, idToken)
    } catch (_) {}
    if (existing && typeof existing === 'object') {
      if (email && existing.email !== email) {
        await rtdbPatch(`users/${uid}`, { email }, idToken)
      }
      return
    }

    const month = monthKey()
    await rtdbPut(
      `users/${uid}`,
      {
        email: email || '',
        plan: 'free',
        createdAt: Date.now(),
        credits: { month, used: 0, purchased: 0 },
      },
      idToken
    )
  }

  async function syncCredits(uid, credits, idToken) {
    if (!idToken || !uid || !credits) return
    await rtdbPut(`users/${uid}/credits`, credits, idToken)
  }

  async function redeemViaServerApi(uid, email, idToken, rawCode) {
    const res = await rtdbFetch(`${websiteApiBase()}/api/redeem-promo`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idToken, code: rawCode }),
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok || !data?.ok) {
      throw new Error(data?.error || 'Could not redeem code.')
    }
    const month = monthKey()
    const all = (await chrome.storage.local.get('snowbear_credits')).snowbear_credits || {}
    const local = all[uid] || { month, used: 0, purchased: 0 }
    const localNorm =
      local.month === month ? local : { month, used: 0, purchased: local.purchased || 0 }
    all[uid] = {
      month,
      used: localNorm.used || 0,
      purchased: (localNorm.purchased || 0) + (data.credits || 0),
    }
    await chrome.storage.local.set({ snowbear_credits: all })
    return { ok: true, credits: data.credits, code: data.code, creditsRecord: all[uid] }
  }

  async function redeemPromoCode(uid, email, idToken, rawCode) {
    const code = normalizeCode(rawCode)
    if (!code) throw new Error('Enter a valid promo code.')
    if (!idToken) throw new Error('Sign in on the SnowBear website first to redeem codes.')

    try {
      return await redeemViaServerApi(uid, email, idToken, rawCode)
    } catch (apiErr) {
      const msg = apiErr?.message || ''
      if (msg && !msg.includes('Network error') && !msg.includes('fetch')) throw apiErr
    }

    const found = await fetchPromoByCode(code, idToken)
    if (!found) {
      throw new Error(
        'Promo code not found or already used. Generate a fresh code in admin and try again.'
      )
    }

    const { promo, key: promoKey } = found
    const creditAmount = promo.credits || 0
    const month = monthKey()

    await rtdbPatch(
      `promoCodes/${promoKey}`,
      {
        usedByUid: uid,
        usedByEmail: email,
        usedAt: Date.now(),
        active: false,
      },
      idToken
    )

    let current = null
    try {
      current = await rtdbGet(`users/${uid}/credits`, idToken)
    } catch (_) {
      current = null
    }

    const normalized =
      current && current.month === month
        ? current
        : { month, used: 0, purchased: (current && current.purchased) || 0 }

    const nextCredits = {
      month: normalized.month || month,
      used: normalized.used || 0,
      purchased: (normalized.purchased || 0) + creditAmount,
    }

    if (!current) {
      try {
        await rtdbPut(
          `users/${uid}`,
          {
            email: email || '',
            plan: 'free',
            createdAt: Date.now(),
            credits: nextCredits,
          },
          idToken
        )
      } catch (_) {
        await rtdbPut(`users/${uid}/credits`, nextCredits, idToken)
      }
    } else {
      await rtdbPut(`users/${uid}/credits`, nextCredits, idToken)
    }

    const data = await chrome.storage.local.get('snowbear_credits')
    const all = data.snowbear_credits || {}
    const local = all[uid] || { month, used: 0, purchased: 0 }
    const localNorm =
      local.month === month ? local : { month, used: 0, purchased: local.purchased || 0 }
    all[uid] = {
      month: nextCredits.month,
      used: Math.max(localNorm.used || 0, nextCredits.used || 0),
      purchased: nextCredits.purchased,
    }
    await chrome.storage.local.set({ snowbear_credits: all })

    return { ok: true, credits: creditAmount, code, creditsRecord: all[uid] }
  }

  async function fetchUserProfile(uid, idToken) {
    if (!idToken || !uid) return null
    try {
      let profile = await rtdbGet(`users/${uid}`, idToken)
      if (!profile || typeof profile !== 'object') return null
      if (await expirePlanIfNeeded(uid, profile, idToken)) {
        profile = await rtdbGet(`users/${uid}`, idToken)
      }
      const plan = effectiveWebsitePlan(profile.plan, profile.planExpiresAt)
      return {
        plan,
        credits: profile.credits || null,
        planUpdatedAt: profile.planUpdatedAt || 0,
        planExpiresAt: plan === 'free' ? null : profile.planExpiresAt || null,
        planBillingCycle: plan === 'free' ? null : profile.planBillingCycle || null,
      }
    } catch (_) {
      return null
    }
  }

  return { redeemPromoCode, registerUserIfNeeded, syncCredits, fetchUserProfile }
})()