// SnowBear auth service — Firebase REST API (runs in background service worker)
const SnowBearAuthService = (function () {
  const API_KEY = FIREBASE_CONFIG.apiKey
  const SIGNUP_URL = `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${API_KEY}`
  const SIGNIN_URL = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`
  const REFRESH_URL = `https://securetoken.googleapis.com/v1/token?key=${API_KEY}`
  const LOOKUP_URL = `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${API_KEY}`

  function normalizeEmail(email) {
    return (email || '').trim().toLowerCase()
  }

  function mapError(data) {
    const msg = data?.error?.message || 'Authentication failed'
    const err = { message: msg, code: 'auth/unknown', raw: msg }

    const codeMap = {
      EMAIL_EXISTS: 'auth/email-already-in-use',
      INVALID_EMAIL: 'auth/invalid-email',
      WEAK_PASSWORD: 'auth/weak-password',
      PASSWORD_DOES_NOT_MEET_REQUIREMENTS: 'auth/weak-password',
      EMAIL_NOT_FOUND: 'auth/user-not-found',
      INVALID_PASSWORD: 'auth/wrong-password',
      INVALID_LOGIN_CREDENTIALS: 'auth/invalid-credential',
      OPERATION_NOT_ALLOWED: 'auth/operation-not-allowed',
      TOO_MANY_ATTEMPTS_TRY_LATER: 'auth/too-many-requests',
      USER_DISABLED: 'auth/user-disabled',
      API_KEY_INVALID: 'auth/api-key-invalid',
    }

    if (msg.includes('API key not valid')) {
      err.code = 'auth/api-key-invalid'
      err.message = msg
      return err
    }

    err.code = codeMap[msg] || `auth/${msg.toLowerCase().replace(/_/g, '-')}`
    err.message = msg
    return err
  }

  function userMessage(err) {
    const map = {
      'auth/email-already-in-use': 'This email is already registered. Try logging in.',
      'auth/invalid-email': 'Enter a valid email address.',
      'auth/weak-password': 'Password must be at least 6 characters.',
      'auth/user-not-found': 'No account found with this email. Please sign up first.',
      'auth/wrong-password': 'Incorrect password. Please try again.',
      'auth/invalid-credential':
        'Wrong email or password. If you are new, click Sign Up to create an account first.',
      'auth/operation-not-allowed':
        'Email/password login is disabled. Enable it in Firebase Console → Authentication → Sign-in method.',
      'auth/too-many-requests': 'Too many attempts. Wait a few minutes and try again.',
      'auth/user-disabled': 'This account has been disabled.',
      'auth/api-key-invalid':
        'Firebase API key blocked. In Google Cloud Console, remove HTTP referrer restrictions on this API key.',
    }
    return map[err.code] || err.message || 'Authentication failed. Please try again.'
  }

  async function saveSession(data, email) {
    if (!data?.idToken || !data?.localId) {
      throw { code: 'auth/internal-error', message: 'Invalid response from Firebase. Please try again.' }
    }
    const stored = await chrome.storage.local.get('snowbear_user')
    const prev = stored.snowbear_user || {}

    const user = {
      uid: data.localId,
      email: data.email || email,
      idToken: data.idToken,
      refreshToken: data.refreshToken,
      expiresAt: Date.now() + parseInt(data.expiresIn || data.expires_in, 10) * 1000,
      plan: prev.uid === data.localId ? (prev.plan === 'pro' ? 'unlimited' : prev.plan || 'free') : 'free',
    }
    await chrome.storage.local.set({ snowbear_user: user })
    return user
  }

  async function apiPost(url, body, contentType = 'application/json') {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': contentType },
      body: typeof body === 'string' ? body : JSON.stringify(body),
    })
    let data = {}
    try {
      data = await res.json()
    } catch (_) {
      data = {}
    }
    if (!res.ok) throw mapError(data)
    return data
  }

  async function signUp(email, password) {
    const normalized = normalizeEmail(email)
    const data = await apiPost(SIGNUP_URL, {
      email: normalized,
      password,
      returnSecureToken: true,
    })
    return saveSession(data, normalized)
  }

  async function signIn(email, password) {
    const normalized = normalizeEmail(email)
    const data = await apiPost(SIGNIN_URL, {
      email: normalized,
      password,
      returnSecureToken: true,
    })
    return saveSession(data, normalized)
  }

  async function signUpOrSignIn(email, password) {
    try {
      return await signUp(email, password)
    } catch (err) {
      if (err.code === 'auth/email-already-in-use') {
        return signIn(email, password)
      }
      throw err
    }
  }

  async function refreshSession(refreshToken) {
    const data = await apiPost(
      REFRESH_URL,
      `grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}`,
      'application/x-www-form-urlencoded'
    )

    const stored = await chrome.storage.local.get('snowbear_user')
    const prev = stored.snowbear_user || {}

    const user = {
      uid: data.user_id || prev.uid,
      email: data.email || prev.email,
      idToken: data.id_token,
      refreshToken: data.refresh_token || refreshToken,
      expiresAt: Date.now() + parseInt(data.expires_in, 10) * 1000,
      plan: prev.plan || 'free',
    }
    await chrome.storage.local.set({ snowbear_user: user })
    return user
  }

  async function verifyToken(idToken) {
    const data = await apiPost(LOOKUP_URL, { idToken })
    const account = data.users?.[0]
    if (!account) return null
    return {
      uid: account.localId,
      email: account.email,
      idToken,
    }
  }

  async function signOut() {
    await chrome.storage.local.remove('snowbear_user')
  }

  async function getCurrentUser() {
    const stored = await chrome.storage.local.get('snowbear_user')
    const user = stored.snowbear_user
    if (!user?.uid) return null

    if (user.idToken && user.expiresAt && Date.now() < user.expiresAt - 60000) return user

    if (user.refreshToken) {
      try {
        return await refreshSession(user.refreshToken)
      } catch (_) {
        // fall through to token lookup
      }
    }

    if (user.idToken) {
      try {
        const verified = await verifyToken(user.idToken)
        if (verified) {
          const updated = {
            ...user,
            ...verified,
            expiresAt: user.expiresAt || Date.now() + 55 * 60 * 1000,
          }
          await chrome.storage.local.set({ snowbear_user: updated })
          return updated
        }
      } catch (_) {}
    }

    // Website-synced users have no refreshToken — keep session, caller may pull a fresh token
    if (!user.refreshToken && user.uid) return user.idToken ? user : null

    await signOut()
    return null
  }

  return {
    normalizeEmail,
    signUp,
    signIn,
    signUpOrSignIn,
    signOut,
    getCurrentUser,
    userMessage,
  }
})()