// SnowBear auth client — delegates to background service worker (reliable in MV3 popup)
const SnowBearAuth = (function () {
  function sendOnce(type, payload = {}) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage({ type, ...payload }, (res) => {
          if (chrome.runtime.lastError) {
            const msg = chrome.runtime.lastError.message || ''
            const friendly = /no sw/i.test(msg)
              ? 'SnowBear is waking up. Try again in a moment.'
              : msg || 'Extension not ready. Reload SnowBear.'
            reject(new Error(friendly))
            return
          }
          if (!res) {
            reject(new Error('No response from extension. Reload SnowBear and try again.'))
            return
          }
          if (res.error) {
            const err = new Error(res.error.message || 'Authentication failed')
            err.code = res.error.code
            err.raw = res.error.raw
            err.userMessage = res.error.userMessage
            reject(err)
          } else if (type === 'AUTH_SIGNOUT') {
            resolve(true)
          } else {
            resolve(res.user ?? null)
          }
        })
      } catch (e) {
        reject(e)
      }
    })
  }

  async function send(type, payload = {}) {
    let lastErr
    for (let i = 0; i < 3; i++) {
      try {
        return await sendOnce(type, payload)
      } catch (e) {
        lastErr = e
        if (i < 2) await new Promise((r) => setTimeout(r, 250))
      }
    }
    throw lastErr
  }

  return {
    signUp: (email, password) => send('AUTH_SIGNUP', { email, password }),
    signIn: (email, password) => send('AUTH_SIGNIN', { email, password }),
    signUpOrSignIn: (email, password) => send('AUTH_SIGNUP_OR_SIGNIN', { email, password }),
    signOut: () => send('AUTH_SIGNOUT'),
    getCurrentUser: () => send('AUTH_GET_USER'),
    ping: () => sendOnce('PING'),
  }
})()