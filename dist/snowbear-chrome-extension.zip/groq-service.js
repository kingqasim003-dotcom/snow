// Centralized Groq key rotation — one shared limiter in the background worker
const SnowBearGroq = (function () {
  const keyUsage = new Map()
  let roundRobinIndex = 0

  function maskKey(key) {
    return `${key.slice(0, 8)}...${key.slice(-4)}`
  }

  function isKeyAvailable(key, now) {
    const usage = keyUsage.get(key)
    if (!usage) return true
    if (usage.cooldownUntil && now < usage.cooldownUntil) return false
    if (now >= usage.resetAt) return true
    return usage.count < GROQ_CONFIG.rateLimitPerKey
  }

  function recordKeyUsage(key, now) {
    const usage = keyUsage.get(key)
    if (!usage || now >= usage.resetAt) {
      keyUsage.set(key, { count: 1, resetAt: now + GROQ_CONFIG.rateWindowMs })
      return
    }
    usage.count += 1
  }

  function markKeyRateLimited(key, now) {
    const usage = keyUsage.get(key)
    if (!usage || now >= usage.resetAt) {
      keyUsage.set(key, {
        count: GROQ_CONFIG.rateLimitPerKey,
        resetAt: now + GROQ_CONFIG.rateWindowMs,
        cooldownUntil: now + GROQ_CONFIG.rateWindowMs,
      })
      return
    }
    usage.count = GROQ_CONFIG.rateLimitPerKey
    usage.cooldownUntil = now + GROQ_CONFIG.rateWindowMs
  }

  function selectNextKey(keys, tried, now) {
    const available = keys.filter((key) => !tried.has(key) && isKeyAvailable(key, now))
    if (!available.length) return null
    const offset = roundRobinIndex % available.length
    const selected = available[offset]
    roundRobinIndex = (roundRobinIndex + 1) % keys.length
    return selected
  }

  async function requestGroq(apiKey, userContent, options) {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), GROQ_CONFIG.requestTimeoutMs)

    try {
      const body = {
        model: GROQ_CONFIG.model,
        temperature: options.temperature ?? 0.2,
        max_completion_tokens: options.maxTokens ?? 300,
        stream: false,
        messages: [{ role: 'user', content: userContent }],
      }

      const res = await fetch(GROQ_CONFIG.apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
        signal: controller.signal,
      })

      if (res.status === 429) {
        const err = new Error('Groq rate limit reached.')
        err.status = 429
        throw err
      }

      if (!res.ok) {
        let detail = ''
        try {
          detail = (await res.json())?.error?.message || ''
        } catch (_) {}
        console.error(`[SnowBear] Groq error [${maskKey(apiKey)}]:`, res.status, detail)
        throw new Error(detail || 'AI service temporarily unavailable.')
      }

      const data = await res.json()
      const content = data?.choices?.[0]?.message?.content
      if (!content || typeof content !== 'string') {
        throw new Error('AI service returned an empty response.')
      }
      return content.trim()
    } catch (err) {
      if (err.name === 'AbortError') {
        throw new Error('AI request timed out.')
      }
      throw err
    } finally {
      clearTimeout(timeout)
    }
  }

  async function complete(userContent, options = {}) {
    const keys = GROQ_CONFIG.apiKeys
    if (!keys.length) throw new Error('No Groq API keys configured.')

    const tried = new Set()
    let lastError = null

    while (tried.size < keys.length) {
      const now = Date.now()
      const apiKey = selectNextKey(keys, tried, now)
      if (!apiKey) break

      tried.add(apiKey)
      recordKeyUsage(apiKey, now)

      try {
        return await requestGroq(apiKey, userContent, options)
      } catch (err) {
        lastError = err
        if (err.status === 429) {
          markKeyRateLimited(apiKey, now)
          console.warn(`[SnowBear] Key ${maskKey(apiKey)} at 30/min limit — switching…`)
          continue
        }
        throw err
      }
    }

    throw (
      lastError ||
      new Error('All Groq API keys are at the 30 requests/minute limit. Please wait and try again.')
    )
  }

  return { complete }
})()